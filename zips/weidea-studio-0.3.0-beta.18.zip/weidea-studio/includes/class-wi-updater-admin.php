<?php
/**
 * Plugins-screen UI for the update channel: the per-site stable/beta
 * switch and one-click version rollback.
 *
 * Rollback rides WordPress's own upgrade flow: arming a rollback stores a
 * short-lived target version, then hands off to the native
 * update.php?action=upgrade-plugin screen, where WI_Updater presents the
 * older retained release as "the update". Same pipeline, same UI, same
 * safety — just pointed backwards. A builder update misbehaving on a live
 * store must be a thirty-second incident, not an evening.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Channel switch + rollback actions.
 */
final class WI_Updater_Admin {

	/**
	 * Hook registration.
	 */
	public static function init() {
		add_filter( 'plugin_action_links_' . WI_PLUGIN_BASENAME, array( __CLASS__, 'action_links' ) );
		add_action( 'admin_post_wi_switch_channel', array( __CLASS__, 'handle_switch_channel' ) );
		add_action( 'admin_post_wi_check_updates', array( __CLASS__, 'handle_check_updates' ) );
		add_action( 'admin_post_wi_rollback', array( __CLASS__, 'handle_rollback' ) );
		add_action( 'admin_notices', array( __CLASS__, 'channel_notice' ) );
		add_action( 'admin_notices', array( __CLASS__, 'check_notice' ) );
	}

	/**
	 * Forget everything cached about which version is out there.
	 *
	 * FINDING #26. Both deletes matter and they are different caches:
	 *
	 *   · `WI_Updater::TRANSIENT` is OUR manifest, held for 12 hours. While it
	 *     is an object nothing re-fetches, so the channel has no way to tell
	 *     this site that a release landed.
	 *   · `update_plugins` is WORDPRESS'S. WeIdea only reaches the plugins row
	 *     through `pre_set_site_transient_update_plugins`, which fires when
	 *     core WRITES that transient — and core only writes it when it is
	 *     missing. Drop our manifest alone and the screen keeps showing
	 *     yesterday's answer from a perfectly fresh manifest.
	 *
	 * Extracted rather than copied: the channel switch has done exactly this
	 * since it was written, and it is the behaviour Chris has been getting by
	 * switching beta → stable → beta. One path, two callers.
	 */
	private static function forget_cached_versions() {
		delete_site_transient( WI_Updater::TRANSIENT );
		delete_site_transient( 'update_plugins' );
	}

	/**
	 * Add "switch channel" and "roll back" to the plugin's row.
	 *
	 * @param string[] $links Existing action links.
	 * @return string[]
	 */
	public static function action_links( $links ) {
		if ( ! current_user_can( 'update_plugins' ) ) {
			return $links;
		}

		$updater = WI_Updater::instance();
		$other   = 'beta' === $updater->channel() ? 'stable' : 'beta';

		// FINDING #26. Chris's other plugin projects carry this link; WeIdea's
		// updater predates it, and the 12-hour cache had caused the same
		// confusion three times — most recently during a release wait, with
		// the only workaround being to switch channel and switch back, because
		// that was the one action that re-read the manifest.
		//
		// FIRST in the row, because it is the thing you reach for most and the
		// two beside it change what this site RECEIVES. An action link rather
		// than row meta: this presses a button that changes state and makes an
		// outbound request, and row meta is for links that only navigate.
		$check_url = wp_nonce_url(
			add_query_arg( 'action', 'wi_check_updates', admin_url( 'admin-post.php' ) ),
			'wi_check_updates'
		);
		$links['wi-check'] = sprintf(
			'<a href="%s">%s</a>',
			esc_url( $check_url ),
			esc_html__( 'Check for updates', 'weidea-studio' )
		);

		$switch_url = wp_nonce_url(
			add_query_arg(
				array(
					'action'  => 'wi_switch_channel',
					'channel' => $other,
				),
				admin_url( 'admin-post.php' )
			),
			'wi_switch_channel_' . $other
		);
		$links['wi-channel'] = sprintf(
			'<a href="%s">%s</a>',
			esc_url( $switch_url ),
			'beta' === $other
				? esc_html__( 'Switch to beta channel', 'weidea-studio' )
				: esc_html__( 'Switch to stable channel', 'weidea-studio' )
		);

		$target = $updater->rollback_target();
		if ( $target ) {
			$rollback_url = wp_nonce_url(
				add_query_arg(
					array(
						'action'  => 'wi_rollback',
						'version' => rawurlencode( (string) $target->version ),
					),
					admin_url( 'admin-post.php' )
				),
				'wi_rollback_' . (string) $target->version
			);
			$links['wi-rollback'] = sprintf(
				'<a href="%s">%s</a>',
				esc_url( $rollback_url ),
				sprintf(
					/* translators: %s: version number. */
					esc_html__( 'Roll back to %s', 'weidea-studio' ),
					esc_html( (string) $target->version )
				)
			);
		}

		return $links;
	}

	/**
	 * Switch the site's release channel, drop caches, re-check.
	 */
	public static function handle_switch_channel() {
		$channel = isset( $_GET['channel'] ) ? sanitize_key( wp_unslash( $_GET['channel'] ) ) : '';
		check_admin_referer( 'wi_switch_channel_' . $channel );
		if ( ! current_user_can( 'update_plugins' ) ) {
			wp_die( esc_html__( 'You are not allowed to change the WeIdea Studio release channel.', 'weidea-studio' ) );
		}

		update_option( WI_Updater::CHANNEL_OPTION, 'beta' === $channel ? 'beta' : 'stable' );

		// A channel change must be visible immediately, not after cache expiry.
		self::forget_cached_versions();

		wp_safe_redirect(
			add_query_arg( 'wi-channel', rawurlencode( $channel ), admin_url( 'plugins.php' ) )
		);
		exit;
	}

	/**
	 * Drop the caches, re-read the manifest, and say what was found.
	 *
	 * FINDING #26. The channel switch already did all of this; the only thing
	 * it also did was change which track the site rides, which is not what
	 * Chris wanted when he pressed it.
	 */
	public static function handle_check_updates() {
		check_admin_referer( 'wi_check_updates' );
		if ( ! current_user_can( 'update_plugins' ) ) {
			wp_die( esc_html__( 'You are not allowed to check WeIdea Studio for updates.', 'weidea-studio' ) );
		}

		self::forget_cached_versions();

		// Read AFTER the drop, so this is the fresh answer and not the one
		// that was already on the screen. `channel_release()` re-fetches
		// because `manifest()` finds no transient to reuse.
		$release = WI_Updater::instance()->channel_release();
		$found   = ( $release && ! empty( $release->version ) ) ? (string) $release->version : '';

		wp_safe_redirect(
			add_query_arg( 'wi-checked', rawurlencode( $found ), admin_url( 'plugins.php' ) )
		);
		exit;
	}

	/**
	 * Arm a rollback and hand off to the native upgrade screen.
	 */
	public static function handle_rollback() {
		$version = isset( $_GET['version'] ) ? sanitize_text_field( wp_unslash( $_GET['version'] ) ) : '';
		check_admin_referer( 'wi_rollback_' . $version );
		if ( ! current_user_can( 'update_plugins' ) ) {
			wp_die( esc_html__( 'You are not allowed to roll WeIdea Studio back.', 'weidea-studio' ) );
		}

		if ( ! WI_Updater::instance()->find_release( $version ) ) {
			wp_die( esc_html__( 'That version is not retained on the update channel.', 'weidea-studio' ) );
		}

		set_site_transient( WI_Updater::ROLLBACK_TARGET, $version, 5 * MINUTE_IN_SECONDS );

		// Built by hand, NOT with wp_nonce_url(): that helper HTML-escapes
		// its output (for use in href attributes), which corrupts the
		// query string when sent as a Location header.
		$upgrade_url = add_query_arg(
			array(
				'action'   => 'upgrade-plugin',
				'plugin'   => rawurlencode( WI_PLUGIN_BASENAME ),
				'_wpnonce' => wp_create_nonce( 'upgrade-plugin_' . WI_PLUGIN_BASENAME ),
			),
			self_admin_url( 'update.php' )
		);
		wp_safe_redirect( $upgrade_url );
		exit;
	}

	/**
	 * Confirmation after a channel switch.
	 */
	public static function channel_notice() {
		if ( empty( $_GET['wi-channel'] ) || ! current_user_can( 'update_plugins' ) ) {
			return;
		}
		$channel = sanitize_key( wp_unslash( $_GET['wi-channel'] ) );
		printf(
			'<div class="notice notice-success is-dismissible"><p>%s</p></div>',
			'beta' === $channel
				? esc_html__( 'WeIdea Studio is now on the beta channel — this site receives everything hot.', 'weidea-studio' )
				: esc_html__( 'WeIdea Studio is now on the stable channel — this site receives promoted releases only.', 'weidea-studio' )
		);
	}

	/**
	 * What "Check for updates" found, in plain English.
	 *
	 * FINDING #26. Three answers, not two: an update is waiting, this site is
	 * current, or the channel could not be reached. That last one is its own
	 * sentence on purpose — "you're up to date" after a failed request is a
	 * lie the updater has no way to walk back, and it is exactly the state a
	 * release-day check is most likely to hit.
	 */
	public static function check_notice() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only display of a redirect result.
		if ( ! isset( $_GET['wi-checked'] ) || ! current_user_can( 'update_plugins' ) ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only display of a redirect result.
		$found = sanitize_text_field( wp_unslash( $_GET['wi-checked'] ) );

		if ( '' === $found ) {
			printf(
				'<div class="notice notice-warning is-dismissible"><p>%s</p></div>',
				esc_html__( 'WeIdea Studio could not reach its update channel just now, so there is nothing new to report. Try again in a moment.', 'weidea-studio' )
			);
			return;
		}

		if ( version_compare( $found, WI_VERSION, '>' ) ) {
			printf(
				'<div class="notice notice-success is-dismissible"><p>%s</p></div>',
				sprintf(
					/* translators: 1: the version available on the channel. 2: the version installed. */
					esc_html__( 'Version %1$s is available. This site has %2$s — the update button on this row will install it.', 'weidea-studio' ),
					esc_html( $found ),
					esc_html( WI_VERSION )
				)
			);
			return;
		}

		printf(
			'<div class="notice notice-success is-dismissible"><p>%s</p></div>',
			sprintf(
				/* translators: %s: the installed version. */
				esc_html__( 'WeIdea Studio is up to date — this site has %s, which is the newest on its channel.', 'weidea-studio' ),
				esc_html( WI_VERSION )
			)
		);
	}
}
