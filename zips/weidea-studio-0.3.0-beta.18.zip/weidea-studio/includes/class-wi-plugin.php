<?php
/**
 * Plugin bootstrap.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Wires the plugin's modules together. Modules are internal architecture —
 * they surface to the user as one workbench, never as separate tools.
 */
final class WI_Plugin {

	/**
	 * Singleton instance.
	 *
	 * @var WI_Plugin|null
	 */
	private static $instance = null;

	/**
	 * Get (and lazily create) the plugin instance.
	 *
	 * @return WI_Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Boot the modules.
	 */
	private function __construct() {
		add_action( 'init', array( $this, 'load_textdomain' ), 1 );
		WI_Breakpoints::init();
		WI_Blocks::init();
		WI_Assets::init();
		WI_Motion::init();
		// Same idea as WI_Motion, one filter earlier: decorate the saved
		// markup on its way out rather than change what save() writes.
		WI_Labels::init();
		WI_Updater::instance();
		WI_Updater_Admin::init();
		WI_WebAuthn::init();
		WI_Staging::init();
		WI_Deploy::init();
		WI_Workbench::init();
		WI_Settings_Page::init();

		add_action( 'admin_notices', array( $this, 'missing_build_notice' ) );
	}

	/**
	 * Load translations (self-hosted plugins don't get wp.org's
	 * auto-loading). PHP strings translate from languages/; editor
	 * scripts get theirs via wp_set_script_translations in WI_Blocks.
	 */
	public function load_textdomain() {
		load_plugin_textdomain(
			'weidea-studio',
			false,
			dirname( WI_PLUGIN_BASENAME ) . '/languages'
		);
	}

	/**
	 * The plugin's namespaced uploads home: everything WeIdea ever
	 * generates or stores (compiled CSS, fonts, image sequences) lives
	 * under uploads/weidea/<sub>, so cleanup and backups have ONE tree.
	 *
	 * @param string $sub Optional subdirectory (e.g. "css", "sequences").
	 * @return array { 'dir' => string, 'url' => string }
	 */
	public static function upload_dir( $sub = '' ) {
		$uploads = wp_upload_dir();
		$rel     = 'weidea' . ( $sub ? '/' . trim( $sub, '/' ) : '' );
		$dir     = trailingslashit( $uploads['basedir'] ) . $rel;
		wp_mkdir_p( $dir );
		return array(
			'dir' => $dir,
			'url' => trailingslashit( $uploads['baseurl'] ) . $rel,
		);
	}

	/**
	 * Dev convenience: warn when the plugin is running from source without
	 * a build. A packaged zip always ships with build/ included.
	 */
	public function missing_build_notice() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		if ( file_exists( WI_PLUGIN_DIR . 'build/blocks/section/block.json' ) ) {
			return;
		}
		printf(
			'<div class="notice notice-warning"><p>%s</p></div>',
			esc_html__( 'WeIdea Studio: no build found. Run "npm install && npm run build" in the plugin directory.', 'weidea-studio' )
		);
	}
}
