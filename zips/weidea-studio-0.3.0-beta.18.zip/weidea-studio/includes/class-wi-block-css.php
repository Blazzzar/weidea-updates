<?php
/**
 * Per-instance responsive CSS, generated from the control registry.
 *
 * The registry schema declares which attribute each control edits and which
 * CSS property/selector it emits; this class walks that schema against a
 * block's saved attributes and compiles the instance stylesheet using the
 * site's configured breakpoints. Devices without their own value simply
 * emit nothing — the cascade handles inheritance (desktop is the base rule,
 * tablet/mobile are max-width overrides).
 *
 * Phase 0 note: instance CSS is emitted inline at render. Compiling merged
 * static per-page stylesheets moves into the staged-deploy pipeline in
 * Phase 1, per the no-bloat contract.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registry-driven CSS generation.
 */
final class WI_Block_CSS {

	/**
	 * Generate the instance CSS for one rendered block.
	 *
	 * @param string $block_name Block name, e.g. "weidea/section".
	 * @param array  $attrs      Saved block attributes.
	 * @return string Compiled CSS, or empty string.
	 */
	/**
	 * Whether a control's legacy shorthand has been superseded — the PHP
	 * half of a rule whose two halves MUST agree exactly.
	 *
	 * Column's `padding` shorthand and its four per-side longhands bind the
	 * SAME CSS property, which nothing in this codebase had done before.
	 * Relying on declaration order to resolve them produces a measured
	 * editor/front-end divergence: the editor flattens both into one rule
	 * for the previewed device (longhand wins), while this generator buckets
	 * per device, so at tablet width a desktop-only longhand sits in the
	 * desktop rule while the shorthand resets the edge in the tablet one.
	 * Same attributes, two different computed values. So the shorthand is
	 * SUPPRESSED rather than overridden, identically in both generators.
	 *
	 * The predicate is spelled out rather than written as `! empty()` on
	 * purpose (risk R2): `empty( '0' )` is TRUE in PHP, so `! empty()` would
	 * fail to suppress where the JS mirror suppresses — a fresh divergence
	 * created by the very rule written to close one. A device counts as
	 * carrying a value when it holds a string with something in it, and
	 * '0' and '0px' are values.
	 *
	 * @param array $control Control definition.
	 * @param array $attrs   Saved block attributes.
	 * @return bool True when the control must not emit.
	 */
	private static function legacy_superseded( $control, $attrs ) {
		if ( empty( $control['legacy']['supersededBy'] ) ) {
			return false;
		}
		foreach ( (array) $control['legacy']['supersededBy'] as $attr_name ) {
			$map = isset( $attrs[ $attr_name ] ) ? $attrs[ $attr_name ] : null;
			if ( ! is_array( $map ) ) {
				continue;
			}
			foreach ( $map as $v ) {
				if ( '' !== trim( (string) $v ) ) {
					return true;
				}
			}
		}
		return false;
	}

	public static function generate( $block_name, $attrs ) {
		$schema = WI_Registry::schema_for( $block_name );
		if ( ! $schema || empty( $attrs['uniqueId'] ) ) {
			return '';
		}

		$uid = preg_replace( '/[^a-zA-Z0-9_-]/', '', (string) $attrs['uniqueId'] );
		if ( '' === $uid ) {
			return '';
		}

		$selectors = isset( $schema['selectors'] ) ? $schema['selectors'] : array();
		// Buckets follow the ordered device list — never a hard-coded
		// three — so a site (or a later phase) can add breakpoints and
		// existing content compiles against them unchanged.
		$devices    = WI_Breakpoints::devices();
		$device_ids = array_column( $devices, 'id' );
		$base_id    = $device_ids[0];
		$buckets    = array_fill_keys( $device_ids, array() );

		foreach ( (array) $schema['panels'] as $panel ) {
			foreach ( (array) $panel['controls'] as $control ) {
				if ( empty( $control['css']['property'] ) || empty( $control['bind']['attribute'] ) ) {
					continue;
				}

				// A superseded legacy shorthand goes silent the moment any
				// of the longhands that replace it carries a value.
				if ( self::legacy_superseded( $control, $attrs ) ) {
					continue;
				}

				$css       = $control['css'];
				$attr_name = $control['bind']['attribute'];
				$value     = isset( $attrs[ $attr_name ] ) ? $attrs[ $attr_name ] : null;
				$sel_key   = isset( $css['selector'] ) ? $css['selector'] : 'self';
				$sel_tpl   = isset( $selectors[ $sel_key ] ) ? $selectors[ $sel_key ] : '.wi-{uid}';
				$selector  = str_replace( '{uid}', $uid, $sel_tpl );
				$property  = $css['property'];

				// Hover-state bindings style the same selector's :hover.
				if ( isset( $css['state'] ) && 'hover' === $css['state'] ) {
					$selector .= ':hover';
				}

				if ( ! empty( $css['perDeviceBool'] ) && is_array( $value ) ) {
					// Per-device boolean binding (device visibility): emit
					// the fixed value into every device bucket the map
					// marks true — e.g. hide-on-mobile → display:none in the
					// mobile bucket only.
					$v = self::sanitize_value( isset( $css['value'] ) ? $css['value'] : '' );
					if ( '' !== $v ) {
						foreach ( $device_ids as $device ) {
							if ( ! empty( $value[ $device ] ) ) {
								$buckets[ $device ][ $selector ][ $property ] = $v;
							}
						}
					}
				} elseif ( isset( $css['value'] ) ) {
					// Preset binding: a fixed declaration emitted while the
					// attribute is truthy (e.g. stack-on-mobile), confined
					// to css.device's bucket when given.
					if ( $value ) {
						$device = isset( $css['device'] ) && isset( $buckets[ $css['device'] ] )
							? $css['device']
							: $base_id;
						$v      = self::sanitize_value( $css['value'] );
						if ( '' !== $v ) {
							$buckets[ $device ][ $selector ][ $property ] = $v;
						}
					}
				} elseif ( ! empty( $control['responsive'] ) && is_array( $value ) ) {
					foreach ( $device_ids as $device ) {
						$v = isset( $value[ $device ] ) ? self::sanitize_value( $value[ $device ] ) : '';
						if ( '' !== $v ) {
							$buckets[ $device ][ $selector ][ $property ] = self::apply_template( $css, $v );
							// Companion declarations, mirroring the
							// non-responsive branch below and the JS canvas
							// path (src/registry/instance-css.js:129). This
							// branch used to emit the property and nothing
							// else, so a RESPONSIVE control with a companion
							// painted correctly on the canvas and did
							// nothing on the front end — canvas right, front
							// end wrong, every gate green. Column's content
							// alignment is the first such control and cannot
							// ship without this.
							//
							// They land in the SAME device bucket as the
							// value that needs them, so a tablet-only
							// justify-content brings its own flex context
							// into the tablet media query and nowhere else.
							if ( ! empty( $css['companion'] ) && is_array( $css['companion'] ) ) {
								foreach ( $css['companion'] as $cp => $cv ) {
									$cvv = self::sanitize_value( $cv );
									if ( '' !== $cvv ) {
										$buckets[ $device ][ $selector ][ $cp ] = $cvv;
									}
								}
							}
						}
					}
				} elseif ( empty( $control['responsive'] ) ) {
					$v = self::sanitize_value( is_scalar( $value ) ? $value : '' );
					if ( '' !== $v ) {
						$buckets[ $base_id ][ $selector ][ $property ] = self::apply_template( $css, $v );
						// Companion declarations: fixed props emitted
						// alongside this value (e.g. the flex context that
						// justify-content needs). Only when the control has
						// a value, so opting out costs nothing.
						if ( ! empty( $css['companion'] ) && is_array( $css['companion'] ) ) {
							foreach ( $css['companion'] as $cp => $cv ) {
								$cvv = self::sanitize_value( $cv );
								if ( '' !== $cvv ) {
									$buckets[ $base_id ][ $selector ][ $cp ] = $cvv;
								}
							}
						}
					}
				}
			}
		}

		// Composite backgrounds/overlay: the one family the generic
		// property:value path can't carry (needs url()/gradients). The
		// typed composer validates each part and hands finished, safe
		// declarations back into the same device→selector→prop buckets.
		$self_sel    = str_replace( '{uid}', $uid, isset( $selectors['self'] ) ? $selectors['self'] : '.wi-{uid}' );
		$overlay_sel = str_replace( '{uid}', $uid, isset( $selectors['overlay'] ) ? $selectors['overlay'] : $self_sel . '::before' );
		$bg          = WI_Background::compose( $self_sel, $overlay_sel, $attrs, $device_ids, $base_id );
		foreach ( $bg as $device => $sel_map ) {
			if ( ! isset( $buckets[ $device ] ) ) {
				continue;
			}
			foreach ( $sel_map as $selector => $props ) {
				foreach ( $props as $property => $val ) {
					$buckets[ $device ][ $selector ][ $property ] = $val;
				}
			}
		}

		$css = '';
		foreach ( $devices as $device ) {
			$bucket = $buckets[ $device['id'] ];
			if ( ! $bucket ) {
				continue;
			}
			if ( null === $device['max_width'] ) {
				$css .= self::rules( $bucket );
			} else {
				$css .= '@media (max-width:' . (int) $device['max_width'] . 'px){' . self::rules( $bucket ) . '}';
			}
		}

		// The Advanced-fold custom CSS box: a deliberate power-user escape
		// hatch (editor-authored, logged-in). "selector" is replaced with
		// the block's scoped selector; angle brackets are stripped so it
		// can never break out of the <style> element.
		$css .= self::custom_css( isset( $attrs['wiCustomCss'] ) ? $attrs['wiCustomCss'] : '', $self_sel );

		return $css;
	}

	/**
	 * Sanitize and scope the Advanced-fold custom CSS.
	 *
	 * @param mixed  $raw      Raw CSS with "selector" tokens.
	 * @param string $self_sel The block's scoped selector.
	 * @return string
	 */
	private static function custom_css( $raw, $self_sel ) {
		if ( ! is_string( $raw ) || '' === trim( $raw ) ) {
			return '';
		}
		// Strip anything that could escape the style element or smuggle
		// behavior; balance is the author's responsibility, scope isn't.
		$css = preg_replace( '/[<>]|@import|javascript:|expression\s*\(/i', '', $raw );
		return str_replace( 'selector', $self_sel, (string) $css );
	}

	/**
	 * Wrap a value in the binding's template, e.g. "0 0 {value}" turns a
	 * width into a flex shorthand. The value is already sanitized.
	 *
	 * @param array  $css   The control's css binding.
	 * @param string $value Sanitized value.
	 * @return string
	 */
	private static function apply_template( $css, $value ) {
		if ( empty( $css['template'] ) || false === strpos( $css['template'], '{value}' ) ) {
			return $value;
		}
		// The template itself ships in the registry schema (trusted);
		// only {value} carries user input, sanitized above.
		return str_replace( '{value}', $value, $css['template'] );
	}

	/**
	 * Serialize a selector => declarations map.
	 *
	 * @param array $map Selector => [ property => value ].
	 * @return string
	 */
	private static function rules( $map ) {
		$out = '';
		foreach ( $map as $selector => $props ) {
			$out .= $selector . '{';
			foreach ( $props as $property => $value ) {
				$out .= $property . ':' . $value . ';';
			}
			$out .= '}';
		}
		return $out;
	}

	/**
	 * Reject values that could escape a declaration or smuggle behavior.
	 *
	 * @param mixed $value Raw attribute value.
	 * @return string Safe value or empty string.
	 */
	private static function sanitize_value( $value ) {
		if ( ! is_string( $value ) && ! is_numeric( $value ) ) {
			return '';
		}
		$value = trim( (string) $value );
		if ( '' === $value ) {
			return '';
		}
		if ( preg_match( '/[{};<>\\\\]|expression|javascript|url\s*\(/i', $value ) ) {
			return '';
		}
		return $value;
	}
}
