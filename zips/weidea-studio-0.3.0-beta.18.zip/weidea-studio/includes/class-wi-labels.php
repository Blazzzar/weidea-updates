<?php
/**
 * Visitor-facing control words for the interactive blocks, translated at
 * RENDER time (finding #28).
 *
 * The off-canvas drawer's "Menu"/"Close" and the carousel's "Pause",
 * "Play", "Previous slide", "Next slide", "Slides", "%1$s of %2$s" and
 * "Go to slide %s" are deliberately NOT run through __() where they are
 * written. They land in SAVED markup, and saved markup is re-serialized by
 * save() and diffed against the stored HTML every time a post is opened —
 * so a translated string is a block-validation failure waiting for the next
 * author working in a different admin language, on every carousel on the
 * site. src/blocks/carousel/controls.js and src/blocks/offcanvas/markup.js
 * both say so at the point of refusal, and both deprecated.js files name
 * this file as the fix.
 *
 * Here the same words are free to translate, because nothing is stored: the
 * filter decorates the HTML on its way to the visitor, exactly as WI_Motion
 * stamps its classes, and the post content is untouched. No deprecation, no
 * data-wi-v bump, no save() change — the content-is-sacred rule holds.
 *
 * WHICH words get filled: only the ones still showing the untranslated
 * default. The test is the string itself rather than the attribute behind
 * it, because that is the question actually being asked ("is this word ours
 * or the author's?"), it needs no model of each block's fallback chain, and
 * it is idempotent — an author who typed their own words keeps them, in any
 * language. The one string it cannot distinguish is an author who typed the
 * English default on purpose; on a translated site, showing them the
 * translation of the word they typed is the better of the two mistakes.
 *
 * On an English site every replacement below is the identity — __() returns
 * its input when no translation is loaded — so this costs one string
 * comparison per interactive block and changes nothing.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Render-time translation of the words save() had to bake in untranslated.
 */
final class WI_Labels {

	/**
	 * Hook registration.
	 */
	public static function init() {
		// Priority 8: before WI_Motion (9) decorates the root and WI_Assets
		// (10) prepends the instance <style>, so this only ever sees the
		// block's own saved markup and never has to skip past either.
		add_filter( 'render_block', array( __CLASS__, 'render_block' ), 8, 2 );
	}

	/**
	 * The saved English default → its translation, per block.
	 *
	 * Built on demand, never at file scope: translations are not available
	 * until the textdomain is loaded. Each value is a literal __() call so
	 * the strings stay extractable into languages/ by the usual tooling.
	 *
	 * KEEP IN SYNC with the constants in src/blocks/offcanvas/markup.js and
	 * src/blocks/carousel/{controls,save}.js. A word changed there and not
	 * here simply stops being translated — it cannot corrupt anything — but
	 * it also cannot be noticed, so the e2e suite reads both lists.
	 *
	 * @param string $block Block name.
	 * @return array Default => translation.
	 */
	private static function words( $block ) {
		if ( 'weidea/offcanvas' === $block ) {
			return array(
				'Menu'  => __( 'Menu', 'weidea-studio' ),
				'Close' => __( 'Close', 'weidea-studio' ),
			);
		}
		return array(
			'Pause'          => __( 'Pause', 'weidea-studio' ),
			'Play'           => __( 'Play', 'weidea-studio' ),
			'Previous slide' => __( 'Previous slide', 'weidea-studio' ),
			'Next slide'     => __( 'Next slide', 'weidea-studio' ),
			'Slides'         => __( 'Slides', 'weidea-studio' ),
			/* translators: 1: the current slide's number, 2: the number of slides. */
			'%1$s of %2$s'   => __( '%1$s of %2$s', 'weidea-studio' ),
			/* translators: %s: the slide's number. */
			'Go to slide %s' => __( 'Go to slide %s', 'weidea-studio' ),
		);
	}

	/**
	 * Fill the interactive blocks' default labels on the way out.
	 *
	 * @param string $content Rendered block HTML.
	 * @param array  $block   Parsed block.
	 * @return string
	 */
	public static function render_block( $content, $block ) {
		$name = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
		if ( 'weidea/offcanvas' !== $name && 'weidea/carousel' !== $name ) {
			return $content;
		}
		if ( ! is_string( $content ) || '' === trim( $content ) ) {
			return $content;
		}

		$words = self::words( $name );
		// An untranslated site (or an untranslated string) means every
		// replacement is the identity. Leaving early keeps the common case
		// free and keeps the HTML byte-identical rather than round-tripped.
		$words = array_filter(
			$words,
			static function ( $translated, $default ) {
				return $translated !== $default;
			},
			ARRAY_FILTER_USE_BOTH
		);
		if ( ! $words ) {
			return $content;
		}

		return 'weidea/carousel' === $name
			? self::carousel( $content, $words )
			: self::offcanvas( $content, $words );
	}

	/**
	 * Off-canvas: the dialog's accessible name, the trigger's words, and
	 * the close button's words.
	 *
	 * @param string $content Block HTML.
	 * @param array  $words   Default => translation.
	 * @return string
	 */
	private static function offcanvas( $content, $words ) {
		$content = self::attribute( $content, null, 'data-wi-dialog-label', $words );
		$content = self::text( $content, 'wi-offcanvas__trigger', $words );
		return self::text( $content, 'wi-offcanvas__close', $words );
	}

	/**
	 * Carousel: the three label TEMPLATES on the root (view.js interpolates
	 * them with the live slide count), the pause button's two states, and
	 * the arrows' words.
	 *
	 * @param string $content Block HTML.
	 * @param array  $words   Default => translation.
	 * @return string
	 */
	private static function carousel( $content, $words ) {
		foreach ( array( 'data-wi-slide-label', 'data-wi-track-label', 'data-wi-dot-label' ) as $attr ) {
			$content = self::attribute( $content, null, $attr, $words );
		}
		// The pause button carries BOTH states as data attributes, because
		// view.js swaps its textContent between them — so the visible label
		// and the accessible name stay one string. All three need filling.
		$content = self::attribute( $content, 'wi-carousel__pause', 'data-wi-pause', $words );
		$content = self::attribute( $content, 'wi-carousel__pause', 'data-wi-play', $words );
		$content = self::text( $content, 'wi-carousel__pause', $words );
		$content = self::text( $content, 'wi-carousel__prev', $words );
		return self::text( $content, 'wi-carousel__next', $words );
	}

	/**
	 * Replace one attribute's value when it is still the untranslated
	 * default.
	 *
	 * @param string      $content Block HTML.
	 * @param string|null $class   Class of the tag to seek, or null for the root.
	 * @param string      $attr    Attribute name.
	 * @param array       $words   Default => translation.
	 * @return string
	 */
	private static function attribute( $content, $class, $attr, $words ) {
		if ( ! class_exists( 'WP_HTML_Tag_Processor' ) ) {
			return $content;
		}
		$tags  = new WP_HTML_Tag_Processor( $content );
		$found = null === $class
			? $tags->next_tag()
			: $tags->next_tag( array( 'class_name' => $class ) );
		if ( ! $found ) {
			return $content;
		}
		$value = $tags->get_attribute( $attr );
		if ( ! is_string( $value ) || ! isset( $words[ $value ] ) ) {
			return $content;
		}
		$tags->set_attribute( $attr, $words[ $value ] );
		return $tags->get_updated_html();
	}

	/**
	 * Replace one element's text when it is still the untranslated default.
	 *
	 * WP_HTML_Tag_Processor reaches attributes but not text, and this
	 * plugin supports WordPress 6.5, where nothing in core sets an
	 * element's content. So the text is matched directly — narrowly, and
	 * only against markup this plugin wrote: a <button> carrying one of our
	 * own class names, whose entire contents are one of our own English
	 * defaults. Anything else (an author's words, a nested element, another
	 * plugin's button) fails the match and is left exactly as it was.
	 *
	 * @param string $content Block HTML.
	 * @param string $class   Class of the button.
	 * @param array  $words   Default => translation.
	 * @return string
	 */
	private static function text( $content, $class, $words ) {
		// Deliberately unclever: no `>` ever appears inside an attribute
		// value in markup this plugin writes, so `[^>]*` is exact here and a
		// pattern that cannot backtrack is worth more than one that could
		// survive HTML it will never be given. Anything it does not match is
		// simply left alone.
		$pattern = '#(<button\b[^>]*class="[^"]*(?<![\w-])'
			. preg_quote( $class, '#' )
			. '(?![\w-])[^"]*"[^>]*>)([^<]*)(</button>)#';

		return preg_replace_callback(
			$pattern,
			static function ( $m ) use ( $words ) {
				$text = trim( $m[2] );
				if ( ! isset( $words[ $text ] ) ) {
					return $m[0];
				}
				return $m[1] . esc_html( $words[ $text ] ) . $m[3];
			},
			$content,
			1
		);
	}
}
