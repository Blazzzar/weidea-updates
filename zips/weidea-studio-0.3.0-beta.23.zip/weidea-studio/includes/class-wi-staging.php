<?php
/**
 * Staged edits: workbench saves never touch the live post.
 *
 * Each live post gets at most one staged copy (a hidden draft clone,
 * linked by meta). Editing happens on the copy through the normal block
 * editor; a signed preview link renders the staged content at the REAL
 * live URL for anyone holding the link; Deploy (WI_Deploy) publishes the
 * copy over the live post and retires it.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Staged-copy lifecycle, preview links, REST surface.
 */
final class WI_Staging {

	const META_KEY = '_wi_staging_of';

	/**
	 * THE STATUSES A STAGED COPY MAY HOLD — the one definition, read by
	 * everything that has an opinion about it.
	 *
	 * `staged_id()` has always looked for draft OR pending, and that query is
	 * what makes a copy FINDABLE: the moment a copy holds anything else,
	 * staged_id() stops returning it, `hasStaged` goes false, Deploy reports
	 * "Nothing is staged", and the copy is stranded. So this list is not a
	 * policy invented for finding #88 — it is the definition the product has
	 * always run on, finally written down once instead of typed out at each
	 * site that needs it.
	 *
	 * ⛔ WHICH IS WHY THE GUARD AND THE QUERY MUST READ THE SAME ARRAY. Two
	 * copies of this list is the drift #86 and #89 both exist to stop, and
	 * here it would be worse than cosmetic: a guard allowing a status the
	 * query does not find would let somebody save a copy into a state where
	 * nothing can reach it again.
	 */
	const COPY_STATUSES = array( 'draft', 'pending' );

	/**
	 * Statuses the guard deliberately lets through, each for a stated reason.
	 *
	 * ⛔ `trash` IS THE BIN, AND THE BIN IS A RULED FEATURE. Throwing the copy
	 * away moves it to `trash` — `rest_discard()` below does exactly that,
	 * through `wp_trash_post()` or `wp_update_post()`, and both of those run
	 * through `clamp_status()` like everything else. A guard that clamped
	 * every non-copy status would therefore shut the ONE door out of a copy
	 * that finding #55 exists to provide, and Undo with it. That is not a
	 * hypothetical: it is the first thing the obvious build gets wrong, and
	 * four cases in workbench-status-guard.spec.js are there to catch it.
	 * A binned copy is not a live page, which is the thing #88 is about.
	 *
	 * `inherit` is core's own internal — the status every revision carries. A
	 * revision is a different post with its own id and no marker meta, so the
	 * guard never sees one; it is listed for the case where something hands a
	 * copy that status directly.
	 *
	 * ⛔ `auto-draft` IS DELIBERATELY NOT ON THIS LIST, and it was, in the
	 * first build of this guard. It was let through on the reasoning that it
	 * "puts nothing on the public web", which is true and is not the risk:
	 * core's daily `wp_scheduled_auto_draft_delete` runs
	 * `wp_delete_auto_drafts()`, which **force-deletes** every auto-draft over
	 * seven days old — `wp_delete_post( $id, true )`, no bin, no Undo. Q3
	 * ruled that this product bins rather than deletes precisely because a
	 * staged copy is the one place work exists nowhere else, and
	 * `rest_discard()` below goes to real trouble to honour that even when
	 * `EMPTY_TRASH_DAYS` is 0. Passing `auto-draft` through handed core a hard
	 * delete instead. MEASURED on the running 7.1: a copy moved to
	 * `auto-draft`, backdated eight days, was gone after one run of
	 * `wp_delete_auto_drafts()`. Found by an adversarial audit of this guard's
	 * own first build.
	 */
	const PASSTHROUGH_STATUSES = array( 'trash', 'inherit' );

	/**
	 * What the LIVE page said at the moment the copy was taken — a
	 * fingerprint of its title and content, and only those two.
	 *
	 * This is the baseline Deploy compares against (finding #42). Dates
	 * cannot do this job: the copy is inserted as a draft, core registers
	 * draft with 'date_floating' => true, and wp_insert_post therefore
	 * writes '0000-00-00 00:00:00' into BOTH GMT columns — so a date check
	 * would find the live page newer than its own copy every single time
	 * and refuse every deploy on every page from the day it shipped.
	 */
	const FROM_META = '_wi_staged_from';

	/**
	 * What the COPY said at the moment it was made.
	 *
	 * The baseline for "has anyone actually changed this copy?" (Q1). It
	 * exists as a SECOND value rather than re-using FROM_META because
	 * inserting the copy is not always byte-lossless, which was MEASURED
	 * rather than assumed: with kses filters active, a live page holding
	 * `<!-- wp:html --><!-- /wp:html -->` comes back out of wp_insert_post
	 * as `<!-- wp:html /-->`. One stored value would then make a
	 * brand-new copy read as "already changed" and put the words
	 * "this copy has changes" on a copy nobody had touched.
	 *
	 * ONE definition of "different" all the same (design risk R-E): both
	 * stamps are made by fingerprint() and both are compared by it. Two
	 * baselines, because there are two objects and two questions — not two
	 * definitions.
	 */
	const COPY_META = '_wi_staged_copy';

	/**
	 * When the copy was made — a stamp we write ourselves, never read as
	 * the gate. It is what lets the refusal say WHEN: "you took this copy
	 * on Tuesday; the page changed on Thursday" is a far more useful
	 * sentence than "the page changed."
	 */
	const AT_META = '_wi_staged_at';

	/**
	 * Hook registration.
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		add_action( 'pre_get_posts', array( __CLASS__, 'hide_staged_copies' ) );
		add_action( 'wp', array( __CLASS__, 'maybe_preview' ) );

		// ⛳ FINDING #88(a) — a staged copy cannot be saved out of
		// draft/pending, whatever control asks. TWO mechanisms, and both are
		// load-bearing; see guard_rest_status() and clamp_status() for which
		// road each one covers and why neither can do the other's job.
		add_action( 'rest_api_init', array( __CLASS__, 'guard_rest_types' ), 20 );
		add_filter( 'wp_insert_post_data', array( __CLASS__, 'clamp_status' ), 10, 2 );
		// THE THIRD ROAD. `wp_publish_post()` writes the row with
		// `$wpdb->update()` and calls neither of the two above; this is the
		// only seam on it. Priority 1 so the repair happens before anything
		// else reacts to the transition.
		add_action( 'transition_post_status', array( __CLASS__, 'repair_status' ), 1, 3 );
		// And the scheduled publish, stopped BEFORE it happens rather than
		// repaired after. Core's own handler sits at the default 10 and
		// returns early unless the post is still `future`.
		add_action( 'publish_future_post', array( __CLASS__, 'disarm_scheduled_publish' ), 1 );
	}

	/**
	 * THE ONE LIST. Register the REST-side guard for every post type that
	 * has a REST surface.
	 *
	 * ⛔ THE FILTER NAME CARRIES THE POST TYPE IN IT — core applies
	 * `rest_pre_insert_{$this->post_type}` from WP_REST_Posts_Controller. A
	 * staged copy takes the LIVE post's own type (see rest_stage() below), so
	 * a guard registered for `post` alone would miss every PAGE — which is
	 * the entire product. Registering per type from the live registry is the
	 * only spelling that cannot go quietly out of date when a site adds a
	 * custom type, and workbench-status-guard.spec.js drives BOTH built-in
	 * types for exactly that reason.
	 */
	public static function guard_rest_types() {
		foreach ( get_post_types( array( 'show_in_rest' => true ), 'names' ) as $type ) {
			add_filter( "rest_pre_insert_{$type}", array( __CLASS__, 'guard_rest_status' ), 10, 2 );
		}
	}

	/**
	 * REST routes.
	 */
	public static function register_routes() {
		$post_arg = array(
			'post' => array(
				'type'     => 'integer',
				'required' => true,
			),
		);

		// WHO MAY THROW A COPY AWAY: anyone who can edit the page, the same
		// bar as making one (Chris, Q4, August 19 2026). The seam between
		// "can edit" and "can deploy" exists for a real reason — the day Jen
		// edits without deploying — but discarding is not deploying. It
		// changes nothing the public can see, and putting it behind
		// wi_deploy means the person who made the mess cannot tidy it and
		// has to come and find Chris. That is a bottleneck dressed as a
		// safeguard. Whoever can make a copy can throw one away.
		$can_edit = function ( $request ) {
			return current_user_can( 'edit_post', (int) $request['post'] );
		};

		register_rest_route(
			'wi/v1',
			'/stage',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_stage' ),
				'permission_callback' => $can_edit,
				'args'                => $post_arg,
			)
		);

		// The read side. The Workbench's discard confirm has to describe the
		// copy AS IT IS NOW — somebody may have been editing it in the
		// overlay for twenty minutes since it was opened — and it must get
		// those facts without calling /stage, because /stage CREATES a copy
		// when there isn't one. A confirm that quietly re-makes the thing it
		// is about to throw away would be a memorable bug.
		register_rest_route(
			'wi/v1',
			'/staged',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_staged' ),
				'permission_callback' => $can_edit,
				'args'                => $post_arg,
			)
		);

		register_rest_route(
			'wi/v1',
			'/discard',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_discard' ),
				'permission_callback' => $can_edit,
				'args'                => $post_arg,
			)
		);

		register_rest_route(
			'wi/v1',
			'/undiscard',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_undiscard' ),
				'permission_callback' => $can_edit,
				'args'                => $post_arg + array(
					'staged' => array(
						'type'     => 'integer',
						'required' => true,
					),
				),
			)
		);
	}

	/**
	 * The fingerprint of exactly what Deploy overwrites, and nothing else.
	 *
	 * WI_Deploy::rest_deploy writes post_title and post_content over the
	 * live post and touches nothing else — not the excerpt, not the
	 * featured image, not page attributes, not block-level meta. So this
	 * hashes those two and only those two, and the check's scope and the
	 * damage's scope are the same shape by construction. Change one without
	 * the other and this stops meaning what it says.
	 *
	 * The NUL between them is a separator, not decoration: without it a
	 * title of "ab" with an empty body and a title of "a" with a body of
	 * "b" fingerprint identically.
	 *
	 * @param string $title   Post title.
	 * @param string $content Post content.
	 * @return string Hex digest.
	 */
	public static function fingerprint( $title, $content ) {
		return hash( 'sha256', (string) $title . "\n\0\n" . (string) $content );
	}

	/**
	 * fingerprint() for a post object.
	 *
	 * @param WP_Post|null $post Post.
	 * @return string Hex digest, or '' when there is no post.
	 */
	public static function post_fingerprint( $post ) {
		return $post instanceof WP_Post
			? self::fingerprint( $post->post_title, $post->post_content )
			: '';
	}

	/**
	 * Has anyone actually CHANGED the copy since it was made?
	 *
	 * Q1: a copy only counts once it differs from what it was cloned from.
	 * The dialog's own sentence predicts that "your changes will be
	 * replaced by that copy" — when the copy is identical to the page it
	 * came from, deploying it replaces nothing and the prediction is false.
	 * A warning that fires when it is wrong is exactly the habituation E2's
	 * narrowing existed to prevent, arriving through a different door.
	 *
	 * ⚑ RISK R-D — WHY "NO STAMP" MEANS TRUE HERE AND FALSE IN live_moved().
	 * Both mean the same thing: "can't tell — behave exactly as the build
	 * before this one did." Before this shipped the dialog fired whenever a
	 * copy existed, so no stamp must arm it. Before this shipped Deploy
	 * never refused, so no stamp must let it through. The two answers look
	 * opposite and are the same rule.
	 *
	 * @param int $staged_id Copy ID.
	 * @return bool
	 */
	public static function copy_differs( $staged_id ) {
		$made = (string) get_post_meta( (int) $staged_id, self::COPY_META, true );
		if ( '' === $made ) {
			return true;
		}
		return self::post_fingerprint( get_post( (int) $staged_id ) ) !== $made;
	}

	/**
	 * Has the LIVE page changed since the copy was taken?
	 *
	 * Finding #42, and Q7: this compares CONTENT, never dates. Plenty of
	 * things nudge a page's modified stamp without changing a word of it —
	 * measured on this very install, a re-save with identical title and
	 * body moved post_modified by a second and left the fingerprint
	 * untouched — and a warning that fires on nothing trains people to
	 * click past it.
	 *
	 * Its one blind spot is benign: change the live page and change it
	 * back, and the fingerprint matches and nothing warns, because there is
	 * nothing to lose.
	 *
	 * See copy_differs() for why a missing stamp answers false here.
	 *
	 * @param WP_Post|null $post      Live post.
	 * @param int          $staged_id Copy ID.
	 * @return bool
	 */
	public static function live_moved( $post, $staged_id ) {
		$from = (string) get_post_meta( (int) $staged_id, self::FROM_META, true );
		if ( '' === $from ) {
			return false;
		}
		return self::post_fingerprint( $post ) !== $from;
	}

	/**
	 * Everything a person needs to SEE about a copy before anything offers
	 * to throw it away.
	 *
	 * This shape exists because of the August 12 sighting on finding #55.
	 * The dialog fired on every save, and Chris's first two moves were to
	 * purge the SiteGround cache and to check no preview window was open.
	 * Neither could ever have helped — the copy is a draft post carrying
	 * _wi_staging_of, not a cached file and not an open tab, and
	 * hide_staged_copies() keeps it out of the Pages list, so he could not
	 * see or delete the thing the dialog was about. The missing door was
	 * worse than "there is no discard button": the object had no visible
	 * existence at all. A bare "Discard" on an invisible object asks
	 * somebody to delete something they cannot look at.
	 *
	 * @param int $post_id Live post ID.
	 * @return array|null Null when there is no copy.
	 */
	public static function staged_facts( $post_id ) {
		$staged_id = self::staged_id( $post_id );
		if ( ! $staged_id ) {
			return null;
		}
		$at = (int) get_post_meta( $staged_id, self::AT_META, true );
		return array(
			'id'     => $staged_id,
			'at'     => $at,
			'edited' => self::copy_differs( $staged_id ),
			// Whether "edited" is a MEASUREMENT or a fallback. A copy made
			// before this shipped carries no baseline, so copy_differs()
			// answers true to keep the dialog behaving as it always did
			// (R-D) — but that is "we cannot tell", not "somebody changed
			// it", and the confirm must not say the second when it means the
			// first. On upgrade morning every existing copy is this one.
			'known'  => '' !== (string) get_post_meta( $staged_id, self::COPY_META, true ),
			'madeOn' => $at ? self::human_stamp( $at ) : '',
		);
	}

	/**
	 * A stamp written the way the rest of WordPress writes dates.
	 *
	 * Chris ruled the real date and time over "2 days ago" (August 26
	 * 2026, on the mock): these sentences are about which of two things
	 * happened first, and clock times can be checked against what a person
	 * remembers doing. Reading the site's own format is what makes this
	 * match the revision list "See what changed" lands on.
	 *
	 * @param int $timestamp Unix timestamp.
	 * @return string
	 */
	public static function human_stamp( $timestamp ) {
		return sprintf(
			/* translators: 1: a date, 2: a time of day. */
			__( '%1$s at %2$s', 'weidea-studio' ),
			wp_date( get_option( 'date_format' ), (int) $timestamp ),
			wp_date( get_option( 'time_format' ), (int) $timestamp )
		);
	}

	/**
	 * Create (or reuse) the staged copy for a post.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function rest_stage( $request ) {
		$post = get_post( (int) $request['post'] );
		if ( ! $post || wp_is_post_revision( $post ) ) {
			return new WP_Error( 'wi_no_post', __( 'Post not found.', 'weidea-studio' ), array( 'status' => 404 ) );
		}

		$staged_id = self::staged_id( $post->ID );
		$created   = ! $staged_id;

		// ⛔ THE TRAP, AND IT IS THE SINGLE MISTAKE MOST LIKELY TO BE MADE
		// HERE BY A FUTURE AUTHOR BEING HELPFUL.
		//
		// The stamps are written in THIS BRANCH ONLY — when the copy is
		// created. Re-opening the Workbench re-uses the copy that already
		// exists (that is what the `if` is for), and it must NOT refresh
		// either stamp. Refreshing them would erase the very evidence the
		// deploy check exists to read, and it would do it silently, on the
		// most ordinary action in the whole product: opening the Workbench
		// again. Somebody stages, somebody else edits the live page,
		// somebody re-opens the Workbench to look — and the warning that
		// was about to save them quietly stops being possible.
		//
		// `staging-lifecycle.spec.js` asserts this by CONSEQUENCE rather
		// than by reading the meta: stage, edit live, stage again, and the
		// deploy must still refuse.
		if ( $created ) {
			$staged_id = wp_insert_post(
				array(
					'post_type'    => $post->post_type,
					'post_status'  => 'draft',
					'post_title'   => $post->post_title,
					'post_content' => $post->post_content,
					'meta_input'   => array(
						self::META_KEY  => $post->ID,
						self::FROM_META => self::post_fingerprint( $post ),
						self::AT_META   => time(),
					),
				),
				true
			);
			if ( is_wp_error( $staged_id ) ) {
				return $staged_id;
			}
			// Read the copy back rather than fingerprinting what we sent:
			// wp_insert_post runs the content through save filters, and
			// with kses active that is not always byte-lossless. The
			// baseline for "has anyone changed this copy" has to be what
			// the copy ACTUALLY became, or a brand-new copy reads as
			// already edited.
			update_post_meta(
				$staged_id,
				self::COPY_META,
				self::post_fingerprint( get_post( $staged_id ) )
			);
		}

		$stamped_at = (int) get_post_meta( $staged_id, self::AT_META, true );

		return rest_ensure_response(
			array(
				'staged_id'   => $staged_id,
				'edit_url'    => add_query_arg( 'wi-workbench', '1', get_edit_post_link( $staged_id, 'raw' ) ),
				'preview_url' => self::preview_url( $post->ID, $staged_id ),
				// Nothing downstream could previously tell "you already had
				// one of these" from "one has just been made for you", even
				// if it wanted to.
				'created'     => $created,
				'staged_at'   => $stamped_at,
				// Guarded, or a copy with no stamp reports itself as having
				// been made on 1 January 1970.
				'made_on'     => $stamped_at ? self::human_stamp( $stamped_at ) : '',
				'differs'     => self::copy_differs( $staged_id ),
				'title'       => $post->post_title,
			)
		);
	}

	/**
	 * The copy's facts, right now. Read-only, and it never creates one.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function rest_staged( $request ) {
		$post = get_post( (int) $request['post'] );
		if ( ! $post ) {
			return new WP_Error( 'wi_no_post', __( 'Post not found.', 'weidea-studio' ), array( 'status' => 404 ) );
		}
		return rest_ensure_response(
			array(
				'staged' => self::staged_facts( $post->ID ),
				'title'  => $post->post_title,
			)
		);
	}

	/**
	 * Throw the copy away — into the BIN, never a hard delete.
	 *
	 * Deploy's outright delete is safe because the content landed on the
	 * live page one line earlier. Discard has no such landing: this is the
	 * only place in the whole product where work is destroyed that has
	 * never existed anywhere else. So it goes to the WordPress trash and
	 * an Undo sits under it (Chris, Q3, August 19 2026).
	 *
	 * And binning needs NO query changes at all, which is most of why it
	 * is cheap: staged_id() already looks only at draft and pending, so a
	 * binned copy is automatically "not staged" everywhere — the sidebar
	 * sentence goes, the dialog stops, Deploy says "Nothing is staged."
	 * The door out works by moving one status.
	 *
	 * ⚑ WHAT THE BIN DOES AND DOES NOT BUY, said plainly so nobody
	 * describes it as bigger than it is. It buys the Undo. It does not put
	 * the copy in a list anybody can browse: hide_staged_copies() filters
	 * every admin list table on the _wi_staging_of key, and the Trash view
	 * is one of those tables, so a binned copy is out of sight there too.
	 * WordPress clears the trash on its own schedule after that
	 * (EMPTY_TRASH_DAYS — measured as 30 on this install).
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function rest_discard( $request ) {
		$post = get_post( (int) $request['post'] );
		if ( ! $post ) {
			return new WP_Error( 'wi_no_post', __( 'Post not found.', 'weidea-studio' ), array( 'status' => 404 ) );
		}
		$staged_id = self::staged_id( $post->ID );
		if ( ! $staged_id ) {
			return new WP_Error( 'wi_no_staged', __( 'Nothing is staged for this page.', 'weidea-studio' ), array( 'status' => 409 ) );
		}

		// ⛔ wp_trash_post() PERMANENTLY DELETES WHEN TRASH IS SWITCHED OFF.
		// Core's own first two lines: `if ( ! EMPTY_TRASH_DAYS ) { return
		// wp_delete_post( $post_id, true ); }`. So on any site carrying
		// `define( 'EMPTY_TRASH_DAYS', 0 )` — a common enough hardening —
		// the "bin, never delete" ruling would silently become a hard delete
		// on the ONE path in this product that destroys work existing
		// nowhere else, and the Undo underneath it would have nothing to
		// bring back.
		//
		// So the status is moved directly when trash is off. staged_id()
		// filters on draft/pending, so the copy stops being found either
		// way, and rest_undiscard() sets the status back explicitly rather
		// than relying on _wp_trash_meta_status — which is why it does not
		// matter that this route did not write one.
		//
		// The trade is stated rather than hidden: on such a site WordPress
		// runs no scheduled purge, so the copy sits in the bin indefinitely.
		// Keeping work nobody asked us to destroy is the right side to err
		// on, and it is the side Q3 ruled.
		$binned = EMPTY_TRASH_DAYS
			? wp_trash_post( $staged_id )
			: wp_update_post(
				array(
					'ID'          => $staged_id,
					'post_status' => 'trash',
				),
				true
			);

		if ( ! $binned || is_wp_error( $binned ) ) {
			return new WP_Error(
				'wi_discard_failed',
				__( 'The copy could not be thrown away.', 'weidea-studio' ),
				array( 'status' => 500 )
			);
		}

		return rest_ensure_response(
			array(
				'discarded' => true,
				'staged_id' => $staged_id,
				'post'      => $post->ID,
			)
		);
	}

	/**
	 * Undo — take the copy back out of the bin.
	 *
	 * ⛔ ONE RULE, OR THE UNDO LIES. If the copy is binned and somebody
	 * then opens the Workbench again, a NEW copy is created while the
	 * binned one still carries its _wi_staging_of. Restoring the old one
	 * would leave two, and staged_id() would start returning whichever the
	 * database happened to hand back first. So this REFUSES once a newer
	 * copy exists, in plain words, rather than quietly making a mess that
	 * shows up later as "Deploy used the wrong copy."
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function rest_undiscard( $request ) {
		$post_id   = (int) $request['post'];
		$staged_id = (int) $request['staged'];
		$staged    = get_post( $staged_id );

		// The copy must really be this page's copy, and really be in the
		// bin. Without both checks this route untrashes anything its caller
		// can name.
		// The link is read once and required to be a real, positive id that
		// matches — never `(int) '' === 0` quietly agreeing with a `$post_id`
		// of 0. The capability gate above already refuses post 0, and this
		// makes that belt-and-braces rather than load-bearing.
		$linked = (int) get_post_meta( $staged_id, self::META_KEY, true );
		if (
			! $staged
			|| $post_id < 1
			|| $linked < 1
			|| 'trash' !== $staged->post_status
			|| $linked !== $post_id
		) {
			return new WP_Error(
				'wi_no_binned_copy',
				__( 'That copy is not in the bin.', 'weidea-studio' ),
				array( 'status' => 404 )
			);
		}

		if ( self::staged_id( $post_id ) ) {
			return new WP_Error(
				'wi_newer_copy',
				__( 'There’s a newer copy of this page now, so the old one can’t be brought back.', 'weidea-studio' ),
				array( 'status' => 409 )
			);
		}

		if ( ! wp_untrash_post( $staged_id ) ) {
			// Trash switched off means rest_discard() moved the status by
			// hand and wrote no _wp_trash_meta_status, which some core
			// versions treat as nothing to untrash. Put it back directly.
			wp_update_post(
				array(
					'ID'          => $staged_id,
					'post_status' => 'draft',
				),
				true
			);
		}

		// Core's default for an untrashed post is 'draft', which is what
		// staged_id() wants — but wp_untrash_post_status is filterable, and
		// a site that filters it to 'publish' would put a duplicate of the
		// page on the public web. Verified rather than trusted.
		$restored = get_post( $staged_id );
		if ( $restored && ! in_array( $restored->post_status, array( 'draft', 'pending' ), true ) ) {
			wp_update_post(
				array(
					'ID'          => $staged_id,
					'post_status' => 'draft',
				)
			);
		}

		return rest_ensure_response(
			array(
				'restored'  => true,
				'staged_id' => $staged_id,
				'post'      => $post_id,
			)
		);
	}

	/**
	 * Is this post a staged copy? The forward question, asked in one place.
	 *
	 * `staged_id()` answers the INVERSE — given a live post, find its copy —
	 * and it cannot serve here, because it filters on COPY_STATUSES and the
	 * whole job of the guard is to catch a copy on its way OUT of them.
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	public static function is_staged_copy( $post_id ) {
		$post_id = (int) $post_id;
		if ( $post_id <= 0 ) {
			return false;
		}
		return '' !== (string) get_post_meta( $post_id, self::META_KEY, true );
	}

	/**
	 * ⛳ FINDING #88(a), MECHANISM ONE — THE SENTENCE.
	 *
	 * Refuse a REST save that would take a staged copy out of COPY_STATUSES,
	 * and say one plain thing about it naming the real door.
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * WHY THIS HOOK CARRIES THE SENTENCE AND THE OTHER ONE CANNOT.
	 *
	 * MEASURED on the running WordPress 7.1, September 24 2026, by recording
	 * every save hook that fired on each road:
	 *
	 *   REST     rest_pre_insert_<type> · wp_insert_post_data ·
	 *            pre_post_update · transition_post_status
	 *   NON-REST                          wp_insert_post_data ·
	 *            pre_post_update · transition_post_status
	 *
	 * So this filter sees the editor's own save and nothing else — but it is
	 * the only one of the two whose WP_Error core turns into a response the
	 * editor SHOWS. `wp_insert_post_data` can show nothing at all: core takes
	 * its return value straight to `wp_unslash()` and the database with no
	 * `is_wp_error()` check (wp-includes/post.php, read on the running 7.1),
	 * so a WP_Error returned from there is treated as an array and the save
	 * proceeds. That is why there are two mechanisms rather than one, and why
	 * neither is redundant.
	 *
	 * ⚑ ONLY WHEN THE STATUS IS ACTUALLY BEING CHANGED. `$prepared` carries a
	 * post_status on plenty of saves that are not about status at all, and a
	 * guard that fired on the copy's every ordinary save would refuse typing.
	 * The test is against what is STORED, so a save that asks for the status
	 * the copy already has is not a change and is not refused.
	 *
	 * @param stdClass        $prepared Post object about to be inserted.
	 * @param WP_REST_Request $request  The request.
	 * @return stdClass|WP_Error
	 */
	public static function guard_rest_status( $prepared, $request ) {
		$post_id = isset( $prepared->ID ) ? (int) $prepared->ID : 0;
		if ( ! $post_id || ! isset( $prepared->post_status ) ) {
			return $prepared;
		}
		if ( ! self::is_staged_copy( $post_id ) ) {
			return $prepared;
		}

		$asked = (string) $prepared->post_status;
		if ( self::status_is_allowed( $asked, $post_id ) ) {
			return $prepared;
		}

		// ⛔ THE AUTOSAVE ROUTE MUST NOT BE HANDED A WP_Error, and this is not
		// a nicety — it silently throws the person's typing away.
		//
		// MEASURED on the running 7.1, found by an adversarial audit of this
		// guard's own first build. `WP_REST_Autosaves_Controller::create_item()`
		// calls the parent controller's `prepare_item_for_database()` — which
		// is where this filter runs — and then does `$prepared_post->ID =
		// $post->ID` with NO `is_wp_error()` check, and casts the object to an
		// array for `wp_update_post()`. A WP_Error cast to an array carries
		// `errors` and no `post_title` or `post_content`, so the stored values
		// are merged back and the edit is gone. The endpoint still answers 200
		// with a normal-looking body: four autosaves were driven, and the two
		// carrying a refusable status kept their status at `draft` and lost
		// BOTH the title and the typing, under HTTP 200 and in silence.
		//
		// Core 7.1's own editor never sends a refusable status on this route
		// (the served `core-data.js` builds the payload as `status:
		// merged.status === 'auto-draft' ? 'draft' : undefined`), so this is
		// not reachable from the editor Chris uses — but the mobile app, any
		// other REST client and any plugin autosaving on the copy all send one.
		//
		// So this road CLAMPS, exactly as the non-REST road does. There is no
		// sentence to deliver on an autosave anyway: nothing is on screen to
		// read it, and the status the person actually chose is refused in
		// full the moment the real save happens.
		$route = ( $request instanceof WP_REST_Request ) ? (string) $request->get_route() : '';
		if ( '' !== $route && preg_match( '#/autosaves/?$#', $route ) ) {
			$stored                 = (string) get_post_status( $post_id );
			$prepared->post_status  = in_array( $stored, self::COPY_STATUSES, true )
				? $stored
				: 'draft';
			return $prepared;
		}

		return new WP_Error(
			'wi_copy_cannot_publish',
			__( 'This is a Workbench copy, so it can’t go live from here — use Deploy to put it on the live page.', 'weidea-studio' ),
			array( 'status' => 409 )
		);
	}

	/**
	 * ⛳ FINDING #88(a), MECHANISM TWO — THE CLASS.
	 *
	 * Put the status back on ANY road that would take a staged copy out of
	 * COPY_STATUSES. This one sees both roads — Quick Edit, bulk edit,
	 * WP-CLI, another plugin, and the editor's own save — and it is what
	 * makes #88 a defect CLASS that is shut rather than a control that is
	 * switched off. #84 shut a button and this second door stood open behind
	 * it; the lesson is written into the guard rather than only into a
	 * comment.
	 *
	 * ⛔ IT CLAMPS, IT DOES NOT ERROR, AND THAT IS NOT A SHORTCUT. Core does
	 * not check this filter's return for a WP_Error, so erroring here is not
	 * available — it would be read as an array and written to the database.
	 * And on the admin form road a refusal could not be shown in any case:
	 * `edit_post()` calls `wp_update_post( $translated )` with no $wp_error
	 * argument, so any error becomes 0 and the person is redirected to an
	 * ordinary "updated" screen. The sentence therefore lives on the REST
	 * road, where it can actually be read, and this road quietly holds the
	 * line. Both halves were measured before either was written.
	 *
	 * @param array $data    Sanitised post data, on its way to the database.
	 * @param array $postarr The raw post array as handed in.
	 * @return array
	 */
	public static function clamp_status( $data, $postarr ) {
		$post_id = isset( $postarr['ID'] ) ? (int) $postarr['ID'] : 0;

		// No ID means this is a CREATE, and a create has no meta row yet —
		// including the copy's own, which rest_stage() passes as meta_input
		// inside the same wp_insert_post() call. Harmless either way: a copy
		// is created as a draft.
		if ( ! $post_id || ! isset( $data['post_status'] ) ) {
			return $data;
		}
		if ( ! self::is_staged_copy( $post_id ) ) {
			return $data;
		}

		$asked = (string) $data['post_status'];
		if ( self::status_is_allowed( $asked, $post_id ) ) {
			return $data;
		}

		// Back to what the copy already held. Reading the stored status
		// rather than forcing `draft` keeps a copy that was legitimately
		// moved to Pending on Pending, instead of silently demoting it on
		// the next unrelated save.
		$stored = (string) get_post_status( $post_id );
		$data['post_status'] = in_array( $stored, self::COPY_STATUSES, true )
			? $stored
			: 'draft';

		return $data;
	}

	/**
	 * ⛳ FINDING #88(a), MECHANISM THREE — THE ROAD THAT WRITES THE ROW ITSELF.
	 *
	 * Put the status back when a staged copy has ALREADY been moved out of
	 * COPY_STATUSES by something neither filter above could see.
	 *
	 * ⛔ WHY A THIRD MECHANISM EXISTS AT ALL, said plainly because the first
	 * build of this guard got it wrong. `clamp_status()`'s comment claimed it
	 * "sees both roads". It does not: `wp_publish_post()` writes `post_status`
	 * straight to the database with `$wpdb->update()` and never calls
	 * `wp_insert_post()`, so `wp_insert_post_data` never fires on it. Read on
	 * the running 7.1, and measured: calling it on a copy took it `draft` →
	 * `publish` with neither guard firing once.
	 *
	 * ⚑ AND IT IS REACHABLE WITHOUT ANYBODY DOING ANYTHING ODD. A copy left at
	 * `future` by a build that had no guard carries an armed
	 * `publish_future_post` event. Upgrading stops new status changes and does
	 * nothing about the armed one: one tick goes
	 * `check_and_publish_future_post()` → `wp_publish_post()` and the copy is
	 * on the public web, at its own URL, invisible to the Pages list. That is
	 * the exact consequence #84 exists to prevent, arriving by a third door.
	 *
	 * THIS ONE REPAIRS RATHER THAN REFUSES, because it runs after the write —
	 * `transition_post_status` is fired once the row has moved. It is the
	 * backstop, not the front door: the REST filter carries the sentence, the
	 * data filter stops the ordinary roads before they land, and this catches
	 * anything that got past both. Three mechanisms, three roads, none
	 * redundant.
	 *
	 * @param string  $new_status The status just written.
	 * @param string  $old_status The status before it.
	 * @param WP_Post $post       The post.
	 */
	public static function repair_status( $new_status, $old_status, $post ) {
		// The repair is itself a save, which transitions again. Without this
		// the two would call each other until the stack gave out.
		static $repairing = false;
		if ( $repairing ) {
			return;
		}
		if ( $new_status === $old_status || ! ( $post instanceof WP_Post ) ) {
			return;
		}
		if ( ! self::is_staged_copy( $post->ID ) ) {
			return;
		}
		// ⛔ NOT status_is_allowed() HERE. That helper forgives a status equal
		// to the STORED one, and by the time this runs the stored one IS the
		// new status — so it would forgive every transition and this
		// mechanism would do nothing at all. The lists are read directly.
		if (
			in_array( $new_status, self::COPY_STATUSES, true )
			|| in_array( $new_status, self::PASSTHROUGH_STATUSES, true )
		) {
			return;
		}

		$back = in_array( $old_status, self::COPY_STATUSES, true )
			? $old_status
			: 'draft';

		$repairing = true;
		wp_update_post(
			array(
				'ID'          => $post->ID,
				'post_status' => $back,
			)
		);
		$repairing = false;

		// A copy rescued FROM `future` still has core's event armed, and it
		// would fire again on the next tick. Clearing it is part of the
		// repair rather than a separate tidy-up.
		wp_clear_scheduled_hook( 'publish_future_post', array( $post->ID ) );
	}

	/**
	 * ⛳ FINDING #88(a) — the scheduled publish, stopped rather than repaired.
	 *
	 * `repair_status()` above would catch this road too, but only after
	 * `wp_publish_post()` had written the row and fired every save action
	 * behind it — `save_post`, `wp_insert_post`, `wp_after_insert_post` — with
	 * the copy momentarily public. Stopping it first is the better of the two,
	 * and it costs one hook: core's own handler runs at the default priority
	 * and returns early unless the post is still `future`, so setting the copy
	 * back at priority 1 means the publish simply never happens.
	 *
	 * @param int $post_id The post core is about to publish.
	 */
	public static function disarm_scheduled_publish( $post_id ) {
		$post_id = (int) $post_id;
		if ( ! self::is_staged_copy( $post_id ) ) {
			return;
		}
		if ( 'future' !== get_post_status( $post_id ) ) {
			return;
		}
		wp_update_post(
			array(
				'ID'          => $post_id,
				'post_status' => 'draft',
			)
		);
		wp_clear_scheduled_hook( 'publish_future_post', array( $post_id ) );
	}

	/**
	 * May a staged copy hold this status?
	 *
	 * @param string $status  The status being asked for.
	 * @param int    $post_id The copy's post ID.
	 * @return bool
	 */
	private static function status_is_allowed( $status, $post_id ) {
		if ( in_array( $status, self::COPY_STATUSES, true ) ) {
			return true;
		}
		if ( in_array( $status, self::PASSTHROUGH_STATUSES, true ) ) {
			return true;
		}
		// A save that asks for the status the copy already has is not a
		// change, and refusing it would refuse ordinary typing on a copy
		// that somehow already sits outside the list.
		return (string) get_post_status( $post_id ) === (string) $status;
	}

	/**
	 * The staged copy's ID for a live post, if one exists.
	 *
	 * @param int $post_id Live post ID.
	 * @return int 0 when none.
	 */
	public static function staged_id( $post_id ) {
		$found = get_posts(
			array(
				'post_type'      => 'any',
				'post_status'    => self::COPY_STATUSES,
				'meta_key'       => self::META_KEY, // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'     => (int) $post_id, // phpcs:ignore WordPress.DB.SlowDBQuery
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		return $found ? (int) $found[0] : 0;
	}

	/**
	 * Signed preview URL: the LIVE permalink plus a token bound to this
	 * specific live/staged pair. Deploy deletes the staged copy, which
	 * kills the link.
	 *
	 * @param int $post_id   Live post ID.
	 * @param int $staged_id Staged copy ID.
	 * @return string
	 */
	public static function preview_url( $post_id, $staged_id ) {
		return add_query_arg(
			'wi-preview',
			self::preview_token( $post_id, $staged_id ),
			get_permalink( $post_id )
		);
	}

	/**
	 * The preview token for a live/staged pair.
	 *
	 * @param int $post_id   Live post ID.
	 * @param int $staged_id Staged copy ID.
	 * @return string
	 */
	private static function preview_token( $post_id, $staged_id ) {
		return substr( hash_hmac( 'sha256', 'wi-preview|' . (int) $post_id . '|' . (int) $staged_id, wp_salt( 'auth' ) ), 0, 32 );
	}

	/**
	 * Serve staged content at the live URL when a valid token is present.
	 * Signed links are shareable by design — the token, not a login, is
	 * the credential, and it dies when the staged copy does.
	 */
	public static function maybe_preview() {
		if ( ! is_singular() || empty( $_GET['wi-preview'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		$post_id   = get_queried_object_id();
		$staged_id = self::staged_id( $post_id );
		if ( ! $staged_id ) {
			return;
		}
		$token = sanitize_text_field( wp_unslash( $_GET['wi-preview'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! hash_equals( self::preview_token( $post_id, $staged_id ), $token ) ) {
			return;
		}

		$staged = get_post( $staged_id );
		if ( ! $staged ) {
			return;
		}

		add_filter(
			'the_content',
			function ( $content ) use ( $staged, $post_id ) {
				if ( get_the_ID() !== $post_id ) {
					return $content;
				}
				// Run the staged markup through block rendering exactly
				// like live content (instance CSS, conditional assets).
				return do_blocks( $staged->post_content );
			},
			0
		);
		add_filter(
			'the_title',
			function ( $title, $id = 0 ) use ( $staged, $post_id ) {
				return (int) $id === (int) $post_id ? $staged->post_title : $title;
			},
			10,
			2
		);
	}

	/**
	 * Keep staged copies out of admin list tables and nav-menu pickers.
	 *
	 * @param WP_Query $query Query.
	 */
	public static function hide_staged_copies( $query ) {
		if ( ! is_admin() || ! $query->is_main_query() ) {
			return;
		}
		$screen_ok = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $screen_ok && 'edit' !== $screen_ok->base ) {
			return;
		}
		$meta_query   = (array) $query->get( 'meta_query' );
		$meta_query[] = array(
			'key'     => self::META_KEY,
			'compare' => 'NOT EXISTS',
		);
		$query->set( 'meta_query', $meta_query );
	}
}
