# Changelog

## 0.3.0-beta.11 — The library learns to move (July 2026, beta track)

Four interactive blocks — **Accordion, Tabs, Off-canvas, Carousel** — and the
fourth and final pass at finding #19. The blocks are the first in this library
with behaviour, so the interesting work was not the widgets: it was deciding
what a visitor gets when the behaviour doesn't arrive.

- **Accordion, Tabs, Off-canvas and Carousel, registry-driven like the other
  14.** Seven block registrations in total: each of the three container blocks
  has a child (`accordion-item`, `tab`, `slide`) that only its parent can
  insert, so the inserter still shows four new things. They inherit everything
  the registry gives: responsive values with override dots, hover bindings, the
  Animate tab, ⓘ learn-in-place popovers and Learn-panel entries compiled from
  required help + demo specs, per-brand token skinning, the branded inserter
  category. 21 schemas, 56 panels, 157 controls now, all CI-gated.
- **The saved markup is the whole document, and the script is a promotion of
  it.** With the view script gone — safe mode, a CDN eating the file, JS off —
  an Accordion is a stack of real headings with their panels open, Tabs is the
  same panels stacked under their own headings, an Off-canvas drawer is its
  content in normal flow, and a Carousel is a plain list of slides. Nothing is
  hidden, clipped or transformed by a stylesheet unless the script has stamped
  `data-wi-ready` on the block, and no control that needs JavaScript is on
  screen before then: a dead button is worse than no button. The roles that
  describe a widget — tablist, dialog, `aria-expanded`, `aria-roledescription`
  — are set by the script, never saved, because asserting them in markup lies
  to a screen reader in safe mode.
- **Accessibility built to the WAI-ARIA APG, and tested by keystroke.** Real
  buttons in real headings with `aria-expanded`/`aria-controls` and regions
  named by their toggle; a tablist with roving tabindex, arrow keys, Home/End
  and automatic activation; a dialog with a focus trap that survives having one
  focusable element or none, Escape, focus returned to the trigger, the rest of
  the page `inert` and scroll locked and restored; a carousel on CSS
  scroll-snap (native swipe, momentum and keyboard scrolling for free) whose
  slides all stay in the accessibility tree, with a pause control whenever
  autoplay is on, autoplay yielding to hover, to focus inside and to a hidden
  tab, and a live region that is `off` while auto-rotating and `polite` when
  the visitor is driving. Reduced motion is honoured live, not just at load:
  autoplay never starts, and scrolling is instant.
- **Zero bytes on pages that don't ask.** Each block's view script is enqueued
  only where the block renders, deferred, and dequeued wholesale by the safe-
  mode kill switch. A page of static WeIdea blocks now has its own e2e proving
  it serves no interactive JavaScript at all. Frontend totals: **10.3 KB JS
  (budget 12) and 10.5 KB CSS (budget 30)** — four widgets for 7.4 KB of
  script, which is what buying the browser's own scrolling instead of a gesture
  library costs.
- **Structure tags: the selected block no longer has one (#19, fourth pass —
  and the first that isn't arithmetic).** The name chip and core's floating
  block toolbar want the same pixels by construction, and three geometric
  dodges each lost to a new real-world case. Planning called the retreat: a
  selected block is already the most-labelled thing on screen — toolbar, solid
  outline, List View highlight — so its chip says nothing anyone needed, and it
  goes away. Tags label UNSELECTED structure. The collision stops existing
  rather than being computed around. Hover is shut too: hovering the block you
  already have selected was the other route to the chip. The toolbar
  step-clear survives for a case the change doesn't reach — the toolbar belongs
  to the selected block, but it can still park over an ANCESTOR's chip.

  The test went to CI first and was watched failing on beta.10: `expected [],
  received "Section"` in all 14 samples, and `["Column","Column","Row",
  "Section"]` with the Row selected. It samples the whole repaint window
  (12 × 120ms, outlasting both the controller's settle budget and its 120ms
  toolbar rect-watch) because right after a selection there is a frame where
  even the broken build has drawn nothing yet — and a retrying matcher would
  have accepted exactly that frame.
- **Counter and Typed have been shipping CSS that never loaded** (found while
  measuring the budget, fixed here). Both imported `style.scss` from `view.js`
  as well as `index.js`, which made webpack extract their CSS to
  `style-view.css` — and `style-index.css` is the only file `WI_Assets`
  registers per block. So the Typed caret's blink animation and the Counter's
  tabular-nums have never reached a visitor's page or the editor canvas. The
  duplicate import also wrapped each view script in ~870 bytes of CSS-loader
  runtime for a stylesheet nothing served: removing it freed 1.9 KB of the
  frontend JS budget, which is what made room for the fixes below.
- **A judge panel before the push caught a defect a green suite would have
  shipped.** The carousel compared the next scroll offset against the track's
  maximum, but each slide gives up one gap of width, so the track's maximum is
  one gap short of the last slide's own offset: at the default gap a
  three-slide carousel bounced between the first two forever with the third
  unreachable, and a two-slide one had a dead Next arrow. The suite was green
  because it reached slide three with a dot click rather than a second Next.
  Also fixed pre-push: translated strings were being baked into carousel
  content by `save()` (a locale change or a second author in another admin
  language turns every carousel into "unexpected or invalid content" — the
  sibling block already refused to do this and said why); an off-canvas drawer
  hidden at a breakpoint while open left the page scroll-locked and `inert`
  with nothing left to press, so it now closes itself when it stops being
  rendered; a one-slide carousel no longer lights up arrows, a dot and a timer
  that can't move anything; and the drawer restores an explicit
  `aria-hidden="false"` it overwrote instead of deleting the attribute.
- **The accordion's heading-level mirror no longer writes on disagreement.**
  One heading level is chosen for the whole accordion, but each item saves its
  own element, and a child's `save()` cannot see its parent — so the level has
  to be mirrored onto the items. Mirroring "whenever they disagree" is exactly
  what an undo lands on: ⌘Z reverts the children while the parent still holds
  the new level, and the effect writes it straight back, leaving a step the
  author can never get past. That is the shape of #25, so the mirror now fires
  only on the two things that are author actions — the level changing here, or
  an item arriving that has never seen it (inserted, pasted, or from the
  template) — tracked as deltas, so a revert is never one of them. **Worth a
  minute of Chris's manual pass: change the level, press ⌘Z twice, and watch
  whether the accordion moves.**
- **Attribute versioning and the deprecation seam from day one.** Every new
  block stamps `data-wi-v="1"` on its root and ships a `deprecated.js` wired
  through `registerWiBlock`. The arrays are empty — v1 is the first saved
  shape, so there is honestly nothing to migrate — but each file documents its
  exact v1 markup contract, which changes count as a new shape, and the
  concrete v2 recipe. The next markup change is the dangerous one; this is
  where it lands instead of in an author's content.
- **In-page links reach hidden panels.** Both Accordion and Tabs hand out
  stable ids, and a collapsed or hidden panel has no layout, so the browser
  scrolls nowhere and announces nothing — the visitor is told the link worked
  and shown the same screen. Both now reveal the owning panel first, on arrival
  and on `hashchange`, via `getElementById` rather than
  `querySelector(location.hash)`, which throws on a hash that isn't a valid
  selector.
- **Tests:** four new e2e suites (~2,600 lines) covering widget behaviour,
  keyboard operability per pattern, focus return and trap edges, duplicate-uid
  pages, untitled panels, the no-JS document, reduced motion, and the
  inspector; plus the #19 symptom tests and the static-page zero-JS guard.

Known and deliberate, recorded rather than fixed: the carousel and off-canvas
stylesheets carry ~1.2 KB of editor-only rules that can never match on a
visitor's page (the CSS budget is comfortable, but the Tabs pattern — an inline
`<style>` written by `edit.js` — is the house answer and they should move to
it); the carousel's `panelBackground`/`panelRadius` should be
`slideBackground`/`slideRadius` to match its neighbours, which now costs a
deprecation entry rather than nothing; a nested Accordion or Tabs inherits its
outer instance's structural styling, because the whole library uses descendant
selectors and making two blocks the exception is a library-wide decision, not a
tranche one.

## 0.3.0-beta.10 — Undo after a drag is safe again (July 2026, beta track, HOTFIX)

Two items, one of them data-destroying. Both were reported green in beta.9;
#19 twice. The tests for both were written and pushed to CI **before** the
fix, so they were watched failing first — a green assertion that has never
been seen red proves nothing, which is the lesson of this pair.

- **Undo after a canvas drag no longer wipes the page (#25, CRITICAL).**
  Drag a margin (⌥ mirroring both sides), press ⌘Z, and *every block
  disappeared* from the canvas and List View — a Kadence Row Layout block
  included, which is what proved the rollback reached past the dragged
  attributes. ⌘⇧Z brought it all back, and so did a reload before saving, but
  a Save while the page showed empty would have persisted an empty page. The
  red-first run reproduced it on ALL FIVE gesture variants, not just margin:
  ⌘Z left `count: 0, shape: "[]"` against an expected 7. beta.9's padding
  test passed only because its fixture was built in-session, leaving undo
  levels behind it; opening a SAVED page is what exposes this, and that is
  what Chris was doing.

  **The mechanism, measured in the editor rather than argued from source.** An
  instrumented run logged the post entity's edit keys around a drag, and they
  tell the whole story. A drag leaves three entity edits — `selection`,
  `blocks` (the parsed tree) and `content` (the editor's LAZY SERIALIZER: a
  function, not a string) — and TWO undo levels. Walking them back: the first
  restores `content` to a string and changes nothing visible, because the
  editor prefers the `blocks` edit; the second drops the `blocks` edit, at
  which point the editor falls back to `content` — a string by now —
  reparses, and the dragged value is gone. Two presses, document intact.

  That ordering is load-bearing, and beta.9 destroyed it. Its synthesised
  commit — `__unstableMarkLastChangeAsPersistent()`, a persistence FLAG with
  no block change — collapsed the gesture into a single level of the second
  kind. ⌘Z then dropped the `blocks` edit while `content` was STILL the lazy
  function, so the editor tried to derive the document from a content value
  that wasn't content yet, and got nothing. That is the wipe: not a
  whole-page rollback, as the finding reasonably inferred, but a document
  derived from a function.

  **The fix is a retreat, and planning called it correctly.** All the
  coalescing machinery is gone: the `persist: false` marking on every
  intermediate write, the synthesised commit that had to follow it, and two
  further attempts to keep one-step undo (closing the gesture on a scoped
  `UPDATE_BLOCK`, then also re-seating the selection so core-data would keep
  the record). Each of those fixed the wipe and each left ⌘Z with nothing to
  revert, because each was still contriving a history entry instead of
  letting one happen. A drag now dispatches plain `updateBlockAttributes`
  calls — byte-identical to a value typed into the inspector — and whatever
  history Gutenberg makes of them is what a drag costs.
- **A drag now costs about two ⌘Z presses, not one (deliberate).**
  One-undo-per-drag was a beta.9 nicety; planning dropped it rather than let
  it keep a page-wipe alive, and it may return later as a QoL item. Today the
  first press after a drag can look like it did nothing — it is normalising
  `content` — and the second reverts the value. Worth knowing before it reads
  as a bug. Save still lights on a drag-only edit, the close-tab warning
  still fires, and the value still survives save + reload: #18a/b are
  asserted per variant, not assumed.
- **Every gesture variant is now under test (#25's other half).** The #18
  test drove a single-side padding drag on a post built in-session and
  asserted only that the value reverted — so a margin ⌥-mirror on a
  reloaded page went untested, and "the value reverted" never asked whether
  the rest of the document was still there. `drag-undo-variants.spec.js`
  enumerates padding single-side, margin with the ⌥ mirror, Section
  min-height, column-divider drag and the divider's one-gesture reset; for
  each it asserts the value reverts on ⌘Z, **the total block count and the
  whole name/nesting shape are unchanged**, ⌘⇧Z restores, Save lights, and
  the edit survives save + reload. The fixture opens a saved page whose
  first block is foreign to WeIdea, so a whole-page rollback has nowhere to
  hide.
- **Structure tags are readable again, proven geometrically (#19, third
  attempt).** The first two fixes were reported green and failed by hand,
  and the red-first run of this one explains why — including why the
  assertion this fix was *asked* for would have failed by hand a third time.
  - The old test polled "no intersection" until true, and `expect.poll`
    passes on the first satisfying iteration, so one frame caught before the
    popover finished positioning greened a build whose resting state
    overlapped. Assertions now settle (tag and toolbar rects read together
    until two consecutive reads agree) and then assert once.
  - **The settled tag-vs-toolbar assertion passes on the BROKEN build.**
    beta.9's dodge does clear the toolbar — it drops the chip to exactly the
    toolbar's bottom edge, which a strict rect test calls clear. The
    failure screenshots show what is actually wrong: a Section, its Row and
    that Row's first Column share a top-left corner, so all three chips
    live in the same 16px band, and the two that dodged land on top of the
    one that didn't. Only the chip painted last (Column) is legible; the
    Row's chip is buried under it. So the invariant is wider than "clear of
    the toolbar": no tag may be covered by the toolbar **or by another
    tag**, and that is the half that catches this.
  - Tags therefore step clear of both. Every visible toolbar instance is
    measured now, not `querySelector`'s first match — that can be a dormant
    zero-size instance while the live popover sits later in the DOM, which
    measures as "no toolbar" and dodges nothing. Placement is redone
    whenever the toolbar's geometry changes (a 120ms rect watch that spends
    a frame only when something moved) rather than for a fixed 8 frames
    after a selection change, so a toolbar arriving after a List View
    selection scrolls the canvas is no longer missed. Each chip then steps
    sideways past the chips already placed that frame, which spreads a nest
    into a readable run instead of a pile. The dodge works from the tag's
    *measured* rect rather than the block's left edge plus
    `offsetWidth || 0` — that spare 0 quietly turned the horizontal test
    into "no collision".
  - e2e covers a top-level Section and a Row nested in a Section selected
    from List View (the reported case), asserting no tag intersects any
    toolbar or any other tag. List View collapses nested levels by default,
    so the test expands the Section first — the first attempt at this test
    timed out on a Row link that was not in the DOM yet.

## 0.3.0-beta.9 — Canvas drags are real edits (July 2026, beta track)

A data-integrity headline and three canvas-clarity fixes, all from Chris's
first real design session on beta.8.

- **A canvas drag now marks the document dirty (#18, HIGH).** After a
  box-model drag the Save button stayed disabled, so a page edited only by
  dragging could be closed with no unsaved-changes warning: silent data
  loss. Every write inside a drag is deliberately coalesced (one undo step
  per gesture) — but the block-editor reducer *independently* marks a
  change non-persistent when it repeats the same attribute on the same
  block as the action before it, which the drag's final commit always does.
  With no persistent change anywhere in the gesture, `useBlockSync` only
  ever called the editor's `onInput`, which writes transient entity edits
  and never the `content` serializer that makes a post dirty. The final
  commit now writes coalesced and closes the gesture with one
  `__unstableMarkLastChangeAsPersistent()` — the path `useBlockSync` is
  built for — so the post goes dirty, Save enables, the close-tab warning
  fires, and the whole drag still costs exactly ONE undo step. Column
  divider drags used to spend two undo steps; they now spend one. The same
  commit closes double-click-to-reset, which could be swallowed the same
  way. Three new e2e: drag → `isEditedPostDirty` + Save enabled; drag-only
  edit survives save + reload; one undo restores the pre-drag value and
  stops there.
- **List View highlight no longer bleeds above the block (#20).** Hovering
  or selecting a Section/Row/Column in List View painted a block-sized
  region ABOVE the block, over the page title. Not a margin-box artifact: a
  pseudo-element collision. Core paints that highlight (and the focus ring,
  and the multi-select tint) as `::after { content:""; inset:0 }` on the
  block — and WeIdea's block-name chips were on the *same* `::after`. An
  element has only one, so the rules merged into a single box that kept
  core's block-sized geometry but took the chip's color and its
  `translateY(-100%)`. The name tags are now drawn as elements in WeIdea's
  own canvas overlay, so every core pseudo-element is left untouched and
  the highlight is exactly the block's border box.
- **Structure tags step clear of the block toolbar (#19).** Now that the
  tags are overlay-drawn, the controller measures core's floating block
  toolbar (mapping its rect from the editor document into iframe
  coordinates) and pushes any tag it would cover down just far enough to
  clear it — which lands the tag just inside the block's top edge in the
  usual case, and leaves it alone when the toolbar is flipped below.
- **"Show block structure" → "Show layout outline" (#17).** The old label
  read as WordPress jargon and cost two searches. Renamed in both ⋮ menu
  slots, the ⌘K command, and the shortcut description; e2e asserts the new
  wording everywhere and that the old wording is gone. The preference key,
  command name and body class keep their identifiers on purpose — renaming
  the stored key would silently reset the toggle for anyone using it.

## 0.3.0-beta.8 — Editor WYSIWYG parity, honest demos everywhere (July 2026, beta track)

With the front-end render fixed in beta.7, this pass closes the gap between
what the editor shows and what ships, and finishes two items that were
marked closed but failed the manual pass — with e2e that asserts BROADLY,
mirroring what a human actually sees, so a single passing assertion can't
mask a broken feature again.

- **Editor canvas matches the front end (#16).** Instance styles are
  emitted into both render paths from the same schema, but inside the
  editor iframe a single scoped class (`.wi-heading-<uid>`) tied or lost to
  the theme's `.editor-styles-wrapper` rules — so a heading's text color
  painted on the published page yet stayed the theme default (black) in the
  editor. The editor emission now doubles the scoped class so its rules win
  the cascade against theme editor styles; the front-end/PHP path is
  unchanged (it already wins there). New e2e asserts the editor-canvas
  computed color + size EQUAL the front-end computed values.
- **Learn-in-place demos render real content on every panel (#4,
  reopened).** Only Animate showed a live demo on the installed build;
  appearance panels whose only change is text (a color, a size) painted it
  onto an empty box, reading as the same gray skeleton. Text panels now draw
  a real type specimen; the truly abstract panels get DISTINCT schematics —
  a device row with the hidden size struck out (Visibility), a layered
  stack (Advanced/z-index) — never the identical empty box. e2e now
  enumerates every panel and asserts a variety of compiled/schematic/motion
  content, not one.
- **Show-structure is in the ⋮ More menu (#15, reopened).** The toggle
  shipped a ⌘⇧O shortcut and ⌘K command since beta.6, but its menu item was
  registered only against the modern editor's slot; older post-editor
  headers render a different slot, so it never appeared. It now fills both
  slots and is discoverable without a keyboard shortcut (⌘⇧O + ⌘K kept).
- **"Section with columns" variation icon is brand orange (#8, reopened).**
  The earlier fix set `fill` on the `<svg>` element, which the editor's
  global `svg { fill: currentColor }` overrode to black in the real
  inserter. It now uses the same object-icon + `foreground` shape as the
  block icon, and e2e asserts the tile glyph computes to the brand orange.
- **Touch ID deploy e2e de-flaked.** Explicit visibility/enabled waits with
  widened timeouts around the admin-bar launch, the staged iframe, and the
  deploy button, so the WebAuthn ceremony stops racing an incompletely
  wired handler (third recurrence, CI #52).

## 0.3.0-beta.7 — Frontend-render delivery, honest demos, steppers, polish (July 2026, beta track)

Two functional fixes lead, then a polish sweep.

- **Per-instance CSS delivery, consolidated and out of the body (#14).**
  Saved design not painting on some live pages was traced to an HTML
  minifier / CSS combiner (SiteGround Optimizer, Cloudflare) stripping the
  inline `<style>` tags WeIdea emitted before each block — the code path
  itself is correct (proven by a new logged-out guardrail run against the
  release zip). Instance CSS is now collected as blocks render and printed
  as a SINGLE consolidated stylesheet in `wp_footer` — after every block
  stylesheet, so equal-specificity instance rules still win by order —
  instead of the many small inline `<style>` tags the old path wove in
  before each block. One consolidated stylesheet is what an HTML minifier /
  CSS combiner leaves intact. **Frontend armor:** `render_block` now
  guarantees the
  scoped `wi-<block>-<uid>` class is on each block's root element (via
  `WP_HTML_Tag_Processor`), resolving the uid as persisted `uniqueId` → uid
  already in markup → a deterministic derivation — so instance CSS always
  has a hook and content saved without a uniqueId self-heals.
- **Learn-in-place demos render real subjects (#4).** Appearance-only panels
  (Section→Background, Icon) had painted their effect onto a neutral
  skeleton box, so a color or an icon showed nothing. The Icon demo now
  draws the actual glyph at the example size/color, and background demos
  paint the composed gradient/image + overlay as the box itself (the
  Section→Background example gained a gradient + overlay to showcase the new
  controls). New e2e asserts the demo compiles a real gradient, not a
  skeleton.
- **Numeric steppers everywhere (#6).** The size control — registered once,
  so every numeric field inherits it — grew ▲▼ nudge buttons (Shift = ×10)
  beside the unit input, keeping native ArrowUp/Down; both write through the
  same responsive path as typing and the canvas drag handles, live per tick.
- **Polish (#7–#13):** a curated WeIdea color palette in the pickers (hides
  the bridged utility slots like "Notices - Warning"); US-English spelling
  with a lint rule; a brand-orange "Section with columns" variation icon;
  quiet selection states that keep an empty column's placeholder legible;
  a row layout-picker gap; standalone-label spacing; Mac ⌥/⌘ modifier
  labels on the drag chips.
- New guardrails: a logged-out real-editor render test (drives the editor,
  publishes, asserts computed styles for a cookie-less visitor at nested
  section + column level) closing the class of bug behind #14, plus a
  numeric-stepper e2e.

**#14 stays open pending staging3 verification** — closure gates on the
beta.7 plugin painting on staging3 with SG Optimizer (Minify HTML / Combine
CSS) and Rocket Loader still ON.

## 0.3.0-beta.6 — Canvas drag affordances (July 2026, beta track)

Section/Row/Column parity, part 2 (per docs/weidea-studio-parity-spec.md,
Part 2). Direct-manipulation on the canvas — an editor-only layer that
adds **zero frontend bytes** (a new `canvas:check` CI gate greps the built
visitor assets for canvas markers and fails on any leak). Every drag
writes through the SAME `writeResponsiveValue` the inspector uses — one
attribute, two hands, never two systems.

- **Show structure** — a wireframe toggle (⌘K command, More-menu item, and
  a real ⌘/Ctrl+Shift+O shortcut) dims a dashed outline over every WeIdea
  block boundary. Hover shows a dotted outline + a block-name chip; the CSS
  lives inside the editor iframe.
- **Box-model handles** — the selected block gets draggable edges:
  padding (green, inside), margin (orange, outside), and Section min-height
  (blue, on the bottom edge), with a live value chip, a devtools-style
  fill, and spacing-scale snap ticks. Cmd/Ctrl bypasses snap, Shift steps
  by 8, Alt mirrors the opposite side (and un-mirrors cleanly on release).
  A drag writes only the ACTIVE device and lights that device's override
  dot; double-click resets to inherited.
- **Column dividers** — drag the boundary between two columns to
  redistribute the pair's width (device-aware, clamped so neither column
  can collapse or go negative).
- Grabs are movement-gated (a click never materialises an inherited value
  into a hard override), drags coalesce into ONE undo step, interrupted
  drags (pointercancel / lost capture) clean up, and handles survive editor
  iframe swaps. Snap targets source the theme's `spacingSizes`
  (px/rem/em), falling back to the house scale.
- New load-bearing e2e: structure toggle via the real shortcut + a
  bottom-padding drag proving the device-aware write, the override dot, and
  per-device independence.

## 0.3.0-beta.5 — Section/Row/Column parity, part 1 (July 2026, beta track)

Muscle-memory parity with the Kadence Row Layout controls (per
docs/weidea-studio-parity-spec.md, Block 1), so building the Mall in
WeIdea never forces a fallback. All registry-driven with help + demo
specs (CI-enforced); colours token-first.

- **Backgrounds** — image (focal point, size, repeat, scroll/fixed
  attachment), structured gradient, and a per-breakpoint overlay (colour
  or gradient, opacity, blend mode). A typed, validated composer emits
  pure CSS: the overlay is a `::before { z-index:-1 } + isolation:isolate`
  pseudo-element, so it needs no markup change and works on Column (no
  inner wrapper) as well as Section. Every injection vector is covered by
  composer unit assertions.
- **Full box model** — four-side responsive padding + margin (logical
  properties), min-height + vertical content alignment, section
  text/link/link-hover colour, border/radius/token-based shadow, column +
  stacked-row gutters, collapse-order reverse, semantic HTML tag, z-index,
  device visibility, and an Advanced-fold custom-CSS box.
- **Insert-time layout picker** — an empty Row offers a 1–6 column layout
  picker, plus a Section → Row → Columns variation.
- Zero frontend-JS cost: new controls are editor-only weight; backgrounds
  are generated CSS. Frontend budget unchanged. No block deprecations.
  New control types: media, gradient, overlay, visibility.

## 0.3.0-beta.4 — Polish + guards (July 2026, beta track)

- **ⓘ popover footer spacing** — the "Apply an example" button and
  "Open the Learn panel" link were crowded; the actions row now has a
  comfortable gap, padding above, and a hairline separator from the demo.
  Component-level, so every panel popover is fixed at once.
- **Inserter ordering** — WeIdea Studio is forced to the TOP block
  category (block_categories_all at priority 99999, dedup + unshift),
  above Kadence on the coexisting pilot. (Landed on main after beta.3;
  first release to carry it.)
- **Two new release gates**, beside registry-coverage and budget:
  docs-currency (CHANGELOG + build-status must reference the version
  being released) and brand-casing (fails on the mis-cased "Weidea" —
  the brand is "WeIdea", capital I). No mis-cased strings exist today;
  the guard keeps it that way.

## 0.3.0-beta.3 — Learn-in-place v1 (July 2026, beta track)

*Reprioritized ahead of interactive blocks by planning: the ⓘ system is
for learning the tool while building with it — which is happening now.*

- **The ⓘ system on every panel** — a ghost-quiet affordance (brightens
  on hover/focus, keyboard-reachable) opening a popover with: the
  plain-English what-this-changes sentence; a **live demo compiled from
  the panel demo spec by the real engine** (before/after preview for
  style panels, looping entrance for motion panels); **Apply an
  example** dropping starter values into the controls; and the Learn
  panel door. While open, the affected block highlights on the canvas.
- **Preset previews** — the Animate tab Entrance control is now a tile
  grid; hovering any tile plays a live mini-loop of the real effect
  before you apply it.
- **Learn panel v1** — a searchable sidebar auto-generated from every
  registry schema (14 blocks, 23 panels, 62 controls with their help).
  Generated from the source of truth: it cannot drift and cannot be
  somewhere else.
- All editor-only weight; visitor budgets unchanged.

## 0.3.0-beta.2 — First motion effects + foundation hardening (July 2026, beta track)

- **Counter** — climbs to its figure on first sight (per-block ~1 KB view
  script, loaded only where the block renders; markup saves the FINAL
  number for no-JS/SEO; reduced-motion keeps it still).
- **Marquee** — the endlessly gliding ribbon, pure CSS, ZERO JavaScript;
  screen-reader-safe duplicate run; speed/direction controls;
  reduced-motion stands still.
- **Typed Text** — typewriter heading cycling one-phrase-per-line, with
  standing lead, typed-part color, and true heading levels; first phrase
  saves as a complete sentence.
- New registry control types: text, textarea (six total).
- Safe mode now dequeues every block view script generically.
- **Foundation hardening** (planning pass): device list centralized to one
  ordered, filterable source (N-breakpoint-ready, no content migration);
  UID claims seed from the whole document (duplicate/paste-safe, e2e
  covered); registry CSS emits logical properties (RTL ~free); textdomain
  + script translations + runtime registry-string gettext; uploads/weidea/
  established; uninstall removes plugin data only — never content.

## 0.3.0-beta.1 — The Animate tab (July 2026, beta track)

- **Animate tab on every WeIdea block** — Tier 1 of the headline motion
  module. Entrances (fade, rise, slide from left/right, grow, blur into
  focus, wipe across/upward), speed and delay in plain English, "reveal
  children one by one" stagger, and hover lift/grow. Defined once as a
  shared registry panel; present on all 11 blocks.
- **Motion tokens v1** — `--wi-motion-*` (house easing curve, three
  durations, stagger rhythm, travel distance). Every preset rides them;
  brand zones can override them for per-brand motion personalities.
- **No-bloat discipline**: animation never touches saved markup (classes
  stamped at render — zero block deprecations); the whole runtime is a
  ~1.5 KB dependency-free IntersectionObserver helper + ~2 KB CSS loaded
  only on pages that animate; no-JS visitors lose nothing; visitors who
  prefer reduced motion get fade-only; safe mode renders everything
  static instantly.
- Editor: live "Preview entrance" replaying the real engine's classes on
  the canvas.

## 0.2.0-beta.2 — Touch ID deploys + branded inserter (July 2026, beta track)

- **WebAuthn (Touch ID) deploy ceremony** — register a passkey under
  Settings → WeIdea Studio; the workbench Deploy button confirms with
  Touch ID and falls back to the typed key. Verified entirely
  server-side (audited minimal CBOR decoder, COSE ES256/P-256 → PEM,
  OpenSSL signature check, challenge/origin/rpId/UV validation) — zero
  third-party dependencies. e2e drives the full ceremony against a
  virtual platform authenticator on every release.
- **One branded inserter home** — a "WeIdea Studio" category (first in
  the list) plus a block collection on the weidea/ namespace with the
  brand mark; all blocks grouped together, nothing in WP's default
  categories.
- Fix: workbench Deploy/Preview clicks landing before staging resolved
  were silently dropped; they now queue.

## 0.2.0-beta.1 — Phase 1 core (July 2026, beta track)

- **The block library** — the full v1 layout + content set, all
  registry-driven with help text and demo specs on every panel (37
  controls): Section, Row, Column (responsive widths, stack-on-phones
  honoring the site's configurable breakpoints), Advanced Heading, Text,
  Buttons/Button (hover-state color bindings), Image, Icon (curated
  inline-SVG set), Spacer, Divider. Every WeIdea block icon carries the
  dark-orange brand mark.
- **The workbench** — admin-bar button + ⌘E on any editable live page
  opens a full-screen overlay with the real block editor on a STAGED
  copy. Loader ships to logged-in editors only; visitors get zero bytes
  (e2e-verified against a logged-out context).
- **Staged deploys** — edits land on a hidden staged clone; a signed
  preview link renders staged content at the real live URL (and dies on
  deploy). The deploy ceremony: dedicated `wi_deploy` capability, typed
  deploy key (hashed at rest, failures rate-limited), live content
  snapshotted as a tagged rollback point, SiteGround cache purged when
  present, who/when/what audit log, one-click rollback. (The WebAuthn /
  Touch ID ceremony lands on this same endpoint in the next beta.)
- **Safe-mode kill switch** — Settings toggle + admin-bar badge +
  query-param override; disables WeIdea frontend JS site-wide.
- **Settings → WeIdea Studio** — breakpoints, release channel, deploy
  key, safe mode.
- Registry engine: new control types (select, toggle), hover-state CSS
  bindings, value templates, and breakpoint-aware runtime rules.

## 0.1.0 — Phase 0 scaffold (July 2026)

- **Control registry core** — inspector panels render from JSON schemas in
  `registry/blocks/`; the server generates CSS from the same files. Every
  panel and control carries a plain-English label and help text, enforced
  in CI (`npm run registry:check`).
- **Design tokens** — `--wi-*` custom properties with the Kadence palette
  bridge (`--wi-accent` → `--global-palette1`, etc.), so blocks re-skin per
  brand zone through the pilot site's existing body-class remaps.
- **Section proof block** — `weidea/section`, with registry-driven
  Background / Spacing / Content width panels, independent
  desktop/tablet/phone values with inheritance and override dots, and
  site-configurable breakpoints (`wi_breakpoints` option, REST-exposed).
- **No-bloat contract enforcement** — zero assets on pages without WeIdea
  blocks (e2e-verified), per-block conditional loading, CI budget gate with
  numbers written into every release.
- **Self-hosted update channel, two-track** — manifest-based updater
  (12-hour cache, the plugin's only outbound call) serving `stable` and
  `beta` tracks; each site picks its channel on the Plugins screen or via
  REST (`wi_update_channel`). The manifest retains recent releases, and
  the plugin row offers **one-click rollback** to the previous retained
  version through WordPress's native upgrade flow. Detection, channel
  switching, install, and rollback are all covered by the e2e suite
  against a locally served channel.
- **Tooling** — `@wordpress/scripts` build, wp-env disposable WordPress,
  Playwright e2e harness, GitHub Actions CI, versioned release zip.
