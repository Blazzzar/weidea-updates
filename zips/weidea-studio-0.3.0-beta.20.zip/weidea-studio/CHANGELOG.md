# Changelog

## 0.3.0-beta.20 — the editor opens again (August 2026, beta track)

*A single fix, shipped on its own. **Nothing your pages have stored changes**,
and nothing else rides along with it.*

### Every page opened to "The editor has encountered an unexpected error" (#79)

On the staging site, beta.19 could not open a page for editing at all — not an
existing one, not a brand-new blank one. The editor replaced itself with an
error message every time.

The cause was a piece of our own code being too quick off the mark. When you
open a page, WordPress builds the editing area inside a frame of its own, and
it does that in two beats: the frame arrives first, and the page inside it a
moment later. Our code was reaching in on the first beat, when there was not
yet anything there to reach for, and falling over.

It now waits for the second beat. If it looks and the page is not ready, it
says "not yet" instead of falling over, and a check that runs once a second
picks it up as soon as the page is there. On your staging site that wait is
longer than it sounds — the editor there loads Kadence, WooCommerce and the
rest before it finishes building the page — which is exactly why this bit you
and not the test machines.

Two things worth knowing, because they explain why this reached you at all:

- **It was happening everywhere, all along, including on the test machines.**
  The same stumble happened on every single editor open, on every version we
  have shipped for a while. On the test machines it was harmless — the editor
  shrugged it off and carried on — so nobody saw it. Your site runs a newer
  WordPress than the test machines do, and on that one the stumble lands at a
  moment WordPress takes seriously, so it shows the error screen instead. We
  reproduced both: the older WordPress throws quietly, the newer one shows
  your exact error message, and the fix clears it on both.
- **Our test suite could not have caught it.** All 650 checks watch what the
  editor *does*; none of them were listening for the editor *complaining*. A
  new check now listens, and it fails on the old code — we watched it fail
  before we fixed anything.

### The "nothing to move yet" note comes back (found while fixing #79)

Fixing the crash brought something else back with it. When the editor stumbled
it stopped part of WordPress's own work mid-flight, and the page it drew was
slightly shorter than the real one. One small note read the page's height to
decide what to say: under **Content position**, the line that tells you
"Nothing to move yet — this column is the same height as what's in it."

With the crash gone the page is drawn properly, and that note started staying
quiet when it should have spoken. It was measuring a column against the wrong
thing — it ignored the space above and below a paragraph, and it counted the
little "add a block" button that sits at the bottom of every column, which is
part of the editor rather than part of your page. It now measures the actual
contents, so the note appears exactly when there is genuinely nothing to move,
and stays away when there is.

### Also in this release

WordPress 7.1 is now listed as the version we have tested against, which is
what the staging site runs.

## 0.3.0-beta.19 — control chrome v2 (August 2026, beta track)

*The design half of the beta.17 sweep, built as one tranche: the spacing
control redrawn, the help text on a diet, and the little round "put it back"
arrow reaching every colour in the plugin. **Nothing your pages have stored
changes.** Every value you have already set stays exactly as it is, in the same
units, and no page is re-saved by any of this.*

### "Space inside" and "Space outside" are now **Padding** and **Margin** (#57)

Those were the two plainest-English labels in the plugin, and they were the two
that kept sending people to the wrong control. Every other name in the plugin
stays in plain English; these two go back to the words the rest of the web uses,
because a person laying out a page has almost certainly met them before and
"space inside" is only obvious once you already know which inside.

### The four-box spacing control, redrawn (#59, #58)

Each of the four little boxes now carries its side's name **inside** it — TOP,
RIGHT, BOTTOM, LEFT — above a thin line, with the number underneath. The mark
showing which side you are editing is **one whole edge of the box drawn
heavier**: the top edge on the TOP box, the left edge on the LEFT box.

The small right-angled corner brackets are gone. They were drawn to suggest a
corner of a rectangle, and on a control about four separate sides that was the
wrong picture — the same shape drawn four times, rotated, telling you nothing
about which side you were on.

The two headings also stopped breaking onto a second line.

### Close the chain and you get one slider, not four boxes

Linking the sides used to give you one wide box. It now gives you a **slider and
a number box**: drag for the feel of it, type when you know the number.

When the four sides do not agree and you close the chain, the box shows **TOP's
number** with a line saying *"Sides still differ until you move this."* It used
to go blank and say "Different on each side", which told you there was a problem
without telling you what any of the sides actually were.

### Preset sizes, or your own number (#60)

There is a new small button with two sliders drawn on it, in the title line
between the screen-size icons and the chain. Press it and the sizes move **in
tens, from 0 to 120**. Press it again and you can type anything you like.

**A number you have already typed never changes when you press it** — in either
direction. Switching to presets with a 37 in the box leaves the 37 alone; it
simply will not let you type a new number that is not a ten. If you try, it says
so and names the number it did not use, rather than silently rounding it.

In preset mode the little unit box is not drawn at all, because presets are a
pixels idea. Your own sizes keep it.

### One short line of help under a field, and the rest behind the ⓘ (#62)

You photographed a control carrying four lines of grey explanation and ruled:
under a field, one short line. That reached **128 of the plugin's 167** help
sentences — the old median was 79 characters — so this was not a tidy-up of a few
long ones. It was a whole layer written to a different brief.

**Nothing was deleted. It moved.** Everything that no longer fits under a field
is now behind the **ⓘ** button at the top of that panel, listed under the
control's own name.

### The reset arrow is your own mark now (#63)

The small "put it back" arrow is the shape you drew on 17 August, on every panel
of every block: a solid arrowhead pointing left, a bar running right behind it,
a U-turn down the right-hand side and a bar back along the bottom. One closed
outline, one weight, no ring.

It replaces the circular one that shipped before — and it also replaces the
three dashed-circle drafts that had been prepared for you, all of which you
turned down on the same day.

### The orange dot keeps its distance (#67), and leaves the boxes (E-V2-16)

The little orange dot that marks "this screen size has its own value" used to
sit on top of the device icon. It now sits just clear of it with a ring of white
all the way round.

And it is **gone from the four spacing boxes entirely**. On the small boxes the
dot wanted the same corner as the new heavy edge mark, and one of the two had to
go. On Tablet you can now see *that* something is overridden but not *which*
side — that is a real loss and it was accepted knowingly rather than missed.

### Every colour box has the arrow, and the word "Clear" has gone from inside the picker (#66)

All 36 colour controls now carry the same small round arrow as everything else,
top left, just before the name. It only appears when a colour is actually set.

The worded **Clear** inside the colour picker is gone with it. It used to sit
there whether or not you had picked a colour — pressing it when nothing was set
did nothing at all — and where something was set it did the same job as the
arrow. One way back now instead of two, and the colour panels are each about
half an inch shorter for it.

**Gradients and overlays keep their "Clear".** There it is the only way to empty
one colour without deleting the whole gradient or overlay.

One thing worth a look: setting a colour shifts the picker right by about a
quarter of an inch to make room for the arrow, so the nine colour circles re-wrap
from six-and-three to five-and-four. Every dropdown and text box in the plugin
has done that since beta.17; it is just more obvious on a grid of circles.

### Smaller things in the same tranche

- **Nothing extra marks a box measured in a different unit** (#73). A box set in
  `%` on a control whose others are `px` shows its full value — `50%` rather than
  a bare `50` — and that is the whole signal. A dashed border had been drawn for
  it, saying "this is odd" without saying what was odd.
- **The ▲▼ arrows beside a number sit centred on the box everywhere**, not just
  on the one field this was checked on last time (#53). The cause turned out to
  be 16px of invisible space that a WordPress component adds underneath every
  size field: the arrows were being centred correctly, but on a box the browser
  thought was taller than it looked. Every size control in the plugin was eight
  pixels out; the one field the last release was verified against happens not to
  use that component, which is why it looked right.
- **Three labels changed** where shortening the help underneath could not have
  rescued them (E-V2-20).
- **Four grey help lines were reworded a second time** (#77). Once a control has
  the little arrow, the arrow takes about a quarter of an inch from the left, and
  four sentences that fitted on one line before then ran onto a second — which is
  the one-line rule this release is built around. They were measured on screen
  with a value set, not counted by hand: the count got two of the four wrong.

### Under the bonnet, and it is why the counts in this release can be trusted

Crossing a spacing control with the Tab key takes more places to land than it
used to — the two new controls each cost one. Every one of those counts is now
declared and checked on **every screen size and in both size modes**: thirty-two
of them, each printing the name of every place the outline lands beside its
count. Before this release nothing checked past Desktop at all, and the single
check that did leave Desktop asked only "is it at most the budget" — under which
a control quietly *losing* half its controls would have passed. **A drop now
fails the build.**

## 0.3.0-beta.18 — the bug batch (August 2026, beta track)

*The defects from Chris's beta.17 full sweep, plus the two the sweep could not
have seen. Nothing your pages have stored changes; no new settings appear. The
sweep's other returns — the Kadence-alignment batch — are a design pass of their
own and are deliberately NOT in here.*

### A "Check for updates" link on the plugin's own row (#26)

WeIdea asks its update channel once every twelve hours, so a release could land
and this site would not notice until the next morning. Until now the only way to
make it look again was to switch to the other channel and switch back.

There is now a **Check for updates** link on the WeIdea Studio row of the
Plugins screen. It forgets what it knew, asks the channel there and then, and
comes back with a sentence: an update is waiting, this site is current, or the
channel could not be reached. That last one is its own message on purpose —
"you're up to date" after a failed request would be a claim the plugin has no
way to take back.

### The little round arrow says the right thing on Tablet and Phone (#64)

Set something on Tablet that Desktop does not have, and the arrow beside it used
to say *"back to the house default"*. That is the sentence for a setting with
nowhere to go back to, and Tablet always has somewhere. It now says **"back to
following Desktop"**, and so does Phone.

### The dot that marks "this screen size has its own value" is orange (#65)

It was WordPress's admin blue. It was always meant to be WeIdea's orange, the
same orange the selected tab uses. Along the way this fixed something nobody had
reported: on a selected device button the blue dot was genuinely hard to see —
below the contrast standard for small marks like this. The orange is not.

### The ⓘ is legible now (#56), and its panel has a way out (#61)

The little ⓘ in each panel's corner was faded to about a third of its strength.
Measured against the accessibility standard for icons it was well under the
line — the kind of thing you feel as "that's hard to see" rather than notice as
a fault. It is no longer faded at all; it is simply a quiet grey, darkens as
your pointer crosses the panel, and turns orange on the mark itself.

Its help panel now has a small **✕** in the corner. It could always be closed
with the Escape key or by clicking away — neither of which is visible.

### The ▲▼ arrows beside a number sit centred on the box (#53)

They were stuck to the box's top edge. One rule fixed the whole family, so every
size and count field in the library gets it, not just the one where you saw it.

### Not fixed here, and said out loud

The column divider still loses to the blue line when you try to drag it (#46),
and pressing the round **+** between columns still leaves undo with nothing to
do (#54). Both were **measured** this release rather than guessed at — one
long-standing theory about the divider turned out to be wrong, which is worth
more than another fix that does not hold.

## 0.3.0-beta.17 — control chrome v1 (August 2026, beta track)

*Findings #48 (the reset arrow), #49 (linked / unlinked 4-side controls) and
#50 (copy and paste designs) — the three design directives from Chris's
beta.15 full sweep, built as one tranche because they are one thing: the
chrome grammar every control shares. Nothing your pages have stored has
changed; almost everything about how you reach it has.*

**Version note (escalation E19, ruled by Chris).** Two tranches were both
being called "the beta.17 fix pass". This one ships first, so it takes
`0.3.0-beta.17`; the #46 / #53 / #54 / #26 fix pass becomes **beta.18**. The
older phrase is corrected wherever it appears rather than left to confuse the
next reader.

### #48 — one small round arrow that puts anything back

Every setting you can clear now has **the same little round arrow** beside it,
at the **start of the control's row, before its name** — the position Kadence
uses, which Chris chose at the mock over the build's own first answer. It
appears on **87 places across the library**, reaching **100 of the 172
controls**, and it is the only clearing gesture left: **the old
double-click-the-edge-handle trick is retired**, so there is one way to do
this instead of several half-known ones.

**It shows up only when it can do something.** No value set means no arrow —
an affordance you cannot use is absent rather than drawn greyed-out.

**Every arrow says what it will do, and names the setting while doing it** —
*"Minimum height — back to the house default"*, *"Minimum height — back to
following Desktop"*, or *"Alignment — back to 'Left'"* where the setting has
named options. It is deliberately not one word repeated 87 times: one shared
control carrying one name across dozens of settings is a mistake this project
has already made once, and the arrow was built not to repeat it.

**The arrow never means "delete".** It stays off anything where clearing would
throw away something you made — a background image, a gradient, and an overlay
on Desktop. Those keep their worded "Remove" buttons. On Tablet and Phone the
overlay does take the arrow, because there it means "follow the wider screen
again", which is not a deletion at all.

The blank "nothing chosen" options in dropdowns **survive** — the arrow simply
picks that same option. One operation with two faces, not two operations.

### #49 — four spacing boxes become one, until you unlink them

"Space inside" and "Space outside" now open as **one box** reading **"All four
sides"**. Click the **chain** at the end of the row and it becomes the familiar
**four** — Top, Right, Bottom, Left, each with a small corner mark beside its
word so you can tell at a glance which edge you are on. Click it again and it
is one box.

**Typing in the one box sets all four sides in a single step**, which means a
single ⌘Z takes it back. If the four sides already disagree, the one box does
**not** pick a winner — it reads **"Different on each side"**, and your four
values are still there until you type over them.

**On Tablet and Phone, a small dot beside the group means it is overriding the
wider screen**, and it says how many sides do — "all four sides", or "2 of 4
sides override Desktop — click the chain to see which". Before this release
that dot could only sit on a single side; with four sides collapsed into one
box, it had to learn to speak for the group.

**Which controls you left unlinked is remembered per block**, not per block
type — unlinking one Section's padding no longer silently unlinks every
Section you open afterwards. *(§1 of the checklist asks whether you miss the
old behaviour.)*

**Nothing about storage changed.** The four sides are still stored as four
separate values, exactly as before; the one box is a way of showing them, not
a new way of keeping them. Pages built before this update open unchanged.

### #50 — copy a design from one block onto another

Every WeIdea block's three-dots menu now offers **"Copy design"**, and after a
copy every WeIdea block offers **"Paste design from the Section"** — naming
where it came from, so the menu says what it is about to do. Where a block has
same-type siblings there is a third item: **"Apply this design to the other
columns in this row"**, and its wording follows the block (panels, tabs,
slides, buttons) and its count (one other column is "the other column", not a
lie about the number).

**What travels is declared, not guessed.** Every one of the 172 registry
controls says whether its setting is a style, a behaviour, content or
structure, and only styles travel. Words stay. The picture inside an Image
stays. An Icon's symbol stays — a star stays a star — while its colour and
size move. A block's identity never moves.

**What lands is filtered on the way in, and the filters are the interesting
part.** A design pasted onto a different kind of block applies what the two
have in common and drops the rest, counting what it dropped and naming the
PANELS it came from rather than reading out a list of setting names. A setting
whose value means something different on the target — `width` is a share of a
row on a Column and a maximum on a Divider — does not travel. Nor does a
dropdown value the target's own dropdown does not offer. Nor does a value
whose shape disagrees with the target's schema, which is the failure that
paints correctly in the editor and emits nothing on the page.

**One paste is one dispatch and one ⌘Z**, and so is applying a design to a
whole row of columns. Column widths and "hide on this screen size" are
excluded by declaration on the setting itself, so the rule travels with them.

**A copy writes nothing to the post**, and what you copied lives as long as
the browser tab does — no server write, no permission surface, and no menu
item whose effect you cannot predict a day later.

**Everything a person reads or hears says *design*, never *styles*** — the
menu items, the announcements and the little message bars alike, per Chris's
two rulings of August 7. Code identifiers keep "styles"; that split is
deliberate and documented where it could otherwise be "tidied" into one.

**After a paste, what a screen reader says is the paste's own sentence** —
*"Design pasted onto this Column, on every screen size. Undo puts it back."*
A paste can also flip a spacing control from one box to four, and that flip
has a spoken sentence of its own, but only one of the two can be heard: the
platform clears the previous message when it writes the next. **Chris ruled on
August 8 that the paste's sentence is the one that survives** — the flip is
announced when nobody asked for it, and a paste is something you asked for.
The order was a genuine race until this release and is now fixed in place, so
what you hear is the same every time.

## 0.3.0-beta.16 — the beta.15 sweep's fix pass (August 2026, beta track)

Chris's full-sweep manual pass on beta.15 produced eight entries. Six of them
are here: **#43, #45, #46, #47, #51, #52**. The control-chrome design work
(#48/#49/#50) is deliberately not — it is design-first and a fix pass must
not improvise it — and #42's deploy prevention keeps its own tranche.

**Frontend byte delta: 0 B, measured rather than assumed.** The whole tranche
was built, the frontend assets totalled, the tranche stashed, the tree
rebuilt, and the same totals taken again: 10,838 bytes of CSS and 10,598
bytes of JS, both times. Everything here is editor chrome or registry values.
No saved content moves and no storage shape changes.

### #45 — one set of arrows, and every one of them writes

"Number of columns" drew two sets: the browser's own spinners inside the box,
which `type="number"` gives away free, and our ▲▼ steppers below it. The
native pair only ever moved the field's DRAFT — the field holds one until
Enter or blur, because committing per keystroke made typing "12" collapse a
six-column row to one on the way past — so the arrows a person reaches for
first were the arrows that never reached the row.

**That is finding #33 in click form, and it was hiding a third case.** #33
was ArrowUp/ArrowDown falling through to a native stepper while the buttons
went through `nudge()`; the cure was one path for both. Here the keyboard had
the same disease and nobody had noticed, because this control's own header
comment asserted the opposite in as many words — "the ▲▼ buttons and the
arrow keys still act at once" — while no handler existed and the arrows sat
on the native stepper, moving the draft. Both are routed through `apply()`
now, one press is one step, and the native drawing is suppressed while the
`spinbutton` ROLE is kept: it carries name, role, value, min and max for
free, and the bounds matter more here than anywhere else in the plugin.

**And the placement bug was a selector.** Chris's directive is that arrow
controls live inside or beside a field and never below it. The rule that puts
the steppers beside a field named `.wi-control--size` only, so the count
field — which renders the same wrapper and the same steppers — got no flex
container at all: full-width input, steppers pushed onto the next line. The
rule now names every control that draws them, so the next numeric control
inherits the placement instead of depending on someone remembering.

**And the sweep found the same defect on EVERY size control in the library.**
Chris reported one field; the variant coverage his directive asked for
measured computed `appearance` as `auto` on "Line thickness", "Corner
roundness", "Title size", "Space between panels", "Text size" and the rest,
because core's `UnitControl` also renders `<input type="number">`. Those are
WORSE than the count field's dead pair: they work and they DISAGREE, because
they step from the field's own value while our steppers step from the
inherited one — #33's complaint word for word. The suppression therefore
lives on `.wi-size-field input[type="number"]`, the wrapper that pairs a
field with our steppers, so one rule serves the count field and all of them.

Deliberately NOT `.wi-control input[type="number"]`: core's RangeControl
renders one too, has no steppers of ours beside it, and its spinners have
nothing to disagree with. Those are LISTED in the run log rather than failed
— a sweep's skip list is a second findings list.

### #46 — the divider and the "+" both work now

They competed for one narrow gap and which one you got depended on which had
painted last, which is why it read as intermittent. Same family as #32, and
#32's cure already existed in this file: `freeSpan()` carves a handle down to
whatever the editor's own UI leaves free.

**Two things had to change before the carve could see anything.** The divider
is positioned by its own `reposition()` rather than by `positionEdge()`, so
it had never been through `freeSpan()` at all. And `freeSpan()` only ever
queried the canvas document — the in-between inserter is a popover in the
EDITOR document, exactly like the block toolbar that finding #19 had to map
across the same boundary. `toolbarRects()`'s coordinate handling is lifted
into one `rectsIn()` collector both now use, and the 120ms watch that
reschedules on blocker movement reads the same set, so the carve happens when
the "+" ARRIVES rather than one selection change later.

**A second blocker sat above both, and no carve could reach it.** Measured at
the instant of pointerdown: core's insertion-point indicator, and then its
parent container, are rendered in the EDITOR document over the whole canvas
iframe and are hit-testable — so they took the pointerdown meant for the
divider underneath. You cannot raise an element inside an iframe above
something painted over the iframe. Both are set `pointer-events: none`
inline with `!important` from the controller, after two stylesheet attempts
were measured LOSING the cascade. The licence is core's own pattern in the
same reading: the popover wrapper computes `none`, the "+" button computes
`all`. Decoration is transparent, the control is not.

**And the "+" was never an inserter.** Seven CI runs asserted that clicking
it opens one. It does not — `aria-label="Add column"`,
`aria-haspopup="false"` — because core's Inserter switches to DIRECT INSERT
when only one block type is allowed, which for a Row is `weidea/column`. It
adds a column then and there. Every assertion built on "an inserter opens"
waited for something that could never happen, while the click it was testing
had been working. Chris's report named the control correctly ("the
add-column '+' button") and this build read it as a figure of speech. The
spec now asserts the consequence — a column arrives — with the button's
accessible name as the precondition.

Asserted both ways and hit-tested: a real pointer click at the +'s own centre
adds a column, and the divider still drags — from its own zone — WHILE the +
is showing. Neither half is worth anything alone; withdrawing the divider
entirely would pass the first, and leaving it full-height passes the second.

### #47 — one status sentence, never two glued together

The chip strip printed "Custom — you set these by dragging.Following
Desktop." Two independent conditionals wrote into one paragraph and both were
true at once on a device inheriting a dragged desktop layout.

**Fixed as a ruling rather than as punctuation.** A space would have repaired
the typography and left the worse half standing: on the Phone tab "you set
these by dragging" is not true — the dragging happened on Desktop — and it
sends her looking for a gesture she never made there. So the two facts FOLD.
Where the layout came from is the load-bearing one on an inheriting device,
and "Custom" still has to be said, because a custom layout lights no chip and
dropping it would leave the strip with nothing selected and no reason given.
Every state gets exactly one sentence: *Custom — you set these by dragging.*
· *Custom — set by dragging on Desktop.* · *Following Desktop.* · nothing.

The reset link in the same paragraph got the explicit space it also lacked.

### #51 — the device switcher, out of the dropdown and into the top bar

Three icons inline in the editor header, at the start of the group that ends
in Preview and Update. **It drives core's own device-preview state**, which
is the load-bearing decision rather than a convenience: it reads and writes
`core/editor`'s device type, the same store the Preview dropdown uses and the
same one every responsive control in this plugin already shares. Two controls
that CANNOT disagree beats two controls that are tested not to.

One tab stop for the group with a roving tabindex, the house pattern; below
600px it stands down so Update is never the control that falls off the end.
Editor chrome, zero frontend bytes, and `wi-device-bar` is a declared marker
in the canvas gate so it can neither leak to a visitor nor vanish silently.

### #52 — the banner names a door and now provides one

It said "close this and open the Workbench" with no link, no address and no
hint where the Workbench lives. The first human to read it could not find it,
which is the whole test: this copy exists for Jen.

The Workbench has no URL of its own — it is an overlay the front end summons
on the page you are looking at — so the door is the page's own permalink
carrying `#wi-workbench`, which the frontend loader reads on arrival and then
strips, because arriving is an instruction and an instruction that repeats
itself on every reload is a trap. A fragment rather than a query argument: it
never reaches the server, so it cannot become a second cache entry or be
mistaken for the admin-side `wi-workbench=1` flag.

A LINK, not a button, because it goes to a URL — and that keeps the banner's
"no dismiss control" rule true by construction rather than by luck. Same tab,
and the sentence says so: two editors open on one page is finding #42's
data-loss path with the door held open. The e2e follows the link and requires
the overlay to actually open; an href is easy to write and easy to write
wrongly.

### #43 — alignment options that told the truth on half the world's pages

Items 2 and 3 only. Item 1 (the tabs.json "From the left/right" caption
wording) waits for the vocabulary ruling and no word was renamed here.

`image.json` and `offcanvas.json` paired the word "Left" with an EMPTY value
on `text-align`. Empty emits no declaration at all, so the element inherits
whatever surrounds it: on an LTR page that usually lands left by accident,
and on an RTL page it lands right while the control still says Left.
`offcanvas.json` also carried the registry's last physical CSS keyword
(`"right"`). Both now carry real logical values, `""` keeps its place as an
honest "follows whatever's around it", and the guard's allowlist is empty.

**The cheap check for that shape found two more of it.** The static RTL guard
could never see an empty string — there is no physical keyword in it to
catch — but the PAIRING is visible: a blank value wearing a directional word.
Four lines, and it immediately failed on `buttons.json → justify` and
`tabs.json → stripAlign`, neither of which the finding named. All four are
fixed, captions untouched: the ruling constrains the VALUE, not the word,
which is the same line R8 drew in beta.15.

## 0.3.0-beta.15 — Row layout v2 (August 2026, beta track)

The Row becomes the responsive layout instrument the plan always promised:
an arrangement per device, a column-count stepper, direction per device, and
a Column's content aligned inside it — plus three debts that belonged to this
reshape. Seven deliverables, one build session, off a blueprint a four-judge
panel argued into shape.

**Frontend byte delta: 0 B.** Frontend CSS is 10.6 KB of a 30.0 KB budget and
frontend JS is 10.3 KB of 12.0 KB — both unchanged from beta.14. Everything
this tranche paints is per-instance CSS, which the budget does not see and
which a page nobody edits never gains, because all three new attributes
default to `{}` and every generator skips an empty map.

### Probe P1, and a caveat worth more than the answer

P1 asked whether a per-device `flex-direction: column` needs the width
neutralisation the legacy stack path gets. **It came back YES — identical —
so the tranche cost no frontend bytes and escalation E8 never fired.**

But it came back YES for a narrower reason than the recipe assumed. A
percentage flex-basis resolves as `content` only while the container's main
size is INDEFINITE. Measured against a row forced to 300px, the two paths
diverge exactly as E8 describes: columns stored as one third and two thirds
rendered 92px and 184px TALL, where the legacy path gave 78px and 198px. A
second probe then walked every ancestor this library can actually build — a
Section with min-height and "Content sits", an enhanced carousel Slide, a
Column made a flex container by this tranche's own new alignment, a plain
stretched Column — and `.wi-row` stays content-sized in all four.

So the answer is safe today and rests on something nothing enforced. It is
enforced now: a static gate fails if Row ever gains a definite block size
(a height/min-height/max-height/block-size/aspect-ratio binding, or a height
declaration on `.wi-row` in its own stylesheet), and its failure message
carries the whole story rather than a red X — it names P1, explains that a
definite block size turns every stored width into a height under a stacked
direction, and points at finding #45 for the re-opening instructions.

### Arrangements are derived, never stored

There is no `arrangement` attribute and no migration. Pressing a chip writes
`width` on the columns — the same attribute the divider drag already writes,
through the same merge. A partial map (what one drag leaves behind) reads as
**Custom**, and the strip never completes it to keep a chip lit: that would
be a migration wearing a disguise.

The insert-time picker's `LAYOUTS` literal is **deleted**. Both surfaces now
read one array, and CI fails by name if a second literal reappears or the
import goes — because CI cannot check that two literals agree.

"Narrow + wide", "Wide + narrow", "Thin + wide" and "Wide + thin" are gone
from the product. Four names differing by a synonym pair, with the only
disambiguating fact living in a preview swatch that is `aria-hidden`. Every
preset is now named by the split it makes.

### The column-count stepper

A spinbutton with real bounds, and one `replaceInnerBlocks` — never a
synthesised commit or a coalescing flag, which is what caused finding #25.
The invariant the tests measure is RELATIVE and taken in-run: a count change
costs exactly as many undo presses as typing into "Space between columns"
does. Dropping a column moves its content into the last surviving one and
returns every device's ratios to even, which is announced three ways — a
sentence before the press, an assertive `speak()` on commit, and a snackbar
with Undo — because reversibility only counts as a mitigation if the user
knows something happened.

### Column content alignment (#24), and the generator fix it could not ship without

PHP emitted `css.companion` only in the NON-responsive branch, so a
responsive alignment painted correctly on the canvas and emitted nothing on
the front end — canvas right, front end wrong, every gate green, which this
project's own build-status doc names as its worst failure family. The
responsive branch now mirrors the non-responsive one and the JS canvas path.
Blast radius verified zero: all three companion users in the registry are
non-responsive controls. Its acceptance test asserts the tablet media query
directly and was watched red first.

Both selects carry a "not set" first option that DELETES the key. Without
one there was no way back: the moment anything is picked, the companion
writes `display:flex` and the column's children stop collapsing their
margins, and the report arrives a day later as "the gaps went weird and I
can't undo it", long after undo is gone.

### Per-device direction, and the legacy handover

`stackOnMobile` and `collapseReverse` keep their declarations and their
compiled rules — only their two controls leave the inspector. A stored
`direction` map supersedes them through one shared predicate imported by both
`save()` and `edit()`, written to be TOTAL rather than merely correct:
`Object.keys('column').length` is 6, so a naive length check would let a
scalar from a paste strip the legacy classes out of `save()` on blocks that
have no `deprecated.js` to fall back on.

On the first direction write the phone value is seeded from the booleans in
the SAME dispatch — otherwise a row explicitly set never to stack would start
stacking on phones. And clearing the last human-set value clears the
machine-written one in the same press, so `{"mobile":"column"}` never survives
on a device tab the user was never on.

### The live-publish guard (#5)

The classic editor now says what it is. A banner on every already-public page
(never on a draft), a sidebar line, and a confirm dialog **only when a
Workbench copy exists** — not on every live update, which within a week is a
keystroke rather than a decision, and which was absent from the one case
where continuing genuinely destroys work.

**Known hole, documented rather than glossed:** saving with the keyboard
shortcut does not raise the confirm. That gap falls hardest on people who save
by keyboard because reaching the button is expensive for them, and for whom
the on-screen banner is the weakest of the guard's signals. It is a known
hole, not a judgement that those saves are safer. Nobody may describe this
guard as "you cannot change a live page without confirming."

### Also

- **`htmlTag` moves to the Advanced tab** as "Page outline", the Inspector v2
  §3 promise coming due, with plain-English option labels. Values unchanged;
  nothing under `src/`, `includes/` or any `block.json` moved.
- **RTL (R8) is ruled and enforced.** Captions describe the logical edge; the
  visual grid mirrors. A static gate now refuses a physical property, a
  physical option value or a physical `css.template` anywhere in the registry,
  and one smoke assertion measures the observable position on a genuinely
  right-to-left served page via a new `?wi_fake_rtl=1` lever.
- **One line repairs ~26 controls.** Every responsive control rendered its
  device group with the same accessible name, "Edit per device"; it now names
  the control it belongs to.
- **`canvas:check` was passing vacuously** and no longer does. Any surviving
  marker satisfied it, so a whole editor-only layer could vanish from the
  build under a green tick — measured while adding the guard's marker. Every
  declared marker must now be found.

### Gates

`registry:check` gains three rules, each watched failing by name first: a
structural control that also binds, a physical CSS property/value/template,
and a demo example whose shape contradicts its control. `budget` is reported
as a number, not a pass: **frontend CSS 10.6 KB, frontend JS 10.3 KB, delta
0 B.**

## 0.3.0-beta.14 — the cleanup batch, and one finding that turned out not to be one (August 2026, beta track)

Four small items off the ledger: #28, #39, #41 fixed; **#40 instrumented,
measured, and handed back to planning as a design question rather than a bug.**

- **#40 — the ⌥-mirror on an outside edge does exactly what it is supposed
  to.** Chris ⌥-dragged a Section's bottom outside edge, expected the opposite
  cell to mirror quietly, and got "the whole block shifts down the page". The
  finding named two possible worlds and refused to guess between them, so the
  gesture was performed in CI and every value printed: `marginTop 64px`,
  `marginBottom 64px`, right and left unset, all four padding attributes
  unset, and the two lit cells the FIRST and THIRD of a top·right·bottom·left
  row — each under its own word, each bound to its own attribute. The pair is
  the pair. The block moves down because a top margin was set and that is what
  a top margin does. What ⌥ should MEAN on an outside edge is a design
  question, and it goes to planning; nothing was changed here on a build
  session's own authority.
- **The chip names its sides.** `⌥ both` → `⌥ top+bottom`. A control that
  writes two attributes should say which two — "both" is precisely what left
  the second one to be discovered from the page moving. Owed either way the
  instrumentation landed, so it shipped either way.
- **And the quad's cells must now PAINT in source order.** `quad-drag-sync`
  already asserted the pair and the cells; what nothing asserted was where the
  cells actually sit, and "the two lit cells were in suspicious positions" is a
  geometric claim. A grid can reorder what the DOM says, so `quad-geometry`
  now requires cell N to start to the right of cell N−1. This is the half of
  #40 that was genuinely unasserted, and it is the lesson #35 paid for.
- **#39 — the `inner` bucket, closed at all three places it escaped
  through.** `exampleStyles()` files a binding by its selector; `inner` styles
  paint the subject and everything else paints the box; `DemoPreview`'s branch
  test read `self` alone. Section's "Content width" binds `max-width` on
  `inner` and is the library's only example that paints exclusively through
  it, so it satisfied every gate, compiled a real style, and still fell
  through to the abstract placeholder. The branch now reads both buckets.
- **The static gate reads the renderer instead of describing it.** It pulls
  `INVISIBLE_ON_BOX` out of `demo-preview.js`, checks that `exampleStyles`
  still buckets inner-or-self, and derives which buckets the branch consults —
  so "paints something" means "paints something the branch will look at". It
  is load-bearing, not decorative: revert the branch to `self` alone and the
  gate fails by name, naming the panel and the bucket. #39 cannot come back
  quietly. The example itself becomes `30%`, because a width cap only reads
  when it is under half the box — `GeometryPair` draws two subjects, which is
  what lets a `gap` demo exist at all, and each already takes about half.
- **#41 — the demo subject is coloured, and the sweep can now measure
  "legible".** The subject was `#c8c8c8` on a `#f0f0f0` box: a 40-level step,
  which at ~110px is two grey rectangles, which is exactly how Chris read the
  new spacing demos. The inset was real the whole time and nobody could see
  it. Brand orange — the inspector's own — fixes the whole geometry family
  rather than the panel that got reported.
- **`demo-fidelity` gets two rules, and each is a finding that walked past
  the previous one.** A pair kind must RENDER a pair: the old code logged
  `skipped (not a before/after pair)` and continued, which is how the sweep
  missed #39 in its own run — the only legitimate skip is one DECLARED in the
  schema, so the five device-schematic panels are filtered out up front by
  `css.perDeviceBool` and listed in the log. And the difference must be one a
  person SEES, measured as area AND contrast: some share of the tile must
  differ, and some share must differ by a step nobody could miss. Both PNGs
  are decoded in the page under test, so the gate needs no image dependency,
  and every panel's numbers are logged pass or fail. Red-first evidence on
  beta.13's build: `Content width: declares a pair kind but rendered 0
  figure(s)` and `Spacing: 89.43% of the tile differs … and 0.00% differs by a
  step a person cannot miss`. After the fixes, the same two panels measure
  39.50%/39.27% and 89.77%/89.43%.
- **The new rule found a third one, and the thresholds are calibrated against
  the library rather than chosen in the abstract.** Column's Background demo
  measured **0.00% of the tile changed** — not one pixel differing by more
  than anti-aliasing. Its example was `backgroundColor: var(--wi-bg-soft)`
  alone, and that token is `#f5f7fa` against the demo box's `#f0f0f0`: real,
  correct, and about seven levels of grey. It now carries the gradient its
  panel has always been able to paint, as Section's example does. The
  vividness threshold moved too, and the reason is worth recording: at 96 it
  also failed Section's "Text & links" and Tabs' "Tab colors", where the
  accent colour on a muted specimen is a step of **95** — legible to anyone,
  one level under an arbitrary bar. It sits at 72 now, above the grey-on-grey
  40 this rule exists to catch and below the quietest change that genuinely
  reads.
- **A theory that did not survive contact, recorded because it was almost
  written down as a mechanism.** Those near-invisible panels shared a trait —
  their examples are design tokens rather than literals — and there is an
  obvious story about tokens not resolving where the popover renders, which
  would have explained everything. The sweep asked the popover instead:
  `--wi-accent=#2b6aa3 · --wi-bg-soft=#f5f7fa · --wi-bg=#ffffff`, identical
  to the canvas. The tokens resolve fine. The pale ones are simply pale, and
  a pale token painted on a pale demo box is invisible for ordinary reasons.
- **#28 — the interactive blocks' words translate at render time.**
  Off-canvas's "Menu"/"Close" and the carousel's "Pause", "Play", "Previous
  slide", "Next slide", "Slides", "%1$s of %2$s" and "Go to slide %s" have
  been untranslated since beta.11 for a good reason: they land in saved
  markup, `save()` is re-run and diffed against the stored HTML on every open,
  and a translated string is a validation failure waiting for the next author
  in another admin language. `WI_Labels` is `WI_Motion`'s shape — a
  `render_block` filter that decorates the markup on its way to the visitor.
  Nothing stored moves, so no deprecation, no `data-wi-v` bump, no `save()`
  change. Only words still showing the untranslated default are filled, tested
  by the string itself rather than the attribute behind it: an author who
  typed "Shop the Mall" keeps it in every language. Attributes go through
  `WP_HTML_Tag_Processor`; button TEXT cannot, because nothing in WordPress
  6.5 sets an element's content, so it is matched narrowly against our own
  classes and our own defaults. Proving it needed a translated site and the
  e2e environment is English, so `?wi_fake_i18n=1` turns on a gettext filter
  that wraps every `weidea-studio` string in guillemets — and the suite
  asserts both halves that have to hold together: the visitor sees «Menu», and
  the database still says Menu and still opens clean in the editor.

*Frontend budget delta: 0 bytes. `WI_Labels` is PHP, and the demo work is
editor-only.*

## 0.3.0-beta.13 — the stylesheet that never arrived (August 2026, beta track)

Chris's beta.12 manual pass produced five findings, and four of them turned
out to be one bug wearing four hats. The spacing quad's stylesheet had never
reached his browser.

- **The editor stylesheet has been served from the same URL since Phase 0
  (root cause of #34, #35 and #37).** WordPress cache-busts a block's
  `editorStyle` from the block's OWN metadata — `register_block_style_handle()`
  reads `$metadata['version']` — and every one of our 21 `block.json` files
  carried a hand-written `"version": "0.1.0"` that nobody ever bumped. The
  matching *script* was always fine: `register_block_script_handle()` prefers
  `index.asset.php`'s content hash, which webpack regenerates every build. So
  a browser that had ever opened the editor ran **beta.12's JavaScript against
  beta.11's CSS**. The version now lives in one place (`package.json`) and is
  stamped into the built metadata by `bin/stamp-block-versions.mjs`; source
  `block.json` files declare no version at all, so there is no second copy to
  drift. `npm run assets:check` fails the build if a stamp is missing or
  stale, and it goes red against beta.12's own build output.
- **#35 was never a wrong-attribute write.** The drag wrote `marginBottom`
  correctly, every time. With `.wi-control--quad`'s rules missing, the
  four-across grid collapsed into four full-width stacked fields and each side
  label rendered directly above the *next* side's field: the box holding 100
  was Bottom, and the word printed over it was "Right". The label now comes
  FIRST in the DOM and is moved below its own field with `order`, so an
  unstyled fallback stacks legibly instead of lying.
- **#34 / #37 — the quad chrome, fixed at the root and asserted
  geometrically.** The header overlapped because a `FlexItem` is
  `min-width: 0` and nothing gave the label a wrap opportunity, so its glyphs
  painted straight over the device buttons; the row now wraps and the label
  breaks anywhere. The override dot shared its 5px corner with the ▲ stepper
  and lost — it moves to the inline-start corner. A centred value slid under
  the steppers, so the gutter they need is now one named number used by both
  rules. `tests/e2e/quad-geometry.spec.js` asserts the symptom: no two header
  controls' rects intersect, on desktop, tablet AND phone, with a three-digit,
  a negative and an odd-unit value loaded.
- **Negative spacing is ruled (G19): outside yes, inside no.** "Space outside"
  takes negatives, because pulling a section up over its neighbour is a real
  move. "Space inside" declares `min: 0` and clamps, because
  `padding-block-start:-24px` is invalid, the browser drops the declaration,
  and the editor would show a number the page has never heard of. The floor is
  registry DATA next to the group it governs, and it is applied at the single
  commit funnel so typing, stepping, linked typing, linked stepping and a unit
  change cannot disagree.
- **#36 — Column's ⓘ demo, and the hole that let it through.** The demo box
  centred a fixed-size bar, so symmetric padding moved nothing: the compiled
  CSS was real, correct and invisible. The subject now FILLS the content box
  and shrinks away from every edge the padding names. Column's example covers
  all four sides; Column's "Column size" demo compiles `flex: 0 1 33.33%`,
  which was inert on a plain block box and now has a flex track to be an item
  of. The gate hole is closed from both ends: a `style` demo that paints
  nothing a box can show is a CI failure, panels that are genuinely abstract
  now DECLARE `kind: "abstract"` instead of reaching the placeholder by
  falling through every branch (seven of them did), and
  `tests/e2e/demo-fidelity.spec.js` screenshots both tiles of every pair in a
  browser and fails when they are identical.
- **#38 — the tab strip reads like Kadence's, in WeIdea orange** (Chris's
  directive). Icon over label, boxed segments, the active tab lifted out in
  white with a brand-orange rule. Style only: no panel, registry or schema
  field moved and the titles are still plain strings on `rt()`. Core owns both
  of that button's pseudo-elements, so this does not share one — it takes
  `::before` over for the icon and replaces the focus ring core kept there
  with a real `outline`, in the same rule.
- **#35's spec was replaced, not patched.** beta.12's sync spec asserted one
  variant, passed, and shipped alongside the finding. The new one enumerates
  every edge × inside/outside × plain and ⌥-mirror — twelve gestures — and
  asserts both halves that were separately green while a designer looked at
  the wrong answer: the value reaches the correct attribute with no other side
  moving, AND it appears in the correct cell under the correct word.

*Frontend budget delta: 0 bytes. Everything here is editor-only.*

## 0.3.0-beta.12 — Inspector v2: three tabs and one spacing control (July 2026, beta track)

The inspector stops being one long scroll. Every block's settings now sit under
**Layout · Style · Advanced**, and Section and Column's six-to-eight stacked
one-field-per-side spacing controls collapse into a **four-cell quad** with a
shared unit, a link toggle and steppers on every cell. It is about 90%
reorganisation of controls that already existed — which is exactly why the
interesting work was proving that nothing moved but the furniture.

- **Three tabs, and the taxonomy is data.** All 57 panels carry an explicit
  `tab` (layout 30 · style 20 · advanced 7); the renderer only reads it. No
  defaults and no inference: panel ids are not a taxonomy — `panel` appears
  five times meaning five different things, and `text` resolves oppositely on
  a heading and a section. A missing tab is a loud CI failure; a wrong default
  would have been a silent UX bug no gate could catch, because a gate cannot
  know intent. The gate now prints the distribution, so a future block that
  dumps everything into one tab shows up in the log rather than only in a
  designer's frustration.
- **Layout opens on Spacing.** `initialOpen` is per tab now, so "the first
  panel" means the first panel of the tab you are in — which is the complaint
  that started this whole project. Panel open state and the active tab are
  remembered per block type for the session, because `InspectorControls` fills
  render only for the selected block: without memory the strip snapped back to
  Layout on every single selection change, including selecting the block you
  were already editing.
- **Core's own "Advanced" panel is adopted into the Advanced tab**, and five
  of our panels are renamed so it can be (`Custom CSS & stacking order`,
  `Custom CSS`) — measured in the running editor, the sidebar was holding two
  panels with the identical accessible name. *These five renamed panels are a
  visible change and are on the Phase 3 manual checklist.*
- **The spacing quad.** One header over four cells, on Section (padding +
  margin) and Column (padding + margin). Vocabulary is **"Space inside" /
  "Space outside"**, and the per-side labels follow it — `Space inside top`,
  `Space outside left` — so the library speaks with one voice in the ⓘ
  popovers, the Learn sidebar and the Manual. *Those 18 strings are a visible
  change and ride the same manual-pass flag.*
- **The quad is a LAYOUT, not a new binding shape.** Four ordinary scalar
  binds, so both CSS generators, the demo compiler, the Learn sidebar and
  every per-control gate rule are untouched, and byte-identical output is
  structural rather than tested. Storage is unchanged: an e2e proves the quad
  writes a post byte-for-byte identical to authoring the attributes directly,
  in a deliberately scrambled order, because `getCommentAttributes` iterates
  declaration order and write order cannot reorder a save.
- **Linked typing is absolute; linked stepping is relative.** 96/24/96/24 with
  ▲ gives 97/25/97/25, never 97 across the board, which would destroy a design
  in one keypress. Toggling the link never writes anything, and unequal sides
  stay unequal until your first edit equalises them in ONE dispatch, so a
  single ⌘Z restores the set exactly. Sides may legitimately disagree on
  units; the chip then reads `Mixed` and the odd cell shows its full value.
- **Section's margin quad ships four cells**, surfacing `marginRight` and
  `marginLeft` — already declared, never before reachable. Zero new
  attributes, zero bytes on existing saves.
- **Column gets per-side spacing without a migration.** Its all-sides
  `padding` shorthand is kept forever and is never written, rewritten or
  deleted; it shows as a grey placeholder until you edit a side, and your
  first edit seeds all four sides for every device the shorthand keyed, in one
  dispatch. The shorthand is then SUPPRESSED rather than overridden, because
  two attributes binding the same CSS property is new in this codebase and
  declaration order resolves it differently in the two generators — the editor
  flattens per previewed device, PHP buckets per device, and at tablet width
  the shorthand was resetting an edge the desktop longhand had set. Clear all
  four sides and the shorthand comes back: the rule is fully reversible.
- **ArrowUp / ArrowDown finally do what the code has claimed since Phase 1
  (#33).** `size.js`'s header documented a key handler that did not exist, so
  arrows fell through to `UnitControl`'s native stepping — which counts from
  the field's own value while the ▲▼ buttons count from the inherited one. On
  a blank tablet field ▲ gave 81px and ↑ gave 1px. Both paths go through one
  `nudge()` now, on the size control and on every quad cell, and the arrow
  path is tested for the first time.
- **Roving tabindex on every responsive control.** The three device buttons
  were three tab stops on all ~26 of them; they are one now. That is what
  makes a four-cell quad affordable at all: 7 stops per quad on desktop, 8
  with a reset, ~15 for Section's pair, against ~42 for the six stacked
  controls they replace. The number is pinned by a test, red-first, because
  stepper visibility and stop budgets are properties nobody looks at again
  once a feature works.
- **Finding #29 closed — and it was never ours.** The inserter icon test that
  failed all three attempts of beta.11's tag run was dying on a strict-mode
  violation while core regrouped its search results: core's browse view is
  still mounted while the filtered list renders beside it, and both groups are
  headed "WeIdea Studio", so the tile resolved twice for ~150ms. One
  variation, one collection, one category — measured. It settles on core's own
  group count before asserting.
- **Finding #32 closed.** A drag handle's hit zone yields to the inline "+"
  appender: handles measure the editor UI crossing them and claim only the
  span that is left, withdrawing entirely rather than keeping a sliver. The
  appender is watched on the same 120ms clock as the block toolbar, because it
  mounts and moves on hover long after a selection's settle budget expires.
- **Finding #31 closed.** Accordion headings get inline padding in both the
  no-JS and enhanced states so a row never shifts sideways when the script
  arrives, and the chevron gets the clearance its rotated corner actually
  needs.
- **Column's canvas handles are four, and honest about it.** Its two old
  handles wrote the shorthand and would have become a silent no-op the moment
  it was suppressed. Four per-side specs replace them — and because an empty
  column's box is 24px tall (measured), the inward inset is clamped to what a
  box can hold, and a handle that cannot be separated from its opposite
  withdraws and says so rather than overlapping it invisibly.

Editor-only, with one deliberate exception: the legacy-suppression rule edits
`includes/class-wi-block-css.php`, a front-end file. It is behaviourally inert
for every existing save. Frontend budget delta: **0 bytes**.

## 0.3.0-beta.11 — The library learns to move (July 2026, beta track)

Four interactive blocks — **Accordion, Tabs, Off-canvas, Carousel** — and the
fourth and final pass at finding #19. The blocks are the first in this library
with behaviour, so the interesting work was not the widgets: it was deciding
what a visitor gets when the behaviour doesn't arrive.

- **Accordion, Tabs, Off-canvas and Carousel, registry-driven like the other
  14.** Seven block registrations in total: each of the three container blocks
  has a child (`accordion-item`, `tab`, `slide`) that only its parent can
  insert, so the inserter still shows four new things. They inherit everything
  the registry gives: responsive values with override dots, hover bindings, the
  Animate tab, ⓘ learn-in-place popovers and Learn-panel entries compiled from
  required help + demo specs, per-brand token skinning, the branded inserter
  category. 21 schemas, 56 panels, 157 controls now, all CI-gated.
- **The saved markup is the whole document, and the script is a promotion of
  it.** With the view script gone — safe mode, a CDN eating the file, JS off —
  an Accordion is a stack of real headings with their panels open, Tabs is the
  same panels stacked under their own headings, an Off-canvas drawer is its
  content in normal flow, and a Carousel is a plain list of slides. Nothing is
  hidden, clipped or transformed by a stylesheet unless the script has stamped
  `data-wi-ready` on the block, and no control that needs JavaScript is on
  screen before then: a dead button is worse than no button. The roles that
  describe a widget — tablist, dialog, `aria-expanded`, `aria-roledescription`
  — are set by the script, never saved, because asserting them in markup lies
  to a screen reader in safe mode.
- **Accessibility built to the WAI-ARIA APG, and tested by keystroke.** Real
  buttons in real headings with `aria-expanded`/`aria-controls` and regions
  named by their toggle; a tablist with roving tabindex, arrow keys, Home/End
  and automatic activation; a dialog with a focus trap that survives having one
  focusable element or none, Escape, focus returned to the trigger, the rest of
  the page `inert` and scroll locked and restored; a carousel on CSS
  scroll-snap (native swipe, momentum and keyboard scrolling for free) whose
  slides all stay in the accessibility tree, with a pause control whenever
  autoplay is on, autoplay yielding to hover, to focus inside and to a hidden
  tab, and a live region that is `off` while auto-rotating and `polite` when
  the visitor is driving. Reduced motion is honoured live, not just at load:
  autoplay never starts, and scrolling is instant.
- **Zero bytes on pages that don't ask.** Each block's view script is enqueued
  only where the block renders, deferred, and dequeued wholesale by the safe-
  mode kill switch. A page of static WeIdea blocks now has its own e2e proving
  it serves no interactive JavaScript at all. Frontend totals: **10.3 KB JS
  (budget 12) and 10.5 KB CSS (budget 30)** — four widgets for 7.4 KB of
  script, which is what buying the browser's own scrolling instead of a gesture
  library costs.
- **Structure tags: the selected block no longer has one (#19, fourth pass —
  and the first that isn't arithmetic).** The name chip and core's floating
  block toolbar want the same pixels by construction, and three geometric
  dodges each lost to a new real-world case. Planning called the retreat: a
  selected block is already the most-labelled thing on screen — toolbar, solid
  outline, List View highlight — so its chip says nothing anyone needed, and it
  goes away. Tags label UNSELECTED structure. The collision stops existing
  rather than being computed around. Hover is shut too: hovering the block you
  already have selected was the other route to the chip. The toolbar
  step-clear survives for a case the change doesn't reach — the toolbar belongs
  to the selected block, but it can still park over an ANCESTOR's chip.

  The test went to CI first and was watched failing on beta.10: `expected [],
  received "Section"` in all 14 samples, and `["Column","Column","Row",
  "Section"]` with the Row selected. It samples the whole repaint window
  (12 × 120ms, outlasting both the controller's settle budget and its 120ms
  toolbar rect-watch) because right after a selection there is a frame where
  even the broken build has drawn nothing yet — and a retrying matcher would
  have accepted exactly that frame.
- **Counter and Typed have been shipping CSS that never loaded** (found while
  measuring the budget, fixed here). Both imported `style.scss` from `view.js`
  as well as `index.js`, which made webpack extract their CSS to
  `style-view.css` — and `style-index.css` is the only file `WI_Assets`
  registers per block. So the Typed caret's blink animation and the Counter's
  tabular-nums have never reached a visitor's page or the editor canvas. The
  duplicate import also wrapped each view script in ~870 bytes of CSS-loader
  runtime for a stylesheet nothing served: removing it freed 1.9 KB of the
  frontend JS budget, which is what made room for the fixes below.
- **A judge panel before the push caught a defect a green suite would have
  shipped.** The carousel compared the next scroll offset against the track's
  maximum, but each slide gives up one gap of width, so the track's maximum is
  one gap short of the last slide's own offset: at the default gap a
  three-slide carousel bounced between the first two forever with the third
  unreachable, and a two-slide one had a dead Next arrow. The suite was green
  because it reached slide three with a dot click rather than a second Next.
  Also fixed pre-push: translated strings were being baked into carousel
  content by `save()` (a locale change or a second author in another admin
  language turns every carousel into "unexpected or invalid content" — the
  sibling block already refused to do this and said why); an off-canvas drawer
  hidden at a breakpoint while open left the page scroll-locked and `inert`
  with nothing left to press, so it now closes itself when it stops being
  rendered; a one-slide carousel no longer lights up arrows, a dot and a timer
  that can't move anything; and the drawer restores an explicit
  `aria-hidden="false"` it overwrote instead of deleting the attribute.
- **The accordion's heading-level mirror no longer writes on disagreement.**
  One heading level is chosen for the whole accordion, but each item saves its
  own element, and a child's `save()` cannot see its parent — so the level has
  to be mirrored onto the items. Mirroring "whenever they disagree" is exactly
  what an undo lands on: ⌘Z reverts the children while the parent still holds
  the new level, and the effect writes it straight back, leaving a step the
  author can never get past. That is the shape of #25, so the mirror now fires
  only on the two things that are author actions — the level changing here, or
  an item arriving that has never seen it (inserted, pasted, or from the
  template) — tracked as deltas, so a revert is never one of them. **Worth a
  minute of Chris's manual pass: change the level, press ⌘Z twice, and watch
  whether the accordion moves.**
- **Attribute versioning and the deprecation seam from day one.** Every new
  block stamps `data-wi-v="1"` on its root and ships a `deprecated.js` wired
  through `registerWiBlock`. The arrays are empty — v1 is the first saved
  shape, so there is honestly nothing to migrate — but each file documents its
  exact v1 markup contract, which changes count as a new shape, and the
  concrete v2 recipe. The next markup change is the dangerous one; this is
  where it lands instead of in an author's content.
- **In-page links reach hidden panels.** Both Accordion and Tabs hand out
  stable ids, and a collapsed or hidden panel has no layout, so the browser
  scrolls nowhere and announces nothing — the visitor is told the link worked
  and shown the same screen. Both now reveal the owning panel first, on arrival
  and on `hashchange`, via `getElementById` rather than
  `querySelector(location.hash)`, which throws on a hash that isn't a valid
  selector.
- **Tests:** four new e2e suites (~2,600 lines) covering widget behaviour,
  keyboard operability per pattern, focus return and trap edges, duplicate-uid
  pages, untitled panels, the no-JS document, reduced motion, and the
  inspector; plus the #19 symptom tests and the static-page zero-JS guard.

Known and deliberate, recorded rather than fixed: the carousel and off-canvas
stylesheets carry ~1.2 KB of editor-only rules that can never match on a
visitor's page (the CSS budget is comfortable, but the Tabs pattern — an inline
`<style>` written by `edit.js` — is the house answer and they should move to
it); the carousel's `panelBackground`/`panelRadius` should be
`slideBackground`/`slideRadius` to match its neighbours, which now costs a
deprecation entry rather than nothing; a nested Accordion or Tabs inherits its
outer instance's structural styling, because the whole library uses descendant
selectors and making two blocks the exception is a library-wide decision, not a
tranche one.

## 0.3.0-beta.10 — Undo after a drag is safe again (July 2026, beta track, HOTFIX)

Two items, one of them data-destroying. Both were reported green in beta.9;
#19 twice. The tests for both were written and pushed to CI **before** the
fix, so they were watched failing first — a green assertion that has never
been seen red proves nothing, which is the lesson of this pair.

- **Undo after a canvas drag no longer wipes the page (#25, CRITICAL).**
  Drag a margin (⌥ mirroring both sides), press ⌘Z, and *every block
  disappeared* from the canvas and List View — a Kadence Row Layout block
  included, which is what proved the rollback reached past the dragged
  attributes. ⌘⇧Z brought it all back, and so did a reload before saving, but
  a Save while the page showed empty would have persisted an empty page. The
  red-first run reproduced it on ALL FIVE gesture variants, not just margin:
  ⌘Z left `count: 0, shape: "[]"` against an expected 7. beta.9's padding
  test passed only because its fixture was built in-session, leaving undo
  levels behind it; opening a SAVED page is what exposes this, and that is
  what Chris was doing.

  **The mechanism, measured in the editor rather than argued from source.** An
  instrumented run logged the post entity's edit keys around a drag, and they
  tell the whole story. A drag leaves three entity edits — `selection`,
  `blocks` (the parsed tree) and `content` (the editor's LAZY SERIALIZER: a
  function, not a string) — and TWO undo levels. Walking them back: the first
  restores `content` to a string and changes nothing visible, because the
  editor prefers the `blocks` edit; the second drops the `blocks` edit, at
  which point the editor falls back to `content` — a string by now —
  reparses, and the dragged value is gone. Two presses, document intact.

  That ordering is load-bearing, and beta.9 destroyed it. Its synthesised
  commit — `__unstableMarkLastChangeAsPersistent()`, a persistence FLAG with
  no block change — collapsed the gesture into a single level of the second
  kind. ⌘Z then dropped the `blocks` edit while `content` was STILL the lazy
  function, so the editor tried to derive the document from a content value
  that wasn't content yet, and got nothing. That is the wipe: not a
  whole-page rollback, as the finding reasonably inferred, but a document
  derived from a function.

  **The fix is a retreat, and planning called it correctly.** All the
  coalescing machinery is gone: the `persist: false` marking on every
  intermediate write, the synthesised commit that had to follow it, and two
  further attempts to keep one-step undo (closing the gesture on a scoped
  `UPDATE_BLOCK`, then also re-seating the selection so core-data would keep
  the record). Each of those fixed the wipe and each left ⌘Z with nothing to
  revert, because each was still contriving a history entry instead of
  letting one happen. A drag now dispatches plain `updateBlockAttributes`
  calls — byte-identical to a value typed into the inspector — and whatever
  history Gutenberg makes of them is what a drag costs.
- **A drag now costs about two ⌘Z presses, not one (deliberate).**
  One-undo-per-drag was a beta.9 nicety; planning dropped it rather than let
  it keep a page-wipe alive, and it may return later as a QoL item. Today the
  first press after a drag can look like it did nothing — it is normalising
  `content` — and the second reverts the value. Worth knowing before it reads
  as a bug. Save still lights on a drag-only edit, the close-tab warning
  still fires, and the value still survives save + reload: #18a/b are
  asserted per variant, not assumed.
- **Every gesture variant is now under test (#25's other half).** The #18
  test drove a single-side padding drag on a post built in-session and
  asserted only that the value reverted — so a margin ⌥-mirror on a
  reloaded page went untested, and "the value reverted" never asked whether
  the rest of the document was still there. `drag-undo-variants.spec.js`
  enumerates padding single-side, margin with the ⌥ mirror, Section
  min-height, column-divider drag and the divider's one-gesture reset; for
  each it asserts the value reverts on ⌘Z, **the total block count and the
  whole name/nesting shape are unchanged**, ⌘⇧Z restores, Save lights, and
  the edit survives save + reload. The fixture opens a saved page whose
  first block is foreign to WeIdea, so a whole-page rollback has nowhere to
  hide.
- **Structure tags are readable again, proven geometrically (#19, third
  attempt).** The first two fixes were reported green and failed by hand,
  and the red-first run of this one explains why — including why the
  assertion this fix was *asked* for would have failed by hand a third time.
  - The old test polled "no intersection" until true, and `expect.poll`
    passes on the first satisfying iteration, so one frame caught before the
    popover finished positioning greened a build whose resting state
    overlapped. Assertions now settle (tag and toolbar rects read together
    until two consecutive reads agree) and then assert once.
  - **The settled tag-vs-toolbar assertion passes on the BROKEN build.**
    beta.9's dodge does clear the toolbar — it drops the chip to exactly the
    toolbar's bottom edge, which a strict rect test calls clear. The
    failure screenshots show what is actually wrong: a Section, its Row and
    that Row's first Column share a top-left corner, so all three chips
    live in the same 16px band, and the two that dodged land on top of the
    one that didn't. Only the chip painted last (Column) is legible; the
    Row's chip is buried under it. So the invariant is wider than "clear of
    the toolbar": no tag may be covered by the toolbar **or by another
    tag**, and that is the half that catches this.
  - Tags therefore step clear of both. Every visible toolbar instance is
    measured now, not `querySelector`'s first match — that can be a dormant
    zero-size instance while the live popover sits later in the DOM, which
    measures as "no toolbar" and dodges nothing. Placement is redone
    whenever the toolbar's geometry changes (a 120ms rect watch that spends
    a frame only when something moved) rather than for a fixed 8 frames
    after a selection change, so a toolbar arriving after a List View
    selection scrolls the canvas is no longer missed. Each chip then steps
    sideways past the chips already placed that frame, which spreads a nest
    into a readable run instead of a pile. The dodge works from the tag's
    *measured* rect rather than the block's left edge plus
    `offsetWidth || 0` — that spare 0 quietly turned the horizontal test
    into "no collision".
  - e2e covers a top-level Section and a Row nested in a Section selected
    from List View (the reported case), asserting no tag intersects any
    toolbar or any other tag. List View collapses nested levels by default,
    so the test expands the Section first — the first attempt at this test
    timed out on a Row link that was not in the DOM yet.

## 0.3.0-beta.9 — Canvas drags are real edits (July 2026, beta track)

A data-integrity headline and three canvas-clarity fixes, all from Chris's
first real design session on beta.8.

- **A canvas drag now marks the document dirty (#18, HIGH).** After a
  box-model drag the Save button stayed disabled, so a page edited only by
  dragging could be closed with no unsaved-changes warning: silent data
  loss. Every write inside a drag is deliberately coalesced (one undo step
  per gesture) — but the block-editor reducer *independently* marks a
  change non-persistent when it repeats the same attribute on the same
  block as the action before it, which the drag's final commit always does.
  With no persistent change anywhere in the gesture, `useBlockSync` only
  ever called the editor's `onInput`, which writes transient entity edits
  and never the `content` serializer that makes a post dirty. The final
  commit now writes coalesced and closes the gesture with one
  `__unstableMarkLastChangeAsPersistent()` — the path `useBlockSync` is
  built for — so the post goes dirty, Save enables, the close-tab warning
  fires, and the whole drag still costs exactly ONE undo step. Column
  divider drags used to spend two undo steps; they now spend one. The same
  commit closes double-click-to-reset, which could be swallowed the same
  way. Three new e2e: drag → `isEditedPostDirty` + Save enabled; drag-only
  edit survives save + reload; one undo restores the pre-drag value and
  stops there.
- **List View highlight no longer bleeds above the block (#20).** Hovering
  or selecting a Section/Row/Column in List View painted a block-sized
  region ABOVE the block, over the page title. Not a margin-box artifact: a
  pseudo-element collision. Core paints that highlight (and the focus ring,
  and the multi-select tint) as `::after { content:""; inset:0 }` on the
  block — and WeIdea's block-name chips were on the *same* `::after`. An
  element has only one, so the rules merged into a single box that kept
  core's block-sized geometry but took the chip's color and its
  `translateY(-100%)`. The name tags are now drawn as elements in WeIdea's
  own canvas overlay, so every core pseudo-element is left untouched and
  the highlight is exactly the block's border box.
- **Structure tags step clear of the block toolbar (#19).** Now that the
  tags are overlay-drawn, the controller measures core's floating block
  toolbar (mapping its rect from the editor document into iframe
  coordinates) and pushes any tag it would cover down just far enough to
  clear it — which lands the tag just inside the block's top edge in the
  usual case, and leaves it alone when the toolbar is flipped below.
- **"Show block structure" → "Show layout outline" (#17).** The old label
  read as WordPress jargon and cost two searches. Renamed in both ⋮ menu
  slots, the ⌘K command, and the shortcut description; e2e asserts the new
  wording everywhere and that the old wording is gone. The preference key,
  command name and body class keep their identifiers on purpose — renaming
  the stored key would silently reset the toggle for anyone using it.

## 0.3.0-beta.8 — Editor WYSIWYG parity, honest demos everywhere (July 2026, beta track)

With the front-end render fixed in beta.7, this pass closes the gap between
what the editor shows and what ships, and finishes two items that were
marked closed but failed the manual pass — with e2e that asserts BROADLY,
mirroring what a human actually sees, so a single passing assertion can't
mask a broken feature again.

- **Editor canvas matches the front end (#16).** Instance styles are
  emitted into both render paths from the same schema, but inside the
  editor iframe a single scoped class (`.wi-heading-<uid>`) tied or lost to
  the theme's `.editor-styles-wrapper` rules — so a heading's text color
  painted on the published page yet stayed the theme default (black) in the
  editor. The editor emission now doubles the scoped class so its rules win
  the cascade against theme editor styles; the front-end/PHP path is
  unchanged (it already wins there). New e2e asserts the editor-canvas
  computed color + size EQUAL the front-end computed values.
- **Learn-in-place demos render real content on every panel (#4,
  reopened).** Only Animate showed a live demo on the installed build;
  appearance panels whose only change is text (a color, a size) painted it
  onto an empty box, reading as the same gray skeleton. Text panels now draw
  a real type specimen; the truly abstract panels get DISTINCT schematics —
  a device row with the hidden size struck out (Visibility), a layered
  stack (Advanced/z-index) — never the identical empty box. e2e now
  enumerates every panel and asserts a variety of compiled/schematic/motion
  content, not one.
- **Show-structure is in the ⋮ More menu (#15, reopened).** The toggle
  shipped a ⌘⇧O shortcut and ⌘K command since beta.6, but its menu item was
  registered only against the modern editor's slot; older post-editor
  headers render a different slot, so it never appeared. It now fills both
  slots and is discoverable without a keyboard shortcut (⌘⇧O + ⌘K kept).
- **"Section with columns" variation icon is brand orange (#8, reopened).**
  The earlier fix set `fill` on the `<svg>` element, which the editor's
  global `svg { fill: currentColor }` overrode to black in the real
  inserter. It now uses the same object-icon + `foreground` shape as the
  block icon, and e2e asserts the tile glyph computes to the brand orange.
- **Touch ID deploy e2e de-flaked.** Explicit visibility/enabled waits with
  widened timeouts around the admin-bar launch, the staged iframe, and the
  deploy button, so the WebAuthn ceremony stops racing an incompletely
  wired handler (third recurrence, CI #52).

## 0.3.0-beta.7 — Frontend-render delivery, honest demos, steppers, polish (July 2026, beta track)

Two functional fixes lead, then a polish sweep.

- **Per-instance CSS delivery, consolidated and out of the body (#14).**
  Saved design not painting on some live pages was traced to an HTML
  minifier / CSS combiner (SiteGround Optimizer, Cloudflare) stripping the
  inline `<style>` tags WeIdea emitted before each block — the code path
  itself is correct (proven by a new logged-out guardrail run against the
  release zip). Instance CSS is now collected as blocks render and printed
  as a SINGLE consolidated stylesheet in `wp_footer` — after every block
  stylesheet, so equal-specificity instance rules still win by order —
  instead of the many small inline `<style>` tags the old path wove in
  before each block. One consolidated stylesheet is what an HTML minifier /
  CSS combiner leaves intact. **Frontend armor:** `render_block` now
  guarantees the
  scoped `wi-<block>-<uid>` class is on each block's root element (via
  `WP_HTML_Tag_Processor`), resolving the uid as persisted `uniqueId` → uid
  already in markup → a deterministic derivation — so instance CSS always
  has a hook and content saved without a uniqueId self-heals.
- **Learn-in-place demos render real subjects (#4).** Appearance-only panels
  (Section→Background, Icon) had painted their effect onto a neutral
  skeleton box, so a color or an icon showed nothing. The Icon demo now
  draws the actual glyph at the example size/color, and background demos
  paint the composed gradient/image + overlay as the box itself (the
  Section→Background example gained a gradient + overlay to showcase the new
  controls). New e2e asserts the demo compiles a real gradient, not a
  skeleton.
- **Numeric steppers everywhere (#6).** The size control — registered once,
  so every numeric field inherits it — grew ▲▼ nudge buttons (Shift = ×10)
  beside the unit input, keeping native ArrowUp/Down; both write through the
  same responsive path as typing and the canvas drag handles, live per tick.
- **Polish (#7–#13):** a curated WeIdea color palette in the pickers (hides
  the bridged utility slots like "Notices - Warning"); US-English spelling
  with a lint rule; a brand-orange "Section with columns" variation icon;
  quiet selection states that keep an empty column's placeholder legible;
  a row layout-picker gap; standalone-label spacing; Mac ⌥/⌘ modifier
  labels on the drag chips.
- New guardrails: a logged-out real-editor render test (drives the editor,
  publishes, asserts computed styles for a cookie-less visitor at nested
  section + column level) closing the class of bug behind #14, plus a
  numeric-stepper e2e.

**#14 stays open pending staging3 verification** — closure gates on the
beta.7 plugin painting on staging3 with SG Optimizer (Minify HTML / Combine
CSS) and Rocket Loader still ON.

## 0.3.0-beta.6 — Canvas drag affordances (July 2026, beta track)

Section/Row/Column parity, part 2 (per docs/weidea-studio-parity-spec.md,
Part 2). Direct-manipulation on the canvas — an editor-only layer that
adds **zero frontend bytes** (a new `canvas:check` CI gate greps the built
visitor assets for canvas markers and fails on any leak). Every drag
writes through the SAME `writeResponsiveValue` the inspector uses — one
attribute, two hands, never two systems.

- **Show structure** — a wireframe toggle (⌘K command, More-menu item, and
  a real ⌘/Ctrl+Shift+O shortcut) dims a dashed outline over every WeIdea
  block boundary. Hover shows a dotted outline + a block-name chip; the CSS
  lives inside the editor iframe.
- **Box-model handles** — the selected block gets draggable edges:
  padding (green, inside), margin (orange, outside), and Section min-height
  (blue, on the bottom edge), with a live value chip, a devtools-style
  fill, and spacing-scale snap ticks. Cmd/Ctrl bypasses snap, Shift steps
  by 8, Alt mirrors the opposite side (and un-mirrors cleanly on release).
  A drag writes only the ACTIVE device and lights that device's override
  dot; double-click resets to inherited.
- **Column dividers** — drag the boundary between two columns to
  redistribute the pair's width (device-aware, clamped so neither column
  can collapse or go negative).
- Grabs are movement-gated (a click never materialises an inherited value
  into a hard override), drags coalesce into ONE undo step, interrupted
  drags (pointercancel / lost capture) clean up, and handles survive editor
  iframe swaps. Snap targets source the theme's `spacingSizes`
  (px/rem/em), falling back to the house scale.
- New load-bearing e2e: structure toggle via the real shortcut + a
  bottom-padding drag proving the device-aware write, the override dot, and
  per-device independence.

## 0.3.0-beta.5 — Section/Row/Column parity, part 1 (July 2026, beta track)

Muscle-memory parity with the Kadence Row Layout controls (per
docs/weidea-studio-parity-spec.md, Block 1), so building the Mall in
WeIdea never forces a fallback. All registry-driven with help + demo
specs (CI-enforced); colours token-first.

- **Backgrounds** — image (focal point, size, repeat, scroll/fixed
  attachment), structured gradient, and a per-breakpoint overlay (colour
  or gradient, opacity, blend mode). A typed, validated composer emits
  pure CSS: the overlay is a `::before { z-index:-1 } + isolation:isolate`
  pseudo-element, so it needs no markup change and works on Column (no
  inner wrapper) as well as Section. Every injection vector is covered by
  composer unit assertions.
- **Full box model** — four-side responsive padding + margin (logical
  properties), min-height + vertical content alignment, section
  text/link/link-hover colour, border/radius/token-based shadow, column +
  stacked-row gutters, collapse-order reverse, semantic HTML tag, z-index,
  device visibility, and an Advanced-fold custom-CSS box.
- **Insert-time layout picker** — an empty Row offers a 1–6 column layout
  picker, plus a Section → Row → Columns variation.
- Zero frontend-JS cost: new controls are editor-only weight; backgrounds
  are generated CSS. Frontend budget unchanged. No block deprecations.
  New control types: media, gradient, overlay, visibility.

## 0.3.0-beta.4 — Polish + guards (July 2026, beta track)

- **ⓘ popover footer spacing** — the "Apply an example" button and
  "Open the Learn panel" link were crowded; the actions row now has a
  comfortable gap, padding above, and a hairline separator from the demo.
  Component-level, so every panel popover is fixed at once.
- **Inserter ordering** — WeIdea Studio is forced to the TOP block
  category (block_categories_all at priority 99999, dedup + unshift),
  above Kadence on the coexisting pilot. (Landed on main after beta.3;
  first release to carry it.)
- **Two new release gates**, beside registry-coverage and budget:
  docs-currency (CHANGELOG + build-status must reference the version
  being released) and brand-casing (fails on the mis-cased "Weidea" —
  the brand is "WeIdea", capital I). No mis-cased strings exist today;
  the guard keeps it that way.

## 0.3.0-beta.3 — Learn-in-place v1 (July 2026, beta track)

*Reprioritized ahead of interactive blocks by planning: the ⓘ system is
for learning the tool while building with it — which is happening now.*

- **The ⓘ system on every panel** — a ghost-quiet affordance (brightens
  on hover/focus, keyboard-reachable) opening a popover with: the
  plain-English what-this-changes sentence; a **live demo compiled from
  the panel demo spec by the real engine** (before/after preview for
  style panels, looping entrance for motion panels); **Apply an
  example** dropping starter values into the controls; and the Learn
  panel door. While open, the affected block highlights on the canvas.
- **Preset previews** — the Animate tab Entrance control is now a tile
  grid; hovering any tile plays a live mini-loop of the real effect
  before you apply it.
- **Learn panel v1** — a searchable sidebar auto-generated from every
  registry schema (14 blocks, 23 panels, 62 controls with their help).
  Generated from the source of truth: it cannot drift and cannot be
  somewhere else.
- All editor-only weight; visitor budgets unchanged.

## 0.3.0-beta.2 — First motion effects + foundation hardening (July 2026, beta track)

- **Counter** — climbs to its figure on first sight (per-block ~1 KB view
  script, loaded only where the block renders; markup saves the FINAL
  number for no-JS/SEO; reduced-motion keeps it still).
- **Marquee** — the endlessly gliding ribbon, pure CSS, ZERO JavaScript;
  screen-reader-safe duplicate run; speed/direction controls;
  reduced-motion stands still.
- **Typed Text** — typewriter heading cycling one-phrase-per-line, with
  standing lead, typed-part color, and true heading levels; first phrase
  saves as a complete sentence.
- New registry control types: text, textarea (six total).
- Safe mode now dequeues every block view script generically.
- **Foundation hardening** (planning pass): device list centralized to one
  ordered, filterable source (N-breakpoint-ready, no content migration);
  UID claims seed from the whole document (duplicate/paste-safe, e2e
  covered); registry CSS emits logical properties (RTL ~free); textdomain
  + script translations + runtime registry-string gettext; uploads/weidea/
  established; uninstall removes plugin data only — never content.

## 0.3.0-beta.1 — The Animate tab (July 2026, beta track)

- **Animate tab on every WeIdea block** — Tier 1 of the headline motion
  module. Entrances (fade, rise, slide from left/right, grow, blur into
  focus, wipe across/upward), speed and delay in plain English, "reveal
  children one by one" stagger, and hover lift/grow. Defined once as a
  shared registry panel; present on all 11 blocks.
- **Motion tokens v1** — `--wi-motion-*` (house easing curve, three
  durations, stagger rhythm, travel distance). Every preset rides them;
  brand zones can override them for per-brand motion personalities.
- **No-bloat discipline**: animation never touches saved markup (classes
  stamped at render — zero block deprecations); the whole runtime is a
  ~1.5 KB dependency-free IntersectionObserver helper + ~2 KB CSS loaded
  only on pages that animate; no-JS visitors lose nothing; visitors who
  prefer reduced motion get fade-only; safe mode renders everything
  static instantly.
- Editor: live "Preview entrance" replaying the real engine's classes on
  the canvas.

## 0.2.0-beta.2 — Touch ID deploys + branded inserter (July 2026, beta track)

- **WebAuthn (Touch ID) deploy ceremony** — register a passkey under
  Settings → WeIdea Studio; the workbench Deploy button confirms with
  Touch ID and falls back to the typed key. Verified entirely
  server-side (audited minimal CBOR decoder, COSE ES256/P-256 → PEM,
  OpenSSL signature check, challenge/origin/rpId/UV validation) — zero
  third-party dependencies. e2e drives the full ceremony against a
  virtual platform authenticator on every release.
- **One branded inserter home** — a "WeIdea Studio" category (first in
  the list) plus a block collection on the weidea/ namespace with the
  brand mark; all blocks grouped together, nothing in WP's default
  categories.
- Fix: workbench Deploy/Preview clicks landing before staging resolved
  were silently dropped; they now queue.

## 0.2.0-beta.1 — Phase 1 core (July 2026, beta track)

- **The block library** — the full v1 layout + content set, all
  registry-driven with help text and demo specs on every panel (37
  controls): Section, Row, Column (responsive widths, stack-on-phones
  honoring the site's configurable breakpoints), Advanced Heading, Text,
  Buttons/Button (hover-state color bindings), Image, Icon (curated
  inline-SVG set), Spacer, Divider. Every WeIdea block icon carries the
  dark-orange brand mark.
- **The workbench** — admin-bar button + ⌘E on any editable live page
  opens a full-screen overlay with the real block editor on a STAGED
  copy. Loader ships to logged-in editors only; visitors get zero bytes
  (e2e-verified against a logged-out context).
- **Staged deploys** — edits land on a hidden staged clone; a signed
  preview link renders staged content at the real live URL (and dies on
  deploy). The deploy ceremony: dedicated `wi_deploy` capability, typed
  deploy key (hashed at rest, failures rate-limited), live content
  snapshotted as a tagged rollback point, SiteGround cache purged when
  present, who/when/what audit log, one-click rollback. (The WebAuthn /
  Touch ID ceremony lands on this same endpoint in the next beta.)
- **Safe-mode kill switch** — Settings toggle + admin-bar badge +
  query-param override; disables WeIdea frontend JS site-wide.
- **Settings → WeIdea Studio** — breakpoints, release channel, deploy
  key, safe mode.
- Registry engine: new control types (select, toggle), hover-state CSS
  bindings, value templates, and breakpoint-aware runtime rules.

## 0.1.0 — Phase 0 scaffold (July 2026)

- **Control registry core** — inspector panels render from JSON schemas in
  `registry/blocks/`; the server generates CSS from the same files. Every
  panel and control carries a plain-English label and help text, enforced
  in CI (`npm run registry:check`).
- **Design tokens** — `--wi-*` custom properties with the Kadence palette
  bridge (`--wi-accent` → `--global-palette1`, etc.), so blocks re-skin per
  brand zone through the pilot site's existing body-class remaps.
- **Section proof block** — `weidea/section`, with registry-driven
  Background / Spacing / Content width panels, independent
  desktop/tablet/phone values with inheritance and override dots, and
  site-configurable breakpoints (`wi_breakpoints` option, REST-exposed).
- **No-bloat contract enforcement** — zero assets on pages without WeIdea
  blocks (e2e-verified), per-block conditional loading, CI budget gate with
  numbers written into every release.
- **Self-hosted update channel, two-track** — manifest-based updater
  (12-hour cache, the plugin's only outbound call) serving `stable` and
  `beta` tracks; each site picks its channel on the Plugins screen or via
  REST (`wi_update_channel`). The manifest retains recent releases, and
  the plugin row offers **one-click rollback** to the previous retained
  version through WordPress's native upgrade flow. Detection, channel
  switching, install, and rollback are all covered by the e2e suite
  against a locally served channel.
- **Tooling** — `@wordpress/scripts` build, wp-env disposable WordPress,
  Playwright e2e harness, GitHub Actions CI, versioned release zip.
