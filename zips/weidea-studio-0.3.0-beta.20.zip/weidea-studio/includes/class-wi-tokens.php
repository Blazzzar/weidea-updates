<?php
/**
 * Design tokens, including the Kadence palette bridge.
 *
 * Coexistence contract (current direction): WeIdea tokens ALIAS TO the
 * site's existing Kadence global palette slots, so every WeIdea block
 * automatically re-skins per brand zone through the body-class palette
 * remaps already built on the pilot site. Sites without Kadence simply
 * get the fallback values. Later the bridge flips — brands become native
 * WeIdea token scopes and the Kadence slots alias FROM them.
 *
 * Kadence slot conventions this maps: 1–2 accents, 3–6 text (strongest to
 * faintest), 7–9 backgrounds (softest to base).
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Token definitions and CSS output.
 */
final class WI_Tokens {

	/**
	 * The token map: name (without the --wi- prefix) => CSS value.
	 *
	 * @return string[]
	 */
	public static function tokens() {
		/**
		 * Filter the design tokens. Values are raw CSS; the Kadence bridge
		 * lives in the defaults and can be replaced wholesale on sites
		 * that never ran Kadence.
		 *
		 * @param string[] $tokens Token name => CSS value.
		 */
		return apply_filters(
			'wi_design_tokens',
			array(
				'accent'        => 'var(--global-palette1, #2b6aa3)',
				'accent-alt'    => 'var(--global-palette2, #215181)',
				'text-strong'   => 'var(--global-palette3, #1f2933)',
				'text'          => 'var(--global-palette4, #3e4c59)',
				'text-soft'     => 'var(--global-palette5, #52606d)',
				'text-faint'    => 'var(--global-palette6, #7b8794)',
				'bg-soft'       => 'var(--global-palette7, #f5f7fa)',
				'bg-alt'        => 'var(--global-palette8, #f9fafb)',
				'bg'            => 'var(--global-palette9, #ffffff)',
				'content-width' => '1160px',

				// Motion tokens v1 — the house personality. Every preset
				// and (later) every timeline references these; brand
				// zones can override them (Retrobotics snappy, Knocking
				// Ghost slow and eerie) via body-class scoping.
				'motion-duration'      => '0.6s',
				'motion-duration-fast' => '0.35s',
				'motion-duration-slow' => '1s',
				'motion-ease'          => 'cubic-bezier(0.22, 1, 0.36, 1)',
				'motion-stagger'       => '90ms',
				'motion-distance'      => '28px',

				// House shadows — one shadow language across the whole
				// site; the Section/Column shadow control picks by token.
				'shadow-sm' => '0 1px 2px rgba(0,0,0,0.06), 0 1px 3px rgba(0,0,0,0.10)',
				'shadow-md' => '0 4px 12px rgba(0,0,0,0.10), 0 2px 4px rgba(0,0,0,0.06)',
				'shadow-lg' => '0 12px 32px rgba(0,0,0,0.14), 0 4px 8px rgba(0,0,0,0.08)',
			)
		);
	}

	/**
	 * Breakpoint-aware base rules shared by all block instances — rules
	 * that need the site's configured breakpoints (which static block
	 * stylesheets can't know), generated once per page, not per instance.
	 *
	 * @return string
	 */
	public static function runtime_css() {
		$bp  = WI_Breakpoints::get();
		$css = '@media (max-width:' . $bp['mobile'] . 'px){'
			. '.wi-row--stack{flex-direction:column;}'
			. '.wi-row--stack.wi-row--reverse{flex-direction:column-reverse;}'
			. '.wi-row--stack > .wi-column{flex:1 1 auto;}'
			. '}';

		/**
		 * Filter the breakpoint-aware shared rules.
		 *
		 * @param string $css   Compiled CSS.
		 * @param int[]  $bp    Current breakpoints.
		 */
		return apply_filters( 'wi_runtime_css', $css, $bp );
	}

	/**
	 * ⛔ E-V2-4b — THE ONE LIST, IN PIXELS: 0 to 120 in tens.
	 *
	 * These thirteen numbers are the sidebar's preset sizes AND the canvas
	 * drag's tick marks, and they are one list because Chris ruled it one on
	 * August 12 2026. Before that ruling they were two: this function read the
	 * theme's `spacingSizes` while #60's preset mode was going to step in tens,
	 * so the same Section would have snapped to 48 by dragging on the page and
	 * offered no 48 in the sidebar. A person finds that inside a day.
	 *
	 * ⚑ THE COST HE ACCEPTED, WRITTEN DOWN RATHER THAN LEFT TO BE
	 * REDISCOVERED: **the canvas drag stops being theme-aware.** A theme that
	 * declares `spacingSizes` no longer steers the snap. `wi_spacing_scale`
	 * below is still a filter, so a theme can move BOTH consumers together —
	 * which is the only shape in which they cannot drift apart again. The
	 * theme-reading code this replaces is not "temporarily disabled"; it is
	 * the behaviour the ruling removed, and leaving it in place behind a flag
	 * would leave two lists one edit away from existing again.
	 *
	 * ⚑ AND IT WAS NOT HYPOTHETICAL. The first run of the linked slider on the
	 * test site drew its stops at 7, 10, 11, 16, 17, 20, 24, 27, 30, 36, 37,
	 * 47, 54, 57, 67, 77, 81 — the theme's own fluid sizes resolved to pixels,
	 * on a control whose whole ruling is "increments of ten".
	 *
	 * ⚑ TWO COPIES OF THIS LITERAL EXIST, ONE PER LANGUAGE, AND A GATE HOLDS
	 * THEM EQUAL. `src/registry/spacing-stops.js` carries `HOUSE_STOPS` for
	 * the case where nothing has been localised yet, and CG-STOPS in
	 * `bin/check-registry-coverage.mjs` fails the build unless the two lists
	 * are the same numbers in the same order — and fails, rather than skips,
	 * if it cannot find either one.
	 *
	 * @return int[]
	 */
	public static function spacing_scale() {
		$scale = array( 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120 );

		/**
		 * Filter the spacing scale — the sidebar's preset sizes and the
		 * canvas drag's ticks, which are one list (E-V2-4b).
		 *
		 * @param int[] $scale Px values.
		 */
		return apply_filters( 'wi_spacing_scale', $scale );
	}

	/**
	 * The compiled :root ruleset.
	 *
	 * @return string
	 */
	public static function css() {
		$out = ':root{';
		foreach ( self::tokens() as $name => $value ) {
			$name = preg_replace( '/[^a-z0-9-]/', '', strtolower( (string) $name ) );
			if ( '' === $name || ! is_string( $value ) || preg_match( '/[{};<>]/', $value ) ) {
				continue;
			}
			$out .= '--wi-' . $name . ':' . $value . ';';
		}
		return $out . '}';
	}
}
