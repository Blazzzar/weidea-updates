<?php
/**
 * Frontend asset loading — the enforcement point of the no-bloat contract.
 *
 * Rule 1: a page containing no WeIdea blocks enqueues NOTHING. Rule 2: a
 * page pays only for the blocks it contains. Block styles are deliberately
 * NOT registered through block.json (classic themes would enqueue them on
 * every page); this class owns registration and enqueues per block, per
 * page, deterministically:
 *
 *  - On singular pages, has_block() decides in wp_enqueue_scripts, so
 *    styles print in <head>.
 *  - Everywhere else (archives, widgets, patterns), a render_block filter
 *    catches any weidea/* block as a fallback; those styles print late but
 *    never load on pages without blocks.
 *
 * The same render_block filter injects each block instance's generated
 * responsive CSS immediately before its markup.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Conditional asset enqueueing.
 */
final class WI_Assets {

	/**
	 * Instance CSS already printed, keyed by uniqueId.
	 *
	 * @var bool[]
	 */
	private static $printed = array();

	/**
	 * Whether the token stylesheet has been enqueued this request.
	 *
	 * @var bool
	 */
	private static $tokens_done = false;

	/**
	 * Hook registration.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_styles' ), 20 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_for_content' ) );
		add_filter( 'render_block', array( __CLASS__, 'render_block' ), 10, 2 );
		add_action( 'enqueue_block_assets', array( __CLASS__, 'editor_tokens' ) );
	}

	/**
	 * Register (never enqueue) each block's frontend stylesheet.
	 */
	public static function register_styles() {
		foreach ( WI_Blocks::BLOCKS as $slug ) {
			$rel = 'build/blocks/' . $slug . '/style-index.css';
			if ( file_exists( WI_PLUGIN_DIR . $rel ) ) {
				wp_register_style( 'wi-block-' . $slug, WI_PLUGIN_URL . $rel, array(), WI_VERSION );
			}
		}
	}

	/**
	 * Head-time enqueue for singular content, based on has_block().
	 */
	public static function enqueue_for_content() {
		if ( ! is_singular() ) {
			return;
		}
		$post = get_post();
		if ( ! $post ) {
			return;
		}
		foreach ( WI_Blocks::BLOCKS as $slug ) {
			if ( has_block( 'weidea/' . $slug, $post ) ) {
				self::enqueue_block( $slug );
			}
		}
	}

	/**
	 * Fallback enqueue + instance CSS injection at render time.
	 *
	 * @param string $content Rendered block HTML.
	 * @param array  $block   Parsed block.
	 * @return string
	 */
	public static function render_block( $content, $block ) {
		$name = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
		if ( 0 !== strpos( $name, 'weidea/' ) ) {
			return $content;
		}

		self::enqueue_block( substr( $name, 7 ) );

		$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
		$uid   = isset( $attrs['uniqueId'] ) ? preg_replace( '/[^a-zA-Z0-9_-]/', '', (string) $attrs['uniqueId'] ) : '';
		if ( '' !== $uid && empty( self::$printed[ $uid ] ) ) {
			$css = WI_Block_CSS::generate( $name, $attrs );
			if ( '' !== $css ) {
				self::$printed[ $uid ] = true;
				$content               = '<style id="wi-css-' . esc_attr( $uid ) . '">' . $css . '</style>' . $content;
			}
		}
		return $content;
	}

	/**
	 * Enqueue one block's stylesheet plus the shared tokens (once).
	 *
	 * @param string $slug Block slug.
	 */
	private static function enqueue_block( $slug ) {
		self::tokens();
		if ( wp_style_is( 'wi-block-' . $slug, 'registered' ) ) {
			wp_enqueue_style( 'wi-block-' . $slug );
		}
	}

	/**
	 * Print the design tokens once per request, as inline CSS on a
	 * src-less handle — a page without WeIdea blocks never gets them.
	 */
	private static function tokens() {
		if ( self::$tokens_done ) {
			return;
		}
		self::$tokens_done = true;
		wp_register_style( 'wi-tokens', false, array(), WI_VERSION );
		wp_enqueue_style( 'wi-tokens' );
		wp_add_inline_style( 'wi-tokens', WI_Tokens::css() . WI_Tokens::runtime_css() );
	}

	/**
	 * Editor canvas assets (admin only — enqueue_block_assets also fires
	 * on the frontend, where the conditional path above owns loading).
	 * The canvas gets the tokens plus every block's frontend stylesheet,
	 * so what you design against is what ships.
	 */
	public static function editor_tokens() {
		if ( ! is_admin() ) {
			return;
		}
		wp_register_style( 'wi-tokens-editor', false, array(), WI_VERSION );
		wp_enqueue_style( 'wi-tokens-editor' );
		wp_add_inline_style( 'wi-tokens-editor', WI_Tokens::css() . WI_Tokens::runtime_css() );

		foreach ( WI_Blocks::BLOCKS as $slug ) {
			if ( wp_style_is( 'wi-block-' . $slug, 'registered' ) ) {
				wp_enqueue_style( 'wi-block-' . $slug );
			}
		}
	}
}
