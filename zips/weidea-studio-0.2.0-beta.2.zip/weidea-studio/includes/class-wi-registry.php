<?php
/**
 * Control registry — the single source of truth for every inspector panel.
 *
 * Each block's panels, controls, bindings, and help text live in a JSON
 * schema under registry/blocks/. The editor renders its panels FROM these
 * schemas, and the server generates CSS FROM the same schemas, so the two
 * can never drift. This is the seam the Control Forge builds against:
 * a new control is a schema entry plus (at most) a control-type renderer.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Loads and serves control-registry schemas.
 */
final class WI_Registry {

	/**
	 * Loaded schemas, keyed by block name (e.g. "weidea/section").
	 *
	 * @var array[]|null
	 */
	private static $schemas = null;

	/**
	 * All registered block schemas.
	 *
	 * @return array[] Schemas keyed by block name.
	 */
	public static function all() {
		if ( null !== self::$schemas ) {
			return self::$schemas;
		}
		self::$schemas = array();

		$files = glob( WI_PLUGIN_DIR . 'registry/blocks/*.json' );
		if ( is_array( $files ) ) {
			foreach ( $files as $file ) {
				$data = json_decode( (string) file_get_contents( $file ), true );
				if ( is_array( $data ) && ! empty( $data['block'] ) ) {
					self::$schemas[ $data['block'] ] = $data;
				}
			}
		}

		/**
		 * Filter the loaded registry schemas. Forged controls arriving via
		 * the update channel land in the JSON files; this filter exists for
		 * per-site experiments and the future per-site on/off toggle.
		 *
		 * @param array[] $schemas Schemas keyed by block name.
		 */
		self::$schemas = apply_filters( 'wi_registry_schemas', self::$schemas );

		return self::$schemas;
	}

	/**
	 * Schema for one block.
	 *
	 * @param string $block Block name, e.g. "weidea/section".
	 * @return array|null
	 */
	public static function schema_for( $block ) {
		$all = self::all();
		return isset( $all[ $block ] ) ? $all[ $block ] : null;
	}
}
