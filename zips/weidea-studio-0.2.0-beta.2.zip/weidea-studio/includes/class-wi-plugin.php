<?php
/**
 * Plugin bootstrap.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Wires the plugin's modules together. Modules are internal architecture —
 * they surface to the user as one workbench, never as separate tools.
 */
final class WI_Plugin {

	/**
	 * Singleton instance.
	 *
	 * @var WI_Plugin|null
	 */
	private static $instance = null;

	/**
	 * Get (and lazily create) the plugin instance.
	 *
	 * @return WI_Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Boot the modules.
	 */
	private function __construct() {
		WI_Breakpoints::init();
		WI_Blocks::init();
		WI_Assets::init();
		WI_Updater::instance();
		WI_Updater_Admin::init();
		WI_WebAuthn::init();
		WI_Staging::init();
		WI_Deploy::init();
		WI_Workbench::init();
		WI_Settings_Page::init();

		add_action( 'admin_notices', array( $this, 'missing_build_notice' ) );
	}

	/**
	 * Dev convenience: warn when the plugin is running from source without
	 * a build. A packaged zip always ships with build/ included.
	 */
	public function missing_build_notice() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		if ( file_exists( WI_PLUGIN_DIR . 'build/blocks/section/block.json' ) ) {
			return;
		}
		printf(
			'<div class="notice notice-warning"><p>%s</p></div>',
			esc_html__( 'WeIdea Studio: no build found. Run "npm install && npm run build" in the plugin directory.', 'weidea-studio' )
		);
	}
}
