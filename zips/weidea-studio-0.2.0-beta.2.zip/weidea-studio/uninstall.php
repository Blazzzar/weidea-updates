<?php
/**
 * Uninstall cleanup.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'wi_breakpoints' );
delete_option( 'wi_update_channel' );
delete_option( 'wi_deploy_key_hash' );
delete_option( 'wi_deploy_log' );
delete_option( 'wi_safe_mode' );
delete_site_transient( 'wi_update_manifest' );
delete_site_transient( 'wi_rollback_target' );
