<?php
/**
 * Staged edits: workbench saves never touch the live post.
 *
 * Each live post gets at most one staged copy (a hidden draft clone,
 * linked by meta). Editing happens on the copy through the normal block
 * editor; a signed preview link renders the staged content at the REAL
 * live URL for anyone holding the link; Deploy (WI_Deploy) publishes the
 * copy over the live post and retires it.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Staged-copy lifecycle, preview links, REST surface.
 */
final class WI_Staging {

	const META_KEY = '_wi_staging_of';

	/**
	 * What the LIVE page said at the moment the copy was taken — a
	 * fingerprint of its title and content, and only those two.
	 *
	 * This is the baseline Deploy compares against (finding #42). Dates
	 * cannot do this job: the copy is inserted as a draft, core registers
	 * draft with 'date_floating' => true, and wp_insert_post therefore
	 * writes '0000-00-00 00:00:00' into BOTH GMT columns — so a date check
	 * would find the live page newer than its own copy every single time
	 * and refuse every deploy on every page from the day it shipped.
	 */
	const FROM_META = '_wi_staged_from';

	/**
	 * What the COPY said at the moment it was made.
	 *
	 * The baseline for "has anyone actually changed this copy?" (Q1). It
	 * exists as a SECOND value rather than re-using FROM_META because
	 * inserting the copy is not always byte-lossless, which was MEASURED
	 * rather than assumed: with kses filters active, a live page holding
	 * `<!-- wp:html --><!-- /wp:html -->` comes back out of wp_insert_post
	 * as `<!-- wp:html /-->`. One stored value would then make a
	 * brand-new copy read as "already changed" and put the words
	 * "this copy has changes" on a copy nobody had touched.
	 *
	 * ONE definition of "different" all the same (design risk R-E): both
	 * stamps are made by fingerprint() and both are compared by it. Two
	 * baselines, because there are two objects and two questions — not two
	 * definitions.
	 */
	const COPY_META = '_wi_staged_copy';

	/**
	 * When the copy was made — a stamp we write ourselves, never read as
	 * the gate. It is what lets the refusal say WHEN: "you took this copy
	 * on Tuesday; the page changed on Thursday" is a far more useful
	 * sentence than "the page changed."
	 */
	const AT_META = '_wi_staged_at';

	/**
	 * Hook registration.
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		add_action( 'pre_get_posts', array( __CLASS__, 'hide_staged_copies' ) );
		add_action( 'wp', array( __CLASS__, 'maybe_preview' ) );
	}

	/**
	 * REST routes.
	 */
	public static function register_routes() {
		$post_arg = array(
			'post' => array(
				'type'     => 'integer',
				'required' => true,
			),
		);

		// WHO MAY THROW A COPY AWAY: anyone who can edit the page, the same
		// bar as making one (Chris, Q4, August 19 2026). The seam between
		// "can edit" and "can deploy" exists for a real reason — the day Jen
		// edits without deploying — but discarding is not deploying. It
		// changes nothing the public can see, and putting it behind
		// wi_deploy means the person who made the mess cannot tidy it and
		// has to come and find Chris. That is a bottleneck dressed as a
		// safeguard. Whoever can make a copy can throw one away.
		$can_edit = function ( $request ) {
			return current_user_can( 'edit_post', (int) $request['post'] );
		};

		register_rest_route(
			'wi/v1',
			'/stage',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_stage' ),
				'permission_callback' => $can_edit,
				'args'                => $post_arg,
			)
		);

		// The read side. The Workbench's discard confirm has to describe the
		// copy AS IT IS NOW — somebody may have been editing it in the
		// overlay for twenty minutes since it was opened — and it must get
		// those facts without calling /stage, because /stage CREATES a copy
		// when there isn't one. A confirm that quietly re-makes the thing it
		// is about to throw away would be a memorable bug.
		register_rest_route(
			'wi/v1',
			'/staged',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_staged' ),
				'permission_callback' => $can_edit,
				'args'                => $post_arg,
			)
		);

		register_rest_route(
			'wi/v1',
			'/discard',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_discard' ),
				'permission_callback' => $can_edit,
				'args'                => $post_arg,
			)
		);

		register_rest_route(
			'wi/v1',
			'/undiscard',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_undiscard' ),
				'permission_callback' => $can_edit,
				'args'                => $post_arg + array(
					'staged' => array(
						'type'     => 'integer',
						'required' => true,
					),
				),
			)
		);
	}

	/**
	 * The fingerprint of exactly what Deploy overwrites, and nothing else.
	 *
	 * WI_Deploy::rest_deploy writes post_title and post_content over the
	 * live post and touches nothing else — not the excerpt, not the
	 * featured image, not page attributes, not block-level meta. So this
	 * hashes those two and only those two, and the check's scope and the
	 * damage's scope are the same shape by construction. Change one without
	 * the other and this stops meaning what it says.
	 *
	 * The NUL between them is a separator, not decoration: without it a
	 * title of "ab" with an empty body and a title of "a" with a body of
	 * "b" fingerprint identically.
	 *
	 * @param string $title   Post title.
	 * @param string $content Post content.
	 * @return string Hex digest.
	 */
	public static function fingerprint( $title, $content ) {
		return hash( 'sha256', (string) $title . "\n\0\n" . (string) $content );
	}

	/**
	 * fingerprint() for a post object.
	 *
	 * @param WP_Post|null $post Post.
	 * @return string Hex digest, or '' when there is no post.
	 */
	public static function post_fingerprint( $post ) {
		return $post instanceof WP_Post
			? self::fingerprint( $post->post_title, $post->post_content )
			: '';
	}

	/**
	 * Has anyone actually CHANGED the copy since it was made?
	 *
	 * Q1: a copy only counts once it differs from what it was cloned from.
	 * The dialog's own sentence predicts that "your changes will be
	 * replaced by that copy" — when the copy is identical to the page it
	 * came from, deploying it replaces nothing and the prediction is false.
	 * A warning that fires when it is wrong is exactly the habituation E2's
	 * narrowing existed to prevent, arriving through a different door.
	 *
	 * ⚑ RISK R-D — WHY "NO STAMP" MEANS TRUE HERE AND FALSE IN live_moved().
	 * Both mean the same thing: "can't tell — behave exactly as the build
	 * before this one did." Before this shipped the dialog fired whenever a
	 * copy existed, so no stamp must arm it. Before this shipped Deploy
	 * never refused, so no stamp must let it through. The two answers look
	 * opposite and are the same rule.
	 *
	 * @param int $staged_id Copy ID.
	 * @return bool
	 */
	public static function copy_differs( $staged_id ) {
		$made = (string) get_post_meta( (int) $staged_id, self::COPY_META, true );
		if ( '' === $made ) {
			return true;
		}
		return self::post_fingerprint( get_post( (int) $staged_id ) ) !== $made;
	}

	/**
	 * Has the LIVE page changed since the copy was taken?
	 *
	 * Finding #42, and Q7: this compares CONTENT, never dates. Plenty of
	 * things nudge a page's modified stamp without changing a word of it —
	 * measured on this very install, a re-save with identical title and
	 * body moved post_modified by a second and left the fingerprint
	 * untouched — and a warning that fires on nothing trains people to
	 * click past it.
	 *
	 * Its one blind spot is benign: change the live page and change it
	 * back, and the fingerprint matches and nothing warns, because there is
	 * nothing to lose.
	 *
	 * See copy_differs() for why a missing stamp answers false here.
	 *
	 * @param WP_Post|null $post      Live post.
	 * @param int          $staged_id Copy ID.
	 * @return bool
	 */
	public static function live_moved( $post, $staged_id ) {
		$from = (string) get_post_meta( (int) $staged_id, self::FROM_META, true );
		if ( '' === $from ) {
			return false;
		}
		return self::post_fingerprint( $post ) !== $from;
	}

	/**
	 * Everything a person needs to SEE about a copy before anything offers
	 * to throw it away.
	 *
	 * This shape exists because of the August 12 sighting on finding #55.
	 * The dialog fired on every save, and Chris's first two moves were to
	 * purge the SiteGround cache and to check no preview window was open.
	 * Neither could ever have helped — the copy is a draft post carrying
	 * _wi_staging_of, not a cached file and not an open tab, and
	 * hide_staged_copies() keeps it out of the Pages list, so he could not
	 * see or delete the thing the dialog was about. The missing door was
	 * worse than "there is no discard button": the object had no visible
	 * existence at all. A bare "Discard" on an invisible object asks
	 * somebody to delete something they cannot look at.
	 *
	 * @param int $post_id Live post ID.
	 * @return array|null Null when there is no copy.
	 */
	public static function staged_facts( $post_id ) {
		$staged_id = self::staged_id( $post_id );
		if ( ! $staged_id ) {
			return null;
		}
		$at = (int) get_post_meta( $staged_id, self::AT_META, true );
		return array(
			'id'     => $staged_id,
			'at'     => $at,
			'edited' => self::copy_differs( $staged_id ),
			// Whether "edited" is a MEASUREMENT or a fallback. A copy made
			// before this shipped carries no baseline, so copy_differs()
			// answers true to keep the dialog behaving as it always did
			// (R-D) — but that is "we cannot tell", not "somebody changed
			// it", and the confirm must not say the second when it means the
			// first. On upgrade morning every existing copy is this one.
			'known'  => '' !== (string) get_post_meta( $staged_id, self::COPY_META, true ),
			'madeOn' => $at ? self::human_stamp( $at ) : '',
		);
	}

	/**
	 * A stamp written the way the rest of WordPress writes dates.
	 *
	 * Chris ruled the real date and time over "2 days ago" (August 26
	 * 2026, on the mock): these sentences are about which of two things
	 * happened first, and clock times can be checked against what a person
	 * remembers doing. Reading the site's own format is what makes this
	 * match the revision list "See what changed" lands on.
	 *
	 * @param int $timestamp Unix timestamp.
	 * @return string
	 */
	public static function human_stamp( $timestamp ) {
		return sprintf(
			/* translators: 1: a date, 2: a time of day. */
			__( '%1$s at %2$s', 'weidea-studio' ),
			wp_date( get_option( 'date_format' ), (int) $timestamp ),
			wp_date( get_option( 'time_format' ), (int) $timestamp )
		);
	}

	/**
	 * Create (or reuse) the staged copy for a post.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function rest_stage( $request ) {
		$post = get_post( (int) $request['post'] );
		if ( ! $post || wp_is_post_revision( $post ) ) {
			return new WP_Error( 'wi_no_post', __( 'Post not found.', 'weidea-studio' ), array( 'status' => 404 ) );
		}

		$staged_id = self::staged_id( $post->ID );
		$created   = ! $staged_id;

		// ⛔ THE TRAP, AND IT IS THE SINGLE MISTAKE MOST LIKELY TO BE MADE
		// HERE BY A FUTURE AUTHOR BEING HELPFUL.
		//
		// The stamps are written in THIS BRANCH ONLY — when the copy is
		// created. Re-opening the Workbench re-uses the copy that already
		// exists (that is what the `if` is for), and it must NOT refresh
		// either stamp. Refreshing them would erase the very evidence the
		// deploy check exists to read, and it would do it silently, on the
		// most ordinary action in the whole product: opening the Workbench
		// again. Somebody stages, somebody else edits the live page,
		// somebody re-opens the Workbench to look — and the warning that
		// was about to save them quietly stops being possible.
		//
		// `staging-lifecycle.spec.js` asserts this by CONSEQUENCE rather
		// than by reading the meta: stage, edit live, stage again, and the
		// deploy must still refuse.
		if ( $created ) {
			$staged_id = wp_insert_post(
				array(
					'post_type'    => $post->post_type,
					'post_status'  => 'draft',
					'post_title'   => $post->post_title,
					'post_content' => $post->post_content,
					'meta_input'   => array(
						self::META_KEY  => $post->ID,
						self::FROM_META => self::post_fingerprint( $post ),
						self::AT_META   => time(),
					),
				),
				true
			);
			if ( is_wp_error( $staged_id ) ) {
				return $staged_id;
			}
			// Read the copy back rather than fingerprinting what we sent:
			// wp_insert_post runs the content through save filters, and
			// with kses active that is not always byte-lossless. The
			// baseline for "has anyone changed this copy" has to be what
			// the copy ACTUALLY became, or a brand-new copy reads as
			// already edited.
			update_post_meta(
				$staged_id,
				self::COPY_META,
				self::post_fingerprint( get_post( $staged_id ) )
			);
		}

		$stamped_at = (int) get_post_meta( $staged_id, self::AT_META, true );

		return rest_ensure_response(
			array(
				'staged_id'   => $staged_id,
				'edit_url'    => add_query_arg( 'wi-workbench', '1', get_edit_post_link( $staged_id, 'raw' ) ),
				'preview_url' => self::preview_url( $post->ID, $staged_id ),
				// Nothing downstream could previously tell "you already had
				// one of these" from "one has just been made for you", even
				// if it wanted to.
				'created'     => $created,
				'staged_at'   => $stamped_at,
				// Guarded, or a copy with no stamp reports itself as having
				// been made on 1 January 1970.
				'made_on'     => $stamped_at ? self::human_stamp( $stamped_at ) : '',
				'differs'     => self::copy_differs( $staged_id ),
				'title'       => $post->post_title,
			)
		);
	}

	/**
	 * The copy's facts, right now. Read-only, and it never creates one.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function rest_staged( $request ) {
		$post = get_post( (int) $request['post'] );
		if ( ! $post ) {
			return new WP_Error( 'wi_no_post', __( 'Post not found.', 'weidea-studio' ), array( 'status' => 404 ) );
		}
		return rest_ensure_response(
			array(
				'staged' => self::staged_facts( $post->ID ),
				'title'  => $post->post_title,
			)
		);
	}

	/**
	 * Throw the copy away — into the BIN, never a hard delete.
	 *
	 * Deploy's outright delete is safe because the content landed on the
	 * live page one line earlier. Discard has no such landing: this is the
	 * only place in the whole product where work is destroyed that has
	 * never existed anywhere else. So it goes to the WordPress trash and
	 * an Undo sits under it (Chris, Q3, August 19 2026).
	 *
	 * And binning needs NO query changes at all, which is most of why it
	 * is cheap: staged_id() already looks only at draft and pending, so a
	 * binned copy is automatically "not staged" everywhere — the sidebar
	 * sentence goes, the dialog stops, Deploy says "Nothing is staged."
	 * The door out works by moving one status.
	 *
	 * ⚑ WHAT THE BIN DOES AND DOES NOT BUY, said plainly so nobody
	 * describes it as bigger than it is. It buys the Undo. It does not put
	 * the copy in a list anybody can browse: hide_staged_copies() filters
	 * every admin list table on the _wi_staging_of key, and the Trash view
	 * is one of those tables, so a binned copy is out of sight there too.
	 * WordPress clears the trash on its own schedule after that
	 * (EMPTY_TRASH_DAYS — measured as 30 on this install).
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function rest_discard( $request ) {
		$post = get_post( (int) $request['post'] );
		if ( ! $post ) {
			return new WP_Error( 'wi_no_post', __( 'Post not found.', 'weidea-studio' ), array( 'status' => 404 ) );
		}
		$staged_id = self::staged_id( $post->ID );
		if ( ! $staged_id ) {
			return new WP_Error( 'wi_no_staged', __( 'Nothing is staged for this page.', 'weidea-studio' ), array( 'status' => 409 ) );
		}

		// ⛔ wp_trash_post() PERMANENTLY DELETES WHEN TRASH IS SWITCHED OFF.
		// Core's own first two lines: `if ( ! EMPTY_TRASH_DAYS ) { return
		// wp_delete_post( $post_id, true ); }`. So on any site carrying
		// `define( 'EMPTY_TRASH_DAYS', 0 )` — a common enough hardening —
		// the "bin, never delete" ruling would silently become a hard delete
		// on the ONE path in this product that destroys work existing
		// nowhere else, and the Undo underneath it would have nothing to
		// bring back.
		//
		// So the status is moved directly when trash is off. staged_id()
		// filters on draft/pending, so the copy stops being found either
		// way, and rest_undiscard() sets the status back explicitly rather
		// than relying on _wp_trash_meta_status — which is why it does not
		// matter that this route did not write one.
		//
		// The trade is stated rather than hidden: on such a site WordPress
		// runs no scheduled purge, so the copy sits in the bin indefinitely.
		// Keeping work nobody asked us to destroy is the right side to err
		// on, and it is the side Q3 ruled.
		$binned = EMPTY_TRASH_DAYS
			? wp_trash_post( $staged_id )
			: wp_update_post(
				array(
					'ID'          => $staged_id,
					'post_status' => 'trash',
				),
				true
			);

		if ( ! $binned || is_wp_error( $binned ) ) {
			return new WP_Error(
				'wi_discard_failed',
				__( 'The copy could not be thrown away.', 'weidea-studio' ),
				array( 'status' => 500 )
			);
		}

		return rest_ensure_response(
			array(
				'discarded' => true,
				'staged_id' => $staged_id,
				'post'      => $post->ID,
			)
		);
	}

	/**
	 * Undo — take the copy back out of the bin.
	 *
	 * ⛔ ONE RULE, OR THE UNDO LIES. If the copy is binned and somebody
	 * then opens the Workbench again, a NEW copy is created while the
	 * binned one still carries its _wi_staging_of. Restoring the old one
	 * would leave two, and staged_id() would start returning whichever the
	 * database happened to hand back first. So this REFUSES once a newer
	 * copy exists, in plain words, rather than quietly making a mess that
	 * shows up later as "Deploy used the wrong copy."
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function rest_undiscard( $request ) {
		$post_id   = (int) $request['post'];
		$staged_id = (int) $request['staged'];
		$staged    = get_post( $staged_id );

		// The copy must really be this page's copy, and really be in the
		// bin. Without both checks this route untrashes anything its caller
		// can name.
		// The link is read once and required to be a real, positive id that
		// matches — never `(int) '' === 0` quietly agreeing with a `$post_id`
		// of 0. The capability gate above already refuses post 0, and this
		// makes that belt-and-braces rather than load-bearing.
		$linked = (int) get_post_meta( $staged_id, self::META_KEY, true );
		if (
			! $staged
			|| $post_id < 1
			|| $linked < 1
			|| 'trash' !== $staged->post_status
			|| $linked !== $post_id
		) {
			return new WP_Error(
				'wi_no_binned_copy',
				__( 'That copy is not in the bin.', 'weidea-studio' ),
				array( 'status' => 404 )
			);
		}

		if ( self::staged_id( $post_id ) ) {
			return new WP_Error(
				'wi_newer_copy',
				__( 'There’s a newer copy of this page now, so the old one can’t be brought back.', 'weidea-studio' ),
				array( 'status' => 409 )
			);
		}

		if ( ! wp_untrash_post( $staged_id ) ) {
			// Trash switched off means rest_discard() moved the status by
			// hand and wrote no _wp_trash_meta_status, which some core
			// versions treat as nothing to untrash. Put it back directly.
			wp_update_post(
				array(
					'ID'          => $staged_id,
					'post_status' => 'draft',
				),
				true
			);
		}

		// Core's default for an untrashed post is 'draft', which is what
		// staged_id() wants — but wp_untrash_post_status is filterable, and
		// a site that filters it to 'publish' would put a duplicate of the
		// page on the public web. Verified rather than trusted.
		$restored = get_post( $staged_id );
		if ( $restored && ! in_array( $restored->post_status, array( 'draft', 'pending' ), true ) ) {
			wp_update_post(
				array(
					'ID'          => $staged_id,
					'post_status' => 'draft',
				)
			);
		}

		return rest_ensure_response(
			array(
				'restored'  => true,
				'staged_id' => $staged_id,
				'post'      => $post_id,
			)
		);
	}

	/**
	 * The staged copy's ID for a live post, if one exists.
	 *
	 * @param int $post_id Live post ID.
	 * @return int 0 when none.
	 */
	public static function staged_id( $post_id ) {
		$found = get_posts(
			array(
				'post_type'      => 'any',
				'post_status'    => array( 'draft', 'pending' ),
				'meta_key'       => self::META_KEY, // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'     => (int) $post_id, // phpcs:ignore WordPress.DB.SlowDBQuery
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		return $found ? (int) $found[0] : 0;
	}

	/**
	 * Signed preview URL: the LIVE permalink plus a token bound to this
	 * specific live/staged pair. Deploy deletes the staged copy, which
	 * kills the link.
	 *
	 * @param int $post_id   Live post ID.
	 * @param int $staged_id Staged copy ID.
	 * @return string
	 */
	public static function preview_url( $post_id, $staged_id ) {
		return add_query_arg(
			'wi-preview',
			self::preview_token( $post_id, $staged_id ),
			get_permalink( $post_id )
		);
	}

	/**
	 * The preview token for a live/staged pair.
	 *
	 * @param int $post_id   Live post ID.
	 * @param int $staged_id Staged copy ID.
	 * @return string
	 */
	private static function preview_token( $post_id, $staged_id ) {
		return substr( hash_hmac( 'sha256', 'wi-preview|' . (int) $post_id . '|' . (int) $staged_id, wp_salt( 'auth' ) ), 0, 32 );
	}

	/**
	 * Serve staged content at the live URL when a valid token is present.
	 * Signed links are shareable by design — the token, not a login, is
	 * the credential, and it dies when the staged copy does.
	 */
	public static function maybe_preview() {
		if ( ! is_singular() || empty( $_GET['wi-preview'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		$post_id   = get_queried_object_id();
		$staged_id = self::staged_id( $post_id );
		if ( ! $staged_id ) {
			return;
		}
		$token = sanitize_text_field( wp_unslash( $_GET['wi-preview'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! hash_equals( self::preview_token( $post_id, $staged_id ), $token ) ) {
			return;
		}

		$staged = get_post( $staged_id );
		if ( ! $staged ) {
			return;
		}

		add_filter(
			'the_content',
			function ( $content ) use ( $staged, $post_id ) {
				if ( get_the_ID() !== $post_id ) {
					return $content;
				}
				// Run the staged markup through block rendering exactly
				// like live content (instance CSS, conditional assets).
				return do_blocks( $staged->post_content );
			},
			0
		);
		add_filter(
			'the_title',
			function ( $title, $id = 0 ) use ( $staged, $post_id ) {
				return (int) $id === (int) $post_id ? $staged->post_title : $title;
			},
			10,
			2
		);
	}

	/**
	 * Keep staged copies out of admin list tables and nav-menu pickers.
	 *
	 * @param WP_Query $query Query.
	 */
	public static function hide_staged_copies( $query ) {
		if ( ! is_admin() || ! $query->is_main_query() ) {
			return;
		}
		$screen_ok = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $screen_ok && 'edit' !== $screen_ok->base ) {
			return;
		}
		$meta_query   = (array) $query->get( 'meta_query' );
		$meta_query[] = array(
			'key'     => self::META_KEY,
			'compare' => 'NOT EXISTS',
		);
		$query->set( 'meta_query', $meta_query );
	}
}
