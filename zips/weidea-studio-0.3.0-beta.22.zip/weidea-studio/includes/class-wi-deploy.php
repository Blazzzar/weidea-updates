<?php
/**
 * The deploy ceremony: publish staging live, keep a way back, purge
 * caches, and write down who did what.
 *
 * A dedicated wi_deploy capability separates "can edit" from "can
 * deploy" (granted to administrators by default, filterable). Phase 1
 * ships the typed deploy key — stored only as a hash, rate-limited on
 * failures. The WebAuthn (Touch ID) ceremony lands on top of this same
 * endpoint; the key remains the documented fallback.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Deploy + rollback endpoints, deploy key, audit log, cache purge.
 */
final class WI_Deploy {

	const KEY_OPTION = 'wi_deploy_key_hash';
	const LOG_OPTION = 'wi_deploy_log';
	const MAX_LOG    = 100;
	const MAX_FAILS  = 5;

	/**
	 * Hook registration.
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		add_filter( 'user_has_cap', array( __CLASS__, 'grant_deploy_cap' ) );
	}

	/**
	 * Administrators can deploy by default; sites can widen or narrow
	 * this (the day Jen edits without deploying, this is the seam).
	 *
	 * @param array $allcaps User capabilities.
	 * @return array
	 */
	public static function grant_deploy_cap( $allcaps ) {
		if ( ! empty( $allcaps['manage_options'] ) && ! isset( $allcaps['wi_deploy'] ) ) {
			/**
			 * Filter whether this user may deploy.
			 *
			 * @param bool $granted Default grant (administrators).
			 */
			$allcaps['wi_deploy'] = apply_filters( 'wi_grant_deploy_cap', true );
		}
		return $allcaps;
	}

	/**
	 * REST routes.
	 */
	public static function register_routes() {
		$post_arg = array(
			'post' => array(
				'type'     => 'integer',
				'required' => true,
			),
		);

		register_rest_route(
			'wi/v1',
			'/deploy',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_deploy' ),
				'permission_callback' => array( __CLASS__, 'can_deploy' ),
				'args'                => $post_arg + array(
					'key'      => array( 'type' => 'string' ),
					'webauthn' => array( 'type' => 'object' ),
					// "Yes, I know, go ahead." Only the dialog's third
					// button ever sets this (finding #42, Q6: Deploy asks
					// rather than refusing flatly — a flat refusal creates a
					// page that can never be deployed again, and the
					// person's only escape is to redo the work somewhere
					// else, which loses more than we were protecting).
					'force'    => array( 'type' => 'boolean' ),
				),
			)
		);

		// The preflight. §3.5: never trust the client with a data-loss
		// gate, AND never make somebody authenticate for an answer they
		// were always going to be refused. Both halves, so this read-only
		// route exists alongside the same check inside rest_deploy.
		//
		// It leaks nothing new — same capability gate as the deploy route
		// itself, which already requires the deploy capability plus edit
		// rights on the post.
		register_rest_route(
			'wi/v1',
			'/deploy-check',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_deploy_check' ),
				'permission_callback' => array( __CLASS__, 'can_deploy' ),
				'args'                => $post_arg,
			)
		);

		register_rest_route(
			'wi/v1',
			'/rollback',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_rollback' ),
				'permission_callback' => array( __CLASS__, 'can_deploy' ),
				'args'                => $post_arg,
			)
		);
	}

	/**
	 * Permission: the dedicated deploy capability plus edit rights on
	 * the target post.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool
	 */
	public static function can_deploy( $request ) {
		return current_user_can( 'wi_deploy' )
			&& current_user_can( 'edit_post', (int) $request['post'] );
	}

	/**
	 * Verify the typed deploy key: hashed at rest, rate-limited on
	 * failure (per user, sliding 10-minute window).
	 *
	 * @param string $key Submitted key.
	 * @return true|WP_Error
	 */
	private static function verify_key( $key ) {
		$hash = get_option( self::KEY_OPTION, '' );
		if ( '' === $hash ) {
			return new WP_Error(
				'wi_no_deploy_key',
				__( 'No deploy key is set. Add one under Settings → WeIdea Studio first.', 'weidea-studio' ),
				array( 'status' => 409 )
			);
		}

		$fails_key = 'wi_deploy_fails_' . get_current_user_id();
		$fails     = (int) get_transient( $fails_key );
		if ( $fails >= self::MAX_FAILS ) {
			return new WP_Error(
				'wi_deploy_locked',
				__( 'Too many failed attempts — deploys locked for 10 minutes.', 'weidea-studio' ),
				array( 'status' => 429 )
			);
		}

		if ( ! is_string( $key ) || '' === $key || ! wp_check_password( $key, $hash ) ) {
			set_transient( $fails_key, $fails + 1, 10 * MINUTE_IN_SECONDS );
			return new WP_Error(
				'wi_bad_deploy_key',
				__( 'That deploy key is not right.', 'weidea-studio' ),
				array( 'status' => 403 )
			);
		}

		delete_transient( $fails_key );
		return true;
	}

	/**
	 * Deploy: snapshot live as a tagged revision, copy staged over live,
	 * retire the staged copy, purge caches, log.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function rest_deploy( $request ) {
		// ⚑ THE LOOKUPS AND THE STALENESS CHECK RUN BEFORE THE CEREMONY,
		// AND THE ORDER IS THE POINT (design §3.5). The ceremony used to be
		// first, so a naive staleness check would have landed after it —
		// the person does Touch ID, and then gets told no. Nobody should
		// authenticate for an answer they were always going to be refused.
		//
		// This is not a security relaxation. `can_deploy` has already run:
		// the caller holds the deploy capability AND edit rights on this
		// post, and the preflight route hands them the identical answer
		// under the identical gate. The ceremony is a confirmation ritual,
		// not the authentication.
		$post = get_post( (int) $request['post'] );
		if ( ! $post ) {
			return new WP_Error( 'wi_no_post', __( 'Post not found.', 'weidea-studio' ), array( 'status' => 404 ) );
		}
		$staged_id = WI_Staging::staged_id( $post->ID );
		if ( ! $staged_id ) {
			return new WP_Error( 'wi_no_staged', __( 'Nothing is staged for this page.', 'weidea-studio' ), array( 'status' => 409 ) );
		}

		// FINDING #42. The live page moved after the copy was taken, so
		// deploying would write over somebody's newer edit. Refuse by
		// default; the dialog's "Deploy anyway" is the way through.
		//
		// This half is also what makes Q1 safe. Q1 stops the classic
		// editor's dialog firing for a copy nobody has edited — including
		// the case where the copy is untouched AND the live page has moved,
		// where there is still real loss. That case is caught HERE instead.
		// Ship Q1 without this and there is a window with no guard at
		// either end (design §2.2, risk R-C).
		if ( empty( $request['force'] ) && WI_Staging::live_moved( $post, $staged_id ) ) {
			return new WP_Error(
				'wi_live_moved',
				__( 'The public page has changed since you made this copy.', 'weidea-studio' ),
				self::stale_payload( $post, $staged_id ) + array( 'status' => 409 )
			);
		}

		// Two ceremonies, one endpoint: WebAuthn (Touch ID) when the
		// request carries an assertion, the typed key otherwise.
		$webauthn = $request['webauthn'];
		if ( ! empty( $webauthn ) && is_array( $webauthn ) ) {
			$verified = WI_WebAuthn::verify_assertion( get_current_user_id(), $webauthn );
		} else {
			$verified = self::verify_key( (string) $request['key'] );
		}
		if ( is_wp_error( $verified ) ) {
			return $verified;
		}

		// ⛔ RE-READ AND NULL-CHECK. staged_id() answered a moment ago and
		// this is a different query; between them another request can have
		// deployed or discarded the same copy. Without the check, $staged is
		// null, `$staged->post_title` reads as null, and wp_update_post
		// BLANKS THE LIVE PAGE — the worst outcome in the plugin, produced by
		// two people pressing Deploy at once.
		//
		// The window widened when the ceremony moved after the staleness
		// check, so this is not a pre-existing hole left alone: it is one
		// this tranche made easier to fall into.
		$staged = get_post( $staged_id );
		if ( ! $staged instanceof WP_Post ) {
			return new WP_Error(
				'wi_no_staged',
				__( 'Nothing is staged for this page.', 'weidea-studio' ),
				array( 'status' => 409 )
			);
		}

		// The way back: snapshot the CURRENT live content as a revision
		// before overwriting, and remember which one it was.
		//
		// ⚑ AND THE FALLBACK IS NOT BELT-AND-BRACES — WITHOUT IT THERE IS NO
		// WAY BACK AT ALL ON THE EXACT PATH FINDING #42 IS ABOUT. Measured:
		// wp_save_post_revision() returns NULL when the newest revision
		// already matches the post, and that is precisely the state a live
		// page is in immediately after somebody edits it, because that edit
		// saved a revision of the new content on the way past. So the
		// stale-deploy case — the one where somebody presses "Deploy anyway"
		// over a newer edit — was the one case that recorded revision_id 0,
		// and rest_rollback refuses on an empty revision_id. Roll back was
		// broken in exactly the situation it exists for.
		//
		// The newest revision is the right answer when the save is a no-op,
		// and it is safe BY THE SAME TEST: core returns null only after
		// comparing that revision against the post and finding them equal,
		// so restoring it restores the pre-overwrite content.
		//
		// This is a defect in the shipped build, not one this tranche
		// introduced. It is fixed here because the "public page has changed"
		// dialog tells people they can get the page back afterwards, and a
		// dialog must not promise a recovery the product cannot perform.
		$revision_id = (int) wp_save_post_revision( $post->ID );
		if ( ! $revision_id ) {
			$revision_id = self::latest_revision_id( $post->ID );
		}

		$updated = wp_update_post(
			array(
				'ID'           => $post->ID,
				'post_title'   => $staged->post_title,
				'post_content' => $staged->post_content,
			),
			true
		);
		if ( is_wp_error( $updated ) ) {
			return $updated;
		}

		wp_delete_post( $staged_id, true );
		self::purge_cache();
		self::log(
			array(
				'action'      => 'deploy',
				'post'        => $post->ID,
				'revision_id' => $revision_id,
			)
		);

		return rest_ensure_response(
			array(
				'deployed'    => true,
				'post'        => $post->ID,
				'revision_id' => $revision_id,
			)
		);
	}

	/**
	 * The preflight: is this deploy going to be refused, and why?
	 *
	 * Read-only, no ceremony, no side effects. The Workbench's Deploy
	 * button calls this FIRST so it can put the question on screen before
	 * asking anybody for a deploy key or a fingerprint.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function rest_deploy_check( $request ) {
		$post = get_post( (int) $request['post'] );
		if ( ! $post ) {
			return new WP_Error( 'wi_no_post', __( 'Post not found.', 'weidea-studio' ), array( 'status' => 404 ) );
		}
		$staged_id = WI_Staging::staged_id( $post->ID );
		if ( ! $staged_id ) {
			return new WP_Error( 'wi_no_staged', __( 'Nothing is staged for this page.', 'weidea-studio' ), array( 'status' => 409 ) );
		}
		return rest_ensure_response(
			array( 'stale' => WI_Staging::live_moved( $post, $staged_id ) )
				+ self::stale_payload( $post, $staged_id )
		);
	}

	/**
	 * The facts the "public page has changed" dialog reads.
	 *
	 * A dialog about data loss must not have to guess, so the refusal
	 * carries its own evidence: how old the copy is, whether anybody ever
	 * changed it, and when the public page moved.
	 *
	 * `live_after_staged` exists because the sentence "someone edited the
	 * public page on X, AFTER that" is a claim about ORDER, and order is
	 * the one thing a clock can get wrong here (a restored revision, a
	 * migration, a wrong server clock). When the order cannot be shown, the
	 * dialog drops the word "after" rather than asserting something it
	 * cannot support.
	 *
	 * @param WP_Post $post      Live post.
	 * @param int     $staged_id Copy ID.
	 * @return array
	 */
	private static function stale_payload( $post, $staged_id ) {
		$staged_at     = (int) get_post_meta( $staged_id, WI_Staging::AT_META, true );
		$live_modified = (int) get_post_modified_time( 'U', true, $post );
		$revision      = self::latest_revision_id( $post->ID );
		return array(
			'post'              => $post->ID,
			'staged_id'         => $staged_id,
			'staged_at'         => $staged_at,
			'staged_on'         => $staged_at ? WI_Staging::human_stamp( $staged_at ) : '',
			'live_modified'     => $live_modified,
			'live_modified_on'  => $live_modified ? WI_Staging::human_stamp( $live_modified ) : '',
			'live_after_staged' => (bool) ( $staged_at && $live_modified > $staged_at ),
			'copy_edited'       => WI_Staging::copy_differs( $staged_id ),
			// Whether there will be a way back at all — a PREDICTION about
			// after the deploy, not an observation of before it. A page with
			// no revisions yet still gets one: the deploy's own
			// wp_save_post_revision() files the pre-overwrite content on its
			// way past. Reading only "does a revision exist right now" told
			// somebody there was no way back on the very first deploy of a
			// page, which is false and is the worst possible sentence to be
			// wrong about — it is read by a person deciding whether to
			// overwrite a colleague's work.
			'can_roll_back'     => (bool) $revision || wp_revisions_enabled( $post ),
			// '' when the page has no revisions at all — the dialog then
			// leaves "See what changed" off rather than offering a button
			// that opens an empty screen.
			'revisions_url'     => $revision ? (string) admin_url( 'revision.php?revision=' . $revision ) : '',
			'title'             => $post->post_title,
		);
	}

	/**
	 * The newest revision of a post, for the dialog's "See what changed"
	 * button — which is only ever a link into WordPress's own revision
	 * screen, where the newer edit already is.
	 *
	 * @param int $post_id Post ID.
	 * @return int 0 when the post has no revisions.
	 */
	private static function latest_revision_id( $post_id ) {
		// ⛔ AUTOSAVES ARE REVISIONS, AND THEY SORT NEWEST.
		// wp_get_post_revisions() returns them alongside real revisions —
		// measured: a fresh autosave came back ABOVE the genuine revision.
		// Taking [0] blindly would let Deploy record somebody's unsaved
		// autosave draft as the way back, and Roll back would then put that
		// draft on the public page. Ask for a few and take the newest that
		// is not an autosave.
		$revisions = wp_get_post_revisions(
			$post_id,
			array(
				'posts_per_page' => 10,
				'fields'         => 'ids',
			)
		);
		foreach ( (array) $revisions as $revision_id ) {
			if ( ! wp_is_post_autosave( $revision_id ) ) {
				return (int) $revision_id;
			}
		}
		return 0;
	}

	/**
	 * Rollback: restore the revision tagged by the last deploy of this
	 * post. Same ceremony philosophy — one click back.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function rest_rollback( $request ) {
		$post_id = (int) $request['post'];
		$entry   = null;
		foreach ( (array) get_option( self::LOG_OPTION, array() ) as $candidate ) {
			if ( 'deploy' === $candidate['action'] && (int) $candidate['post'] === $post_id ) {
				$entry = $candidate;
				break;
			}
		}
		if ( ! $entry || empty( $entry['revision_id'] ) ) {
			return new WP_Error( 'wi_no_rollback', __( 'No deploy to roll back for this page.', 'weidea-studio' ), array( 'status' => 409 ) );
		}

		$restored = wp_restore_post_revision( (int) $entry['revision_id'] );
		if ( ! $restored ) {
			return new WP_Error( 'wi_rollback_failed', __( 'The rollback point could not be restored.', 'weidea-studio' ), array( 'status' => 500 ) );
		}

		self::purge_cache();
		self::log(
			array(
				'action'      => 'rollback',
				'post'        => $post_id,
				'revision_id' => (int) $entry['revision_id'],
			)
		);

		return rest_ensure_response(
			array(
				'rolled_back' => true,
				'post'        => $post_id,
			)
		);
	}

	/**
	 * Purge SiteGround's cache when its plugin is present — the #1
	 * gotcha from the pilot's build guide, closed at the source.
	 */
	private static function purge_cache() {
		if ( function_exists( 'sg_cachepress_purge_cache' ) ) {
			sg_cachepress_purge_cache();
		}

		/**
		 * Fires after a deploy or rollback so other cache layers can purge.
		 */
		do_action( 'wi_after_deploy_purge' );
	}

	/**
	 * Append a who/when/what entry to the audit log (newest first).
	 *
	 * @param array $entry Entry fields.
	 */
	private static function log( $entry ) {
		$log = (array) get_option( self::LOG_OPTION, array() );
		array_unshift(
			$log,
			$entry + array(
				'user' => get_current_user_id(),
				'time' => time(),
			)
		);
		update_option( self::LOG_OPTION, array_slice( $log, 0, self::MAX_LOG ), false );
	}
}
