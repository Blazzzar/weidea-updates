<?php
/**
 * Block registration.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers the weidea/* blocks from the build output.
 */
final class WI_Blocks {

	/**
	 * Block slugs shipped by the plugin (weidea/{slug}).
	 *
	 * @var string[]
	 */
	const BLOCKS = array( 'section' );

	/**
	 * Hook registration.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_action( 'enqueue_block_editor_assets', array( __CLASS__, 'editor_settings' ) );
	}

	/**
	 * Register each block from its built block.json.
	 */
	public static function register() {
		foreach ( self::BLOCKS as $slug ) {
			$dir = WI_PLUGIN_DIR . 'build/blocks/' . $slug;
			if ( file_exists( $dir . '/block.json' ) ) {
				register_block_type( $dir );
			}
		}
	}

	/**
	 * Expose site settings (breakpoints, version) to the editor runtime.
	 */
	public static function editor_settings() {
		$settings = wp_json_encode(
			array(
				'version'     => WI_VERSION,
				'breakpoints' => WI_Breakpoints::get(),
			)
		);

		foreach ( self::BLOCKS as $slug ) {
			$handle = generate_block_asset_handle( 'weidea/' . $slug, 'editorScript' );
			if ( wp_script_is( $handle, 'registered' ) ) {
				wp_add_inline_script( $handle, 'window.wiStudio = ' . $settings . ';', 'before' );
				break;
			}
		}
	}
}
