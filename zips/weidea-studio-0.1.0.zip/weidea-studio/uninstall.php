<?php
/**
 * Uninstall cleanup.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'wi_breakpoints' );
delete_option( 'wi_update_channel' );
delete_site_transient( 'wi_update_manifest' );
delete_site_transient( 'wi_rollback_target' );
