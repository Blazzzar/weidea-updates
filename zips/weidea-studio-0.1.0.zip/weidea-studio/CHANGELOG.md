# Changelog

## 0.1.0 — Phase 0 scaffold (July 2026)

- **Control registry core** — inspector panels render from JSON schemas in
  `registry/blocks/`; the server generates CSS from the same files. Every
  panel and control carries a plain-English label and help text, enforced
  in CI (`npm run registry:check`).
- **Design tokens** — `--wi-*` custom properties with the Kadence palette
  bridge (`--wi-accent` → `--global-palette1`, etc.), so blocks re-skin per
  brand zone through the pilot site's existing body-class remaps.
- **Section proof block** — `weidea/section`, with registry-driven
  Background / Spacing / Content width panels, independent
  desktop/tablet/phone values with inheritance and override dots, and
  site-configurable breakpoints (`wi_breakpoints` option, REST-exposed).
- **No-bloat contract enforcement** — zero assets on pages without WeIdea
  blocks (e2e-verified), per-block conditional loading, CI budget gate with
  numbers written into every release.
- **Self-hosted update channel, two-track** — manifest-based updater
  (12-hour cache, the plugin's only outbound call) serving `stable` and
  `beta` tracks; each site picks its channel on the Plugins screen or via
  REST (`wi_update_channel`). The manifest retains recent releases, and
  the plugin row offers **one-click rollback** to the previous retained
  version through WordPress's native upgrade flow. Detection, channel
  switching, install, and rollback are all covered by the e2e suite
  against a locally served channel.
- **Tooling** — `@wordpress/scripts` build, wp-env disposable WordPress,
  Playwright e2e harness, GitHub Actions CI, versioned release zip.
