=== WeIdea Studio ===
Contributors: kitemath
Tags: blocks, page builder, design, animation
Requires at least: 6.5
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 0.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A self-owned block library, live-page workbench, restyler, and motion system for WordPress.

== Description ==

WeIdea Studio is a Gutenberg-native builder: content stays standard,
portable block markup, and WordPress core does the heavy lifting. Every
inspector panel is rendered from a control registry — the same schema the
server compiles CSS from — with independent desktop/tablet/phone values on
every visual control and site-configurable breakpoints.

The no-bloat contract: a page with no WeIdea blocks enqueues nothing; every
block pays only for itself; there is no jQuery anywhere; editor weight never
reaches visitors. Updates arrive from a self-hosted channel — no SaaS, no
API keys, no telemetry.

This is the Phase 0 scaffold: the registry core, the design-token system
(including the Kadence palette bridge), the Section proof block, and the
update channel.

== Changelog ==

= 0.1.0 =
* Phase 0 scaffold: control registry, design tokens + Kadence bridge,
  Section block with responsive registry-driven controls, conditional asset
  loading, self-hosted update channel, CI with budget gate and e2e suite.
