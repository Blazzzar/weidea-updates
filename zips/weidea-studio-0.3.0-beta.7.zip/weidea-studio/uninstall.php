<?php
/**
 * Uninstall cleanup.
 *
 * POLICY: removing the plugin removes the plugin's OWN data — options,
 * transients, credentials, and everything under uploads/weidea/ — and
 * NEVER touches content. Posts keep rendering (standard block markup),
 * staged drafts stay where they are, revisions and deploy history in
 * post meta remain. That is the single-maintainer safety net from the
 * plan: content survives the tool.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Plugin options and transients.
delete_option( 'wi_breakpoints' );
delete_option( 'wi_update_channel' );
delete_option( 'wi_deploy_key_hash' );
delete_option( 'wi_deploy_log' );
delete_option( 'wi_safe_mode' );
delete_site_transient( 'wi_update_manifest' );
delete_site_transient( 'wi_rollback_target' );

// Per-user WebAuthn deploy credentials (plugin data, not content).
delete_metadata( 'user', 0, 'wi_webauthn_credentials', '', true );

// Generated assets: the namespaced uploads/weidea/ tree, and nothing
// else — the path is re-derived and checked so this can never walk
// outside the plugin's own directory.
$wi_uploads = wp_upload_dir();
$wi_dir     = trailingslashit( $wi_uploads['basedir'] ) . 'weidea';
if ( is_dir( $wi_dir ) && false === strpos( $wi_dir, '..' ) ) {
	$wi_iterator = new RecursiveIteratorIterator(
		new RecursiveDirectoryIterator( $wi_dir, FilesystemIterator::SKIP_DOTS ),
		RecursiveIteratorIterator::CHILD_FIRST
	);
	foreach ( $wi_iterator as $wi_item ) {
		if ( $wi_item->isDir() ) {
			rmdir( $wi_item->getPathname() ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		} else {
			unlink( $wi_item->getPathname() ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
	}
	rmdir( $wi_dir ); // phpcs:ignore WordPress.WP.AlternativeFunctions
}
