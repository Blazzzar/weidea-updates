<?php
/**
 * Frontend asset loading — the enforcement point of the no-bloat contract.
 *
 * Rule 1: a page containing no WeIdea blocks enqueues NOTHING. Rule 2: a
 * page pays only for the blocks it contains. Block styles are deliberately
 * NOT registered through block.json (classic themes would enqueue them on
 * every page); this class owns registration and enqueues per block, per
 * page, deterministically:
 *
 *  - On singular pages, has_block() decides in wp_enqueue_scripts, so the
 *    block stylesheets print in <head>.
 *  - Everywhere else (archives, widgets, patterns), a render_block filter
 *    catches any weidea/* block as a fallback; those styles print late but
 *    never load on pages without blocks.
 *
 * Per-instance CSS delivery (finding #14). Instance CSS is compiled from
 * the registry per block, collected while blocks render, and printed as ONE
 * consolidated stylesheet in wp_footer — never as scattered inline <style>
 * tags woven into the post body before each block. Consolidating it into a
 * single stylesheet is what survives an HTML minifier / CSS combiner
 * (SiteGround Optimizer, Cloudflare) that mangles or strips the many small
 * inline styles the old path emitted; printing it after every block
 * stylesheet keeps equal-specificity instance rules winning by order.
 *
 * render_block emits no CSS itself; it collects each instance's CSS for the
 * footer and guarantees the scoped class is on the block's root element
 * (the armor below), so the instance rule always has a hook — even for
 * content the editor saved without a uniqueId.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Conditional asset enqueueing.
 */
final class WI_Assets {

	/**
	 * Per-instance CSS collected during render, keyed by uid (dedup), and
	 * printed once in the footer.
	 *
	 * @var string[]
	 */
	private static $css_by_uid = array();

	/**
	 * Whether the token stylesheet has been enqueued this request.
	 *
	 * @var bool
	 */
	private static $tokens_done = false;

	/**
	 * Hook registration.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_styles' ), 20 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_for_content' ) );
		add_filter( 'render_block', array( __CLASS__, 'render_block' ), 10, 2 );
		add_action( 'wp_footer', array( __CLASS__, 'print_instance_css' ), 20 );
		add_action( 'enqueue_block_assets', array( __CLASS__, 'editor_tokens' ) );
		// Safe mode: block view scripts (block.json viewScript entries are
		// enqueued by core at render) get dequeued just before printing.
		add_action( 'wp_print_footer_scripts', array( __CLASS__, 'safe_mode_dequeue' ), 1 );
		add_action( 'wp_print_scripts', array( __CLASS__, 'safe_mode_dequeue' ), 1 );
	}

	/**
	 * The kill switch's enforcement point for block view scripts: core
	 * enqueues block.json viewScript handles during render, so they are
	 * pulled back out right before printing when safe mode is on. Static
	 * content is unaffected — every effect degrades to its saved markup.
	 */
	public static function safe_mode_dequeue() {
		if ( is_admin() || ! WI_Settings_Page::safe_mode() ) {
			return;
		}
		foreach ( WI_Blocks::BLOCKS as $slug ) {
			wp_dequeue_script( generate_block_asset_handle( 'weidea/' . $slug, 'viewScript' ) );
		}
	}

	/**
	 * Register (never enqueue) each block's frontend stylesheet.
	 */
	public static function register_styles() {
		foreach ( WI_Blocks::BLOCKS as $slug ) {
			$rel = 'build/blocks/' . $slug . '/style-index.css';
			if ( file_exists( WI_PLUGIN_DIR . $rel ) ) {
				wp_register_style( 'wi-block-' . $slug, WI_PLUGIN_URL . $rel, array(), WI_VERSION );
			}
		}
	}

	/**
	 * Head-time enqueue of the block stylesheets for singular content, based
	 * on has_block(). The per-instance CSS rides the footer (see render_block
	 * + print_instance_css), so it lands after these and always wins.
	 */
	public static function enqueue_for_content() {
		if ( ! is_singular() ) {
			return;
		}
		$post = get_post();
		if ( ! $post ) {
			return;
		}
		foreach ( WI_Blocks::BLOCKS as $slug ) {
			if ( has_block( 'weidea/' . $slug, $post ) ) {
				self::enqueue_block( $slug );
			}
		}
	}

	/**
	 * Fallback enqueue + scoped-class armor + instance-CSS collection.
	 *
	 * No CSS is emitted inline here: each instance's CSS is collected for the
	 * single consolidated footer stylesheet. What render_block guarantees in
	 * the markup is that the block's root element carries its wi-<block>-<uid>
	 * class, so the instance rule always has a hook — even when the editor
	 * never persisted a uniqueId (old / programmatic content self-heals).
	 *
	 * @param string $content Rendered block HTML.
	 * @param array  $block   Parsed block.
	 * @return string
	 */
	public static function render_block( $content, $block ) {
		$name = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
		if ( 0 !== strpos( $name, 'weidea/' ) ) {
			return $content;
		}

		$slug = substr( $name, 7 );
		self::enqueue_block( $slug );

		$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
		$uid   = self::resolve_uid( $name, $attrs, $content );
		if ( '' === $uid ) {
			return $content;
		}

		$content = self::ensure_class( $content, 'wi-' . $slug . '-' . $uid );

		if ( ! isset( self::$css_by_uid[ $uid ] ) ) {
			$css = self::instance_css( $name, $attrs, $uid );
			if ( '' !== $css ) {
				self::$css_by_uid[ $uid ] = $css;
			}
		}
		return $content;
	}

	/**
	 * Print every collected instance's CSS as one consolidated stylesheet.
	 * Generated CSS is already sanitized by WI_Block_CSS.
	 */
	public static function print_instance_css() {
		if ( is_admin() || ! self::$css_by_uid ) {
			return;
		}
		echo '<style id="wi-instance-css">' . implode( '', self::$css_by_uid ) . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- values are validated in WI_Block_CSS.
	}

	/**
	 * The instance uid for a block: its persisted uniqueId, else the uid
	 * already on its rendered markup, else a deterministic derivation from
	 * its attributes. Deterministic so identical blocks collide onto
	 * identical (harmless) CSS.
	 *
	 * @param string      $name    Block name.
	 * @param array       $attrs   Block attributes.
	 * @param string|null $content Rendered markup, when available.
	 * @return string Sanitized uid, or '' when nothing can be resolved.
	 */
	private static function resolve_uid( $name, $attrs, $content = null ) {
		$uid = isset( $attrs['uniqueId'] ) ? preg_replace( '/[^a-zA-Z0-9_-]/', '', (string) $attrs['uniqueId'] ) : '';
		if ( '' !== $uid ) {
			return $uid;
		}

		$slug = substr( $name, 7 );
		if ( is_string( $content ) && class_exists( 'WP_HTML_Tag_Processor' ) ) {
			$p = new WP_HTML_Tag_Processor( $content );
			if ( $p->next_tag() ) {
				$cls = $p->get_attribute( 'class' );
				if ( is_string( $cls ) && preg_match( '#\bwi-' . preg_quote( $slug, '#' ) . '-([A-Za-z0-9_-]+)#', $cls, $m ) ) {
					return $m[1];
				}
			}
		}

		// Deterministic: identical attrs → identical uid AND identical CSS,
		// so any collision is a no-op.
		return substr( md5( $name . wp_json_encode( $attrs ) ), 0, 10 );
	}

	/**
	 * Generate instance CSS for a block under an explicit uid.
	 *
	 * @param string $name  Block name.
	 * @param array  $attrs Block attributes.
	 * @param string $uid   Resolved uid.
	 * @return string
	 */
	private static function instance_css( $name, $attrs, $uid ) {
		$attrs['uniqueId'] = $uid;
		return WI_Block_CSS::generate( $name, $attrs );
	}

	/**
	 * Ensure the block's root element carries a class, adding it only when
	 * absent. Uses the HTML API so the existing attribute string is parsed,
	 * never string-spliced.
	 *
	 * @param string $content Rendered block HTML.
	 * @param string $class   Class to guarantee (e.g. "wi-section-ab12cd").
	 * @return string
	 */
	private static function ensure_class( $content, $class ) {
		if ( false !== strpos( $content, $class ) || ! class_exists( 'WP_HTML_Tag_Processor' ) ) {
			return $content;
		}
		$p = new WP_HTML_Tag_Processor( $content );
		if ( $p->next_tag() ) {
			$p->add_class( $class );
			return $p->get_updated_html();
		}
		return $content;
	}

	/**
	 * Enqueue one block's stylesheet plus the shared tokens (once).
	 *
	 * @param string $slug Block slug.
	 */
	private static function enqueue_block( $slug ) {
		self::tokens();
		if ( wp_style_is( 'wi-block-' . $slug, 'registered' ) ) {
			wp_enqueue_style( 'wi-block-' . $slug );
		}
	}

	/**
	 * Print the design tokens once per request, as inline CSS on a
	 * src-less handle — a page without WeIdea blocks never gets them.
	 */
	private static function tokens() {
		if ( self::$tokens_done ) {
			return;
		}
		self::$tokens_done = true;
		wp_register_style( 'wi-tokens', false, array(), WI_VERSION );
		wp_enqueue_style( 'wi-tokens' );
		wp_add_inline_style( 'wi-tokens', WI_Tokens::css() . WI_Tokens::runtime_css() );
	}

	/**
	 * Editor canvas assets (admin only — enqueue_block_assets also fires
	 * on the frontend, where the conditional path above owns loading).
	 * The canvas gets the tokens plus every block's frontend stylesheet,
	 * so what you design against is what ships.
	 */
	public static function editor_tokens() {
		if ( ! is_admin() ) {
			return;
		}
		wp_register_style( 'wi-tokens-editor', false, array(), WI_VERSION );
		wp_enqueue_style( 'wi-tokens-editor' );
		wp_add_inline_style( 'wi-tokens-editor', WI_Tokens::css() . WI_Tokens::runtime_css() );

		foreach ( WI_Blocks::BLOCKS as $slug ) {
			if ( wp_style_is( 'wi-block-' . $slug, 'registered' ) ) {
				wp_enqueue_style( 'wi-block-' . $slug );
			}
		}

		// Motion presets in the canvas, so the Animate tab's preview
		// plays with the real engine's CSS.
		if ( wp_style_is( 'wi-motion', 'registered' ) ) {
			wp_enqueue_style( 'wi-motion' );
		}
	}
}
