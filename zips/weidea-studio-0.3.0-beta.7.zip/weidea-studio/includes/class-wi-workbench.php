<?php
/**
 * The workbench: summoned on any live page, for logged-in editors only.
 *
 * Every frontend singular view carries an invisible loader (admin-bar
 * button + ⌘E) — for editors with rights on that post, never for
 * visitors, so the visitor-facing footprint stays zero. Summoning stages
 * the page (WI_Staging) and opens the real block editor for the staged
 * copy in a full-screen overlay iframe, chrome-stripped via the
 * wi-workbench flag. Preview and Deploy ride the staging/deploy REST
 * surface.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Workbench loader + editor chrome.
 */
final class WI_Workbench {

	/**
	 * Hook registration.
	 */
	public static function init() {
		add_action( 'admin_bar_menu', array( __CLASS__, 'admin_bar_node' ), 90 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_loader' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'workbench_editor_chrome' ) );
	}

	/**
	 * Whether the current frontend view can summon the workbench.
	 *
	 * @return int Editable post ID, or 0.
	 */
	private static function editable_post_id() {
		if ( is_admin() || ! is_singular() || ! is_user_logged_in() ) {
			return 0;
		}
		$post_id = get_queried_object_id();
		return $post_id && current_user_can( 'edit_post', $post_id ) ? $post_id : 0;
	}

	/**
	 * The admin-bar summon button.
	 *
	 * @param WP_Admin_Bar $bar Admin bar.
	 */
	public static function admin_bar_node( $bar ) {
		if ( ! self::editable_post_id() ) {
			return;
		}
		$bar->add_node(
			array(
				'id'    => 'wi-workbench',
				'title' => __( 'WeIdea Studio', 'weidea-studio' ),
				'href'  => '#',
				'meta'  => array( 'title' => __( 'Open the workbench (⌘E)', 'weidea-studio' ) ),
			)
		);
	}

	/**
	 * The loader: enqueued only for editors on pages they can edit.
	 */
	public static function enqueue_loader() {
		$post_id = self::editable_post_id();
		if ( ! $post_id ) {
			return;
		}

		$asset_file = WI_PLUGIN_DIR . 'build/workbench/index.asset.php';
		if ( ! file_exists( $asset_file ) ) {
			return;
		}
		$asset = require $asset_file;

		wp_enqueue_script(
			'wi-workbench',
			WI_PLUGIN_URL . 'build/workbench/index.js',
			$asset['dependencies'],
			$asset['version'],
			true
		);
		wp_enqueue_style(
			'wi-workbench',
			WI_PLUGIN_URL . 'build/workbench/style-index.css',
			array(),
			$asset['version']
		);
		wp_add_inline_script(
			'wi-workbench',
			'window.wiWorkbench = ' . wp_json_encode(
				array(
					'postId'  => $post_id,
					'nonce'   => wp_create_nonce( 'wp_rest' ),
					'restUrl' => esc_url_raw( rest_url( 'wi/v1' ) ),
					'canDeploy' => current_user_can( 'wi_deploy' ),
				)
			) . ';',
			'before'
		);
	}

	/**
	 * Inside the overlay iframe (post editor with wi-workbench=1): strip
	 * the admin chrome so the workbench reads as one surface.
	 *
	 * @param string $hook Admin page hook.
	 */
	public static function workbench_editor_chrome( $hook ) {
		if ( 'post.php' !== $hook || empty( $_GET['wi-workbench'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		$css = '#adminmenumain,#wpadminbar,#wpfooter{display:none!important}'
			. 'html.wp-toolbar{padding-top:0!important}'
			. '#wpcontent,#wpbody-content{margin-left:0!important;padding-left:0!important}';
		wp_register_style( 'wi-workbench-chrome', false, array(), WI_VERSION );
		wp_enqueue_style( 'wi-workbench-chrome' );
		wp_add_inline_style( 'wi-workbench-chrome', $css );
	}
}
