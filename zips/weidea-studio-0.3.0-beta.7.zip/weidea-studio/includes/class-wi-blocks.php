<?php
/**
 * Block registration.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers the weidea/* blocks from the build output.
 */
final class WI_Blocks {

	/**
	 * Block slugs shipped by the plugin (weidea/{slug}).
	 *
	 * @var string[]
	 */
	const BLOCKS = array( 'section', 'row', 'column', 'heading', 'text', 'buttons', 'button', 'image', 'icon', 'spacer', 'divider', 'counter', 'marquee', 'typed' );

	/**
	 * Hook registration.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_action( 'enqueue_block_editor_assets', array( __CLASS__, 'editor_settings' ) );
		// Priority 99999: run AFTER other plugins (Kadence hooks this too)
		// so WeIdea can force itself to the front regardless of where they
		// place themselves. On the pilot, Kadence Blocks otherwise sits
		// above WeIdea Studio in the inserter.
		add_filter( 'block_categories_all', array( __CLASS__, 'block_category' ), 99999 );
	}

	/**
	 * One home for every WeIdea block in the inserter, and always the TOP
	 * category — nothing scattered through WP's default categories, and
	 * above Kadence on the coexisting pilot. The JS side registers the
	 * matching weidea/ block collection with the brand mark
	 * (src/registry/register.js).
	 *
	 * @param array[] $categories Block categories.
	 * @return array[]
	 */
	public static function block_category( $categories ) {
		// Drop any existing WeIdea entry (idempotent — the filter can run
		// more than once), then unshift ours to index 0 so it wins no
		// matter what earlier hooks did.
		$categories = array_values(
			array_filter(
				(array) $categories,
				static function ( $category ) {
					return empty( $category['slug'] ) || 'weidea' !== $category['slug'];
				}
			)
		);

		array_unshift(
			$categories,
			array(
				'slug'  => 'weidea',
				'title' => __( 'WeIdea Studio', 'weidea-studio' ),
			)
		);
		return $categories;
	}

	/**
	 * Register each block from its built block.json.
	 */
	public static function register() {
		foreach ( self::BLOCKS as $slug ) {
			$dir = WI_PLUGIN_DIR . 'build/blocks/' . $slug;
			if ( file_exists( $dir . '/block.json' ) ) {
				register_block_type( $dir );
				wp_set_script_translations(
					generate_block_asset_handle( 'weidea/' . $slug, 'editorScript' ),
					'weidea-studio',
					WI_PLUGIN_DIR . 'languages'
				);
			}
		}
	}

	/**
	 * Expose site settings (breakpoints, version) to the editor runtime.
	 */
	public static function editor_settings() {
		// The inspector's ⓘ demos and preset tiles play the REAL motion
		// CSS — it must exist in the parent editor document too (the
		// canvas gets it via enqueue_block_assets).
		if ( wp_style_is( 'wi-motion', 'registered' ) ) {
			wp_enqueue_style( 'wi-motion' );
		}

		$settings = wp_json_encode(
			array(
				'version'      => WI_VERSION,
				'breakpoints'  => WI_Breakpoints::get(),
				'devices'      => WI_Breakpoints::devices(),
				'spacingScale' => WI_Tokens::spacing_scale(),
			)
		);

		foreach ( self::BLOCKS as $slug ) {
			$handle = generate_block_asset_handle( 'weidea/' . $slug, 'editorScript' );
			if ( wp_script_is( $handle, 'registered' ) ) {
				wp_add_inline_script( $handle, 'window.wiStudio = ' . $settings . ';', 'before' );
				break;
			}
		}
	}
}
