<?php
/**
 * Minimal CBOR decoder — exactly the subset WebAuthn registration needs
 * (RFC 8949 major types 0–5 and simple values, definite lengths only;
 * authenticators emit nothing else). No third-party library, per the
 * zero-dependency rule; small enough to audit in one sitting.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CBOR decoding for WebAuthn attestation objects and COSE keys.
 */
final class WI_CBOR {

	/**
	 * Decode the first CBOR item in a byte string.
	 *
	 * @param string $bytes  Raw bytes.
	 * @param int    $offset Byte offset; advanced past the item.
	 * @return mixed Decoded value.
	 * @throws InvalidArgumentException On malformed or unsupported input.
	 */
	public static function decode( $bytes, &$offset = 0 ) {
		if ( $offset >= strlen( $bytes ) ) {
			throw new InvalidArgumentException( 'CBOR: unexpected end of input.' );
		}

		$initial = ord( $bytes[ $offset++ ] );
		$major   = $initial >> 5;
		$info    = $initial & 0x1f;

		switch ( $major ) {
			case 0: // Unsigned integer.
				return self::read_length( $bytes, $offset, $info );

			case 1: // Negative integer.
				return -1 - self::read_length( $bytes, $offset, $info );

			case 2: // Byte string.
			case 3: // Text string.
				$length = self::read_length( $bytes, $offset, $info );
				if ( $offset + $length > strlen( $bytes ) ) {
					throw new InvalidArgumentException( 'CBOR: string overruns input.' );
				}
				$value   = substr( $bytes, $offset, $length );
				$offset += $length;
				return $value;

			case 4: // Array.
				$count = self::read_length( $bytes, $offset, $info );
				$out   = array();
				for ( $i = 0; $i < $count; $i++ ) {
					$out[] = self::decode( $bytes, $offset );
				}
				return $out;

			case 5: // Map.
				$count = self::read_length( $bytes, $offset, $info );
				$out   = array();
				for ( $i = 0; $i < $count; $i++ ) {
					$key = self::decode( $bytes, $offset );
					if ( ! is_int( $key ) && ! is_string( $key ) ) {
						throw new InvalidArgumentException( 'CBOR: unsupported map key type.' );
					}
					$out[ $key ] = self::decode( $bytes, $offset );
				}
				return $out;

			case 7: // Simple values.
				if ( 20 === $info ) {
					return false;
				}
				if ( 21 === $info ) {
					return true;
				}
				if ( 22 === $info ) {
					return null;
				}
				throw new InvalidArgumentException( 'CBOR: unsupported simple value.' );

			default: // Tags (6) and anything else WebAuthn never emits.
				throw new InvalidArgumentException( 'CBOR: unsupported major type ' . $major . '.' );
		}
	}

	/**
	 * Read a length/value header.
	 *
	 * @param string $bytes  Raw bytes.
	 * @param int    $offset Byte offset; advanced.
	 * @param int    $info   Additional-information bits.
	 * @return int
	 * @throws InvalidArgumentException On indefinite lengths or overruns.
	 */
	private static function read_length( $bytes, &$offset, $info ) {
		if ( $info < 24 ) {
			return $info;
		}
		$widths = array(
			24 => 1,
			25 => 2,
			26 => 4,
			27 => 8,
		);
		if ( ! isset( $widths[ $info ] ) ) {
			throw new InvalidArgumentException( 'CBOR: indefinite lengths are not supported.' );
		}
		$width = $widths[ $info ];
		if ( $offset + $width > strlen( $bytes ) ) {
			throw new InvalidArgumentException( 'CBOR: length overruns input.' );
		}
		$value = 0;
		for ( $i = 0; $i < $width; $i++ ) {
			$value = ( $value * 256 ) + ord( $bytes[ $offset++ ] );
		}
		return $value;
	}
}
