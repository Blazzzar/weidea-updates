<?php
/**
 * Background / gradient / overlay composer.
 *
 * Backgrounds are the one family the generic registry-CSS path can't
 * carry: they need url(...), gradient functions, and comma-joined layers
 * that WI_Block_CSS::sanitize_value deliberately rejects. So this typed
 * composer validates each PART of the composite (never free text) and
 * hands finished, safe declarations back to WI_Block_CSS's device →
 * selector → property → value buckets, where the existing serializer and
 * max-width media-query loop emit them unchanged.
 *
 * The overlay is a ::before pseudo-element at z-index:-1 with the host
 * element set to isolation:isolate — so it paints above the element's own
 * background but below in-flow content, needs NO extra markup (works on
 * Column, which has no inner wrapper), and its blend mode can't bleed to
 * the page. Nothing here changes saved markup: no block deprecations.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Validated composition of background image, gradient, and overlay.
 */
final class WI_Background {

	const SIZES      = array( 'cover', 'contain', 'auto' );
	const REPEATS    = array( 'no-repeat', 'repeat', 'repeat-x', 'repeat-y' );
	const ATTACHMENTS = array( 'scroll', 'fixed' );
	const GRAD_TYPES = array( 'linear', 'radial' );
	const BLENDS     = array( 'normal', 'multiply', 'screen', 'overlay', 'darken', 'lighten', 'color-dodge', 'color-burn', 'hard-light', 'soft-light', 'difference', 'exclusion', 'hue', 'saturation', 'color', 'luminosity' );

	/**
	 * Compose the background fragment for one block instance.
	 *
	 * @param string $self_sel    The block's own selector (.wi-section-uid).
	 * @param string $overlay_sel The ::before selector (.wi-section-uid::before).
	 * @param array  $attrs       Block attributes.
	 * @param array  $device_ids  Ordered device ids (base first).
	 * @param string $base_id     The base (no media query) device id.
	 * @return array device => selector => [ property => value ].
	 */
	public static function compose( $self_sel, $overlay_sel, $attrs, $device_ids, $base_id ) {
		$out = array();

		// ---- Background image + gradient (non-responsive, self base). ----
		$layers = array();
		$gradient = self::gradient( isset( $attrs['wiBgGradient'] ) ? $attrs['wiBgGradient'] : null );
		if ( '' !== $gradient ) {
			$layers[] = $gradient; // gradient is the upper (first) layer.
		}
		$image = isset( $attrs['wiBgImage'] ) && is_array( $attrs['wiBgImage'] ) ? $attrs['wiBgImage'] : array();
		$image_url = self::url( isset( $image['url'] ) ? $image['url'] : '' );
		if ( '' !== $image_url ) {
			$layers[] = 'url("' . $image_url . '")';
		}

		if ( $layers ) {
			self::put( $out, $base_id, $self_sel, 'background-image', implode( ',', $layers ) );
			// Image-specific longhands only when an actual image is present.
			if ( '' !== $image_url ) {
				$fx = self::num( isset( $image['focalX'] ) ? $image['focalX'] : 0.5, 0, 1, 2 ) * 100;
				$fy = self::num( isset( $image['focalY'] ) ? $image['focalY'] : 0.5, 0, 1, 2 ) * 100;
				self::put( $out, $base_id, $self_sel, 'background-position', self::trim_num( $fx ) . '% ' . self::trim_num( $fy ) . '%' );
				self::put( $out, $base_id, $self_sel, 'background-size', self::keyword( isset( $image['size'] ) ? $image['size'] : '', self::SIZES, 'cover' ) );
				self::put( $out, $base_id, $self_sel, 'background-repeat', self::keyword( isset( $image['repeat'] ) ? $image['repeat'] : '', self::REPEATS, 'no-repeat' ) );
				self::put( $out, $base_id, $self_sel, 'background-attachment', self::keyword( isset( $image['attachment'] ) ? $image['attachment'] : '', self::ATTACHMENTS, 'scroll' ) );
			}
		}

		// ---- Overlay (responsive ::before). ----
		$overlay = isset( $attrs['wiOverlay'] ) && is_array( $attrs['wiOverlay'] ) ? $attrs['wiOverlay'] : array();
		$paints  = array();
		foreach ( $device_ids as $device ) {
			$entry = isset( $overlay[ $device ] ) && is_array( $overlay[ $device ] ) ? $overlay[ $device ] : null;
			$paint = $entry ? self::overlay_paint( $entry ) : array();
			if ( $paint ) {
				$paints[ $device ] = $paint;
			}
		}

		if ( $paints ) {
			// Skeleton + host isolation: base bucket, device-independent.
			self::put( $out, $base_id, $self_sel, 'position', 'relative' );
			self::put( $out, $base_id, $self_sel, 'isolation', 'isolate' );
			self::put( $out, $base_id, $overlay_sel, 'content', '""' );
			self::put( $out, $base_id, $overlay_sel, 'position', 'absolute' );
			self::put( $out, $base_id, $overlay_sel, 'inset', '0' );
			self::put( $out, $base_id, $overlay_sel, 'pointer-events', 'none' );
			self::put( $out, $base_id, $overlay_sel, 'z-index', '-1' );
			self::put( $out, $base_id, $overlay_sel, 'border-radius', 'inherit' );
			// Per-device paint.
			foreach ( $paints as $device => $decls ) {
				foreach ( $decls as $prop => $val ) {
					self::put( $out, $device, $overlay_sel, $prop, $val );
				}
			}
		}

		return $out;
	}

	/**
	 * The paint declarations for one overlay device entry.
	 *
	 * @param array $entry { kind, color, gradient, opacity, blend }.
	 * @return array property => value (empty when nothing valid).
	 */
	private static function overlay_paint( $entry ) {
		$decls = array();
		$kind  = isset( $entry['kind'] ) ? $entry['kind'] : 'color';

		if ( 'gradient' === $kind ) {
			$g = self::gradient( isset( $entry['gradient'] ) ? $entry['gradient'] : null );
			if ( '' === $g ) {
				return array();
			}
			$decls['background-image'] = $g;
		} else {
			$c = self::color( isset( $entry['color'] ) ? $entry['color'] : '' );
			if ( '' === $c ) {
				return array();
			}
			$decls['background-color'] = $c;
		}

		$decls['opacity']        = self::trim_num( self::num( isset( $entry['opacity'] ) ? $entry['opacity'] : 0.5, 0, 1, 2 ) );
		$decls['mix-blend-mode'] = self::keyword( isset( $entry['blend'] ) ? $entry['blend'] : '', self::BLENDS, 'normal' );
		return $decls;
	}

	/**
	 * Compose a validated gradient function string, or '' if invalid.
	 *
	 * @param mixed $g { type, angle, stops:[ {color,position} ] }.
	 * @return string
	 */
	public static function gradient( $g ) {
		if ( ! is_array( $g ) || empty( $g['stops'] ) || ! is_array( $g['stops'] ) ) {
			return '';
		}
		$stops = array();
		foreach ( $g['stops'] as $stop ) {
			if ( ! is_array( $stop ) ) {
				continue;
			}
			$c = self::color( isset( $stop['color'] ) ? $stop['color'] : '' );
			if ( '' === $c ) {
				continue;
			}
			$pos     = self::trim_num( self::num( isset( $stop['position'] ) ? $stop['position'] : 0, 0, 100, 2 ) );
			$stops[] = $c . ' ' . $pos . '%';
		}
		if ( count( $stops ) < 2 ) {
			return '';
		}
		$type = self::keyword( isset( $g['type'] ) ? $g['type'] : '', self::GRAD_TYPES, 'linear' );
		if ( 'radial' === $type ) {
			return 'radial-gradient(circle,' . implode( ',', $stops ) . ')';
		}
		$angle = self::trim_num( self::num( isset( $g['angle'] ) ? $g['angle'] : 135, 0, 360, 0 ) );
		return 'linear-gradient(' . $angle . 'deg,' . implode( ',', $stops ) . ')';
	}

	/**
	 * Allowlist a color: hex, rgb/rgba/hsl/hsla with numeric components, or
	 * a WeIdea/WordPress token var(). Anything else becomes ''.
	 *
	 * @param mixed $c Raw color.
	 * @return string
	 */
	public static function color( $c ) {
		if ( ! is_string( $c ) ) {
			return '';
		}
		$c = trim( $c );
		if ( preg_match( '/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/', $c ) ) {
			return $c;
		}
		if ( preg_match( '/^(rgb|rgba|hsl|hsla)\(\s*[0-9.,%\s\/]+\)$/', $c ) ) {
			return $c;
		}
		if ( preg_match( '/^var\(--(wi|global)-[a-z0-9-]+\)$/', $c ) ) {
			return $c;
		}
		return '';
	}

	/**
	 * Validate a media URL: http/https only, then reject any residual
	 * metacharacter that could escape url("…"). Returns '' when unsafe.
	 *
	 * @param mixed $u Raw URL.
	 * @return string
	 */
	public static function url( $u ) {
		if ( ! is_string( $u ) || '' === trim( $u ) ) {
			return '';
		}
		$clean = esc_url_raw( trim( $u ), array( 'http', 'https' ) );
		if ( '' === $clean || preg_match( '/[\'"()<>\\\\\s]/', $clean ) ) {
			return '';
		}
		return $clean;
	}

	/**
	 * Return $v if in the allowed enum, else the safe default.
	 *
	 * @param mixed  $v       Raw value.
	 * @param array  $allowed Allowed keywords.
	 * @param string $default Fallback.
	 * @return string
	 */
	private static function keyword( $v, $allowed, $default ) {
		return ( is_string( $v ) && in_array( $v, $allowed, true ) ) ? $v : $default;
	}

	/**
	 * Cast to float, clamp to [min,max], round to $dp decimals.
	 *
	 * @param mixed $v   Raw.
	 * @param float $min Minimum.
	 * @param float $max Maximum.
	 * @param int   $dp  Decimal places.
	 * @return float
	 */
	private static function num( $v, $min, $max, $dp ) {
		$n = is_numeric( $v ) ? (float) $v : 0.0;
		$n = max( $min, min( $max, $n ) );
		return round( $n, $dp );
	}

	/**
	 * Format a number without a trailing ".0".
	 *
	 * @param float $n Number.
	 * @return string
	 */
	private static function trim_num( $n ) {
		$s = rtrim( rtrim( sprintf( '%.2f', $n ), '0' ), '.' );
		return '' === $s ? '0' : $s;
	}

	/**
	 * Set one declaration into the fragment.
	 *
	 * @param array  $out      Fragment (by reference).
	 * @param string $device   Device id.
	 * @param string $selector Selector.
	 * @param string $property Property.
	 * @param string $value    Value.
	 */
	private static function put( &$out, $device, $selector, $property, $value ) {
		if ( ! isset( $out[ $device ] ) ) {
			$out[ $device ] = array();
		}
		if ( ! isset( $out[ $device ][ $selector ] ) ) {
			$out[ $device ][ $selector ] = array();
		}
		$out[ $device ][ $selector ][ $property ] = $value;
	}
}
