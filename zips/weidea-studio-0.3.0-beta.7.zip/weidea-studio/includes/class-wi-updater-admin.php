<?php
/**
 * Plugins-screen UI for the update channel: the per-site stable/beta
 * switch and one-click version rollback.
 *
 * Rollback rides WordPress's own upgrade flow: arming a rollback stores a
 * short-lived target version, then hands off to the native
 * update.php?action=upgrade-plugin screen, where WI_Updater presents the
 * older retained release as "the update". Same pipeline, same UI, same
 * safety — just pointed backwards. A builder update misbehaving on a live
 * store must be a thirty-second incident, not an evening.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Channel switch + rollback actions.
 */
final class WI_Updater_Admin {

	/**
	 * Hook registration.
	 */
	public static function init() {
		add_filter( 'plugin_action_links_' . WI_PLUGIN_BASENAME, array( __CLASS__, 'action_links' ) );
		add_action( 'admin_post_wi_switch_channel', array( __CLASS__, 'handle_switch_channel' ) );
		add_action( 'admin_post_wi_rollback', array( __CLASS__, 'handle_rollback' ) );
		add_action( 'admin_notices', array( __CLASS__, 'channel_notice' ) );
	}

	/**
	 * Add "switch channel" and "roll back" to the plugin's row.
	 *
	 * @param string[] $links Existing action links.
	 * @return string[]
	 */
	public static function action_links( $links ) {
		if ( ! current_user_can( 'update_plugins' ) ) {
			return $links;
		}

		$updater = WI_Updater::instance();
		$other   = 'beta' === $updater->channel() ? 'stable' : 'beta';

		$switch_url = wp_nonce_url(
			add_query_arg(
				array(
					'action'  => 'wi_switch_channel',
					'channel' => $other,
				),
				admin_url( 'admin-post.php' )
			),
			'wi_switch_channel_' . $other
		);
		$links['wi-channel'] = sprintf(
			'<a href="%s">%s</a>',
			esc_url( $switch_url ),
			'beta' === $other
				? esc_html__( 'Switch to beta channel', 'weidea-studio' )
				: esc_html__( 'Switch to stable channel', 'weidea-studio' )
		);

		$target = $updater->rollback_target();
		if ( $target ) {
			$rollback_url = wp_nonce_url(
				add_query_arg(
					array(
						'action'  => 'wi_rollback',
						'version' => rawurlencode( (string) $target->version ),
					),
					admin_url( 'admin-post.php' )
				),
				'wi_rollback_' . (string) $target->version
			);
			$links['wi-rollback'] = sprintf(
				'<a href="%s">%s</a>',
				esc_url( $rollback_url ),
				sprintf(
					/* translators: %s: version number. */
					esc_html__( 'Roll back to %s', 'weidea-studio' ),
					esc_html( (string) $target->version )
				)
			);
		}

		return $links;
	}

	/**
	 * Switch the site's release channel, drop caches, re-check.
	 */
	public static function handle_switch_channel() {
		$channel = isset( $_GET['channel'] ) ? sanitize_key( wp_unslash( $_GET['channel'] ) ) : '';
		check_admin_referer( 'wi_switch_channel_' . $channel );
		if ( ! current_user_can( 'update_plugins' ) ) {
			wp_die( esc_html__( 'You are not allowed to change the WeIdea Studio release channel.', 'weidea-studio' ) );
		}

		update_option( WI_Updater::CHANNEL_OPTION, 'beta' === $channel ? 'beta' : 'stable' );

		// A channel change must be visible immediately, not after cache expiry.
		delete_site_transient( WI_Updater::TRANSIENT );
		delete_site_transient( 'update_plugins' );

		wp_safe_redirect(
			add_query_arg( 'wi-channel', rawurlencode( $channel ), admin_url( 'plugins.php' ) )
		);
		exit;
	}

	/**
	 * Arm a rollback and hand off to the native upgrade screen.
	 */
	public static function handle_rollback() {
		$version = isset( $_GET['version'] ) ? sanitize_text_field( wp_unslash( $_GET['version'] ) ) : '';
		check_admin_referer( 'wi_rollback_' . $version );
		if ( ! current_user_can( 'update_plugins' ) ) {
			wp_die( esc_html__( 'You are not allowed to roll WeIdea Studio back.', 'weidea-studio' ) );
		}

		if ( ! WI_Updater::instance()->find_release( $version ) ) {
			wp_die( esc_html__( 'That version is not retained on the update channel.', 'weidea-studio' ) );
		}

		set_site_transient( WI_Updater::ROLLBACK_TARGET, $version, 5 * MINUTE_IN_SECONDS );

		// Built by hand, NOT with wp_nonce_url(): that helper HTML-escapes
		// its output (for use in href attributes), which corrupts the
		// query string when sent as a Location header.
		$upgrade_url = add_query_arg(
			array(
				'action'   => 'upgrade-plugin',
				'plugin'   => rawurlencode( WI_PLUGIN_BASENAME ),
				'_wpnonce' => wp_create_nonce( 'upgrade-plugin_' . WI_PLUGIN_BASENAME ),
			),
			self_admin_url( 'update.php' )
		);
		wp_safe_redirect( $upgrade_url );
		exit;
	}

	/**
	 * Confirmation after a channel switch.
	 */
	public static function channel_notice() {
		if ( empty( $_GET['wi-channel'] ) || ! current_user_can( 'update_plugins' ) ) {
			return;
		}
		$channel = sanitize_key( wp_unslash( $_GET['wi-channel'] ) );
		printf(
			'<div class="notice notice-success is-dismissible"><p>%s</p></div>',
			'beta' === $channel
				? esc_html__( 'WeIdea Studio is now on the beta channel — this site receives everything hot.', 'weidea-studio' )
				: esc_html__( 'WeIdea Studio is now on the stable channel — this site receives promoted releases only.', 'weidea-studio' )
		);
	}
}
