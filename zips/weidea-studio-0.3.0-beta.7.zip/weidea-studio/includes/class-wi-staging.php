<?php
/**
 * Staged edits: workbench saves never touch the live post.
 *
 * Each live post gets at most one staged copy (a hidden draft clone,
 * linked by meta). Editing happens on the copy through the normal block
 * editor; a signed preview link renders the staged content at the REAL
 * live URL for anyone holding the link; Deploy (WI_Deploy) publishes the
 * copy over the live post and retires it.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Staged-copy lifecycle, preview links, REST surface.
 */
final class WI_Staging {

	const META_KEY = '_wi_staging_of';

	/**
	 * Hook registration.
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		add_action( 'pre_get_posts', array( __CLASS__, 'hide_staged_copies' ) );
		add_action( 'wp', array( __CLASS__, 'maybe_preview' ) );
	}

	/**
	 * REST routes.
	 */
	public static function register_routes() {
		register_rest_route(
			'wi/v1',
			'/stage',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_stage' ),
				'permission_callback' => function ( $request ) {
					return current_user_can( 'edit_post', (int) $request['post'] );
				},
				'args'                => array(
					'post' => array(
						'type'     => 'integer',
						'required' => true,
					),
				),
			)
		);
	}

	/**
	 * Create (or reuse) the staged copy for a post.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function rest_stage( $request ) {
		$post = get_post( (int) $request['post'] );
		if ( ! $post || wp_is_post_revision( $post ) ) {
			return new WP_Error( 'wi_no_post', __( 'Post not found.', 'weidea-studio' ), array( 'status' => 404 ) );
		}

		$staged_id = self::staged_id( $post->ID );
		if ( ! $staged_id ) {
			$staged_id = wp_insert_post(
				array(
					'post_type'    => $post->post_type,
					'post_status'  => 'draft',
					'post_title'   => $post->post_title,
					'post_content' => $post->post_content,
					'meta_input'   => array( self::META_KEY => $post->ID ),
				),
				true
			);
			if ( is_wp_error( $staged_id ) ) {
				return $staged_id;
			}
		}

		return rest_ensure_response(
			array(
				'staged_id'   => $staged_id,
				'edit_url'    => add_query_arg( 'wi-workbench', '1', get_edit_post_link( $staged_id, 'raw' ) ),
				'preview_url' => self::preview_url( $post->ID, $staged_id ),
			)
		);
	}

	/**
	 * The staged copy's ID for a live post, if one exists.
	 *
	 * @param int $post_id Live post ID.
	 * @return int 0 when none.
	 */
	public static function staged_id( $post_id ) {
		$found = get_posts(
			array(
				'post_type'      => 'any',
				'post_status'    => array( 'draft', 'pending' ),
				'meta_key'       => self::META_KEY, // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'     => (int) $post_id, // phpcs:ignore WordPress.DB.SlowDBQuery
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		return $found ? (int) $found[0] : 0;
	}

	/**
	 * Signed preview URL: the LIVE permalink plus a token bound to this
	 * specific live/staged pair. Deploy deletes the staged copy, which
	 * kills the link.
	 *
	 * @param int $post_id   Live post ID.
	 * @param int $staged_id Staged copy ID.
	 * @return string
	 */
	public static function preview_url( $post_id, $staged_id ) {
		return add_query_arg(
			'wi-preview',
			self::preview_token( $post_id, $staged_id ),
			get_permalink( $post_id )
		);
	}

	/**
	 * The preview token for a live/staged pair.
	 *
	 * @param int $post_id   Live post ID.
	 * @param int $staged_id Staged copy ID.
	 * @return string
	 */
	private static function preview_token( $post_id, $staged_id ) {
		return substr( hash_hmac( 'sha256', 'wi-preview|' . (int) $post_id . '|' . (int) $staged_id, wp_salt( 'auth' ) ), 0, 32 );
	}

	/**
	 * Serve staged content at the live URL when a valid token is present.
	 * Signed links are shareable by design — the token, not a login, is
	 * the credential, and it dies when the staged copy does.
	 */
	public static function maybe_preview() {
		if ( ! is_singular() || empty( $_GET['wi-preview'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		$post_id   = get_queried_object_id();
		$staged_id = self::staged_id( $post_id );
		if ( ! $staged_id ) {
			return;
		}
		$token = sanitize_text_field( wp_unslash( $_GET['wi-preview'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! hash_equals( self::preview_token( $post_id, $staged_id ), $token ) ) {
			return;
		}

		$staged = get_post( $staged_id );
		if ( ! $staged ) {
			return;
		}

		add_filter(
			'the_content',
			function ( $content ) use ( $staged, $post_id ) {
				if ( get_the_ID() !== $post_id ) {
					return $content;
				}
				// Run the staged markup through block rendering exactly
				// like live content (instance CSS, conditional assets).
				return do_blocks( $staged->post_content );
			},
			0
		);
		add_filter(
			'the_title',
			function ( $title, $id = 0 ) use ( $staged, $post_id ) {
				return (int) $id === (int) $post_id ? $staged->post_title : $title;
			},
			10,
			2
		);
	}

	/**
	 * Keep staged copies out of admin list tables and nav-menu pickers.
	 *
	 * @param WP_Query $query Query.
	 */
	public static function hide_staged_copies( $query ) {
		if ( ! is_admin() || ! $query->is_main_query() ) {
			return;
		}
		$screen_ok = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $screen_ok && 'edit' !== $screen_ok->base ) {
			return;
		}
		$meta_query   = (array) $query->get( 'meta_query' );
		$meta_query[] = array(
			'key'     => self::META_KEY,
			'compare' => 'NOT EXISTS',
		);
		$query->set( 'meta_query', $meta_query );
	}
}
