<?php
/**
 * The motion system, Tier 1: entrance presets, stagger, hover reactions.
 *
 * Animation never touches saved markup — blocks save clean HTML, and
 * this class stamps the motion classes onto the block's root tag at
 * render time from the shared Animate attributes (no block deprecations,
 * ever, per the content-is-sacred rule). The motion stylesheet and the
 * ~1 KB view helper are enqueued ONLY when an animated block is actually
 * on the page; the safe-mode kill switch disables the JS site-wide.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Render-time class application + conditional asset loading.
 */
final class WI_Motion {

	/**
	 * Whether motion assets are already enqueued this request.
	 *
	 * @var bool
	 */
	private static $enqueued = false;

	/**
	 * Hook registration.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_assets' ), 20 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_for_content' ) );
		// Priority 9: decorate the block root before WI_Assets (10)
		// prepends instance <style> tags.
		add_filter( 'render_block', array( __CLASS__, 'render_block' ), 9, 2 );
	}

	/**
	 * Register (never blindly enqueue) the motion assets.
	 */
	public static function register_assets() {
		if ( file_exists( WI_PLUGIN_DIR . 'build/motion/style-view.css' ) ) {
			wp_register_style( 'wi-motion', WI_PLUGIN_URL . 'build/motion/style-view.css', array(), WI_VERSION );
		}
		if ( file_exists( WI_PLUGIN_DIR . 'build/motion/view.js' ) ) {
			wp_register_script(
				'wi-motion-view',
				WI_PLUGIN_URL . 'build/motion/view.js',
				array(),
				WI_VERSION,
				array(
					'in_footer' => true,
					'strategy'  => 'defer',
				)
			);
		}
	}

	/**
	 * Head-time enqueue on singular content so the hide-then-reveal CSS
	 * is present before first paint. The serialized attribute name is a
	 * reliable, cheap needle — it only ever appears in block comments.
	 */
	public static function enqueue_for_content() {
		if ( ! is_singular() ) {
			return;
		}
		$post = get_post();
		if ( $post && false !== strpos( (string) $post->post_content, '"wiAnim' ) ) {
			self::enqueue();
		}
	}

	/**
	 * Stamp motion classes on an animated block's root tag and make sure
	 * the assets ride along (fallback path for non-singular contexts).
	 *
	 * @param string $content Rendered block HTML.
	 * @param array  $block   Parsed block.
	 * @return string
	 */
	public static function render_block( $content, $block ) {
		$name = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
		if ( 0 !== strpos( $name, 'weidea/' ) || '' === trim( $content ) ) {
			return $content;
		}

		$attrs     = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
		$animation = isset( $attrs['wiAnimation'] ) ? sanitize_html_class( $attrs['wiAnimation'] ) : '';
		$hover     = isset( $attrs['wiAnimHover'] ) ? sanitize_html_class( $attrs['wiAnimHover'] ) : '';
		$stagger   = ! empty( $attrs['wiAnimStagger'] );
		if ( '' === $animation && '' === $hover && ! $stagger ) {
			return $content;
		}

		$tags = new WP_HTML_Tag_Processor( $content );
		if ( ! $tags->next_tag() ) {
			return $content;
		}

		if ( '' !== $animation ) {
			$tags->add_class( 'wi-anim' );
			$tags->add_class( 'wi-anim--' . $animation );
			$speed = isset( $attrs['wiAnimSpeed'] ) ? sanitize_html_class( $attrs['wiAnimSpeed'] ) : '';
			$delay = isset( $attrs['wiAnimDelay'] ) ? sanitize_html_class( $attrs['wiAnimDelay'] ) : '';
			if ( '' !== $speed ) {
				$tags->add_class( 'wi-anim-speed--' . $speed );
			}
			if ( '' !== $delay ) {
				$tags->add_class( 'wi-anim-delay--' . $delay );
			}
		}
		if ( '' !== $hover ) {
			$tags->add_class( 'wi-hover--' . $hover );
		}
		if ( $stagger ) {
			$tags->set_attribute( 'data-wi-stagger', '1' );
		}

		self::enqueue();
		return $tags->get_updated_html();
	}

	/**
	 * Enqueue the motion stylesheet + view helper once. Safe mode skips
	 * BOTH: the CSS hides elements that only the script reveals, so the
	 * pair ships together or not at all — flip the kill switch and every
	 * animated block is simply visible, static, safe.
	 */
	private static function enqueue() {
		if ( self::$enqueued ) {
			return;
		}
		self::$enqueued = true;

		if ( WI_Settings_Page::safe_mode() ) {
			return;
		}
		if ( wp_style_is( 'wi-motion', 'registered' ) ) {
			wp_enqueue_style( 'wi-motion' );
		}
		if ( wp_script_is( 'wi-motion-view', 'registered' ) ) {
			wp_enqueue_script( 'wi-motion-view' );
		}
	}
}
