<?php
/**
 * Settings → WeIdea Studio: breakpoints, release channel, deploy key,
 * safe mode. Small on purpose — the workbench grows richer settings UI
 * in later phases; this page is the plain-WP home for site-level knobs.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The admin settings page + safe-mode plumbing.
 */
final class WI_Settings_Page {

	const SAFE_MODE_OPTION = 'wi_safe_mode';

	/**
	 * Hook registration.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_page' ) );
		add_action( 'admin_init', array( __CLASS__, 'handle_save' ) );
		add_action( 'admin_bar_menu', array( __CLASS__, 'safe_mode_badge' ), 100 );
		add_action( 'init', array( __CLASS__, 'safe_mode_query_toggle' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
	}

	/**
	 * The Touch ID registration script, on this page only.
	 *
	 * @param string $hook Admin page hook.
	 */
	public static function enqueue( $hook ) {
		if ( 'settings_page_weidea-studio' !== $hook ) {
			return;
		}
		$asset_file = WI_PLUGIN_DIR . 'build/webauthn-settings/index.asset.php';
		if ( ! file_exists( $asset_file ) ) {
			return;
		}
		$asset = require $asset_file;
		wp_enqueue_script(
			'wi-webauthn-settings',
			WI_PLUGIN_URL . 'build/webauthn-settings/index.js',
			$asset['dependencies'],
			$asset['version'],
			true
		);
	}

	/**
	 * Whether the safe-mode kill switch is on.
	 *
	 * @return bool
	 */
	public static function safe_mode() {
		return (bool) get_option( self::SAFE_MODE_OPTION, false );
	}

	/**
	 * Register the page.
	 */
	public static function add_page() {
		add_options_page(
			__( 'WeIdea Studio', 'weidea-studio' ),
			__( 'WeIdea Studio', 'weidea-studio' ),
			'manage_options',
			'weidea-studio',
			array( __CLASS__, 'render' )
		);
	}

	/**
	 * Save handler (single nonce-checked POST, no Settings API
	 * indirection needed for four fields).
	 */
	public static function handle_save() {
		if ( ! isset( $_POST['wi_settings_nonce'] ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		check_admin_referer( 'wi_save_settings', 'wi_settings_nonce' );

		$tablet = isset( $_POST['wi_bp_tablet'] ) ? (int) $_POST['wi_bp_tablet'] : 0;
		$mobile = isset( $_POST['wi_bp_mobile'] ) ? (int) $_POST['wi_bp_mobile'] : 0;
		if ( $tablet && $mobile ) {
			update_option(
				WI_Breakpoints::OPTION,
				WI_Breakpoints::sanitize(
					array(
						'tablet' => $tablet,
						'mobile' => $mobile,
					)
				)
			);
		}

		if ( isset( $_POST['wi_channel'] ) ) {
			update_option( WI_Updater::CHANNEL_OPTION, 'beta' === $_POST['wi_channel'] ? 'beta' : 'stable' );
			delete_site_transient( WI_Updater::TRANSIENT );
		}

		update_option( self::SAFE_MODE_OPTION, ! empty( $_POST['wi_safe_mode'] ) );

		$key = isset( $_POST['wi_deploy_key'] ) ? (string) wp_unslash( $_POST['wi_deploy_key'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- hashed immediately, never stored raw.
		if ( '' !== trim( $key ) ) {
			update_option( WI_Deploy::KEY_OPTION, wp_hash_password( trim( $key ) ), false );
		}

		add_settings_error( 'weidea-studio', 'saved', __( 'WeIdea Studio settings saved.', 'weidea-studio' ), 'success' );
	}

	/**
	 * Render the page.
	 */
	public static function render() {
		$bp        = WI_Breakpoints::get();
		$channel   = WI_Updater::instance()->channel();
		$has_key   = '' !== get_option( WI_Deploy::KEY_OPTION, '' );
		$safe_mode = self::safe_mode();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'WeIdea Studio', 'weidea-studio' ); ?></h1>
			<?php settings_errors( 'weidea-studio' ); ?>
			<form method="post">
				<?php wp_nonce_field( 'wi_save_settings', 'wi_settings_nonce' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><?php esc_html_e( 'Breakpoints', 'weidea-studio' ); ?></th>
						<td>
							<label><?php esc_html_e( 'Tablet at and below', 'weidea-studio' ); ?>
								<input name="wi_bp_tablet" type="number" value="<?php echo esc_attr( $bp['tablet'] ); ?>" class="small-text" min="320" max="2560"> px</label>
							&nbsp;&nbsp;
							<label><?php esc_html_e( 'Phone at and below', 'weidea-studio' ); ?>
								<input name="wi_bp_mobile" type="number" value="<?php echo esc_attr( $bp['mobile'] ); ?>" class="small-text" min="320" max="2560"> px</label>
							<p class="description"><?php esc_html_e( 'Generated CSS recompiles against these on every render — changing them later is a recompile, not a rebuild.', 'weidea-studio' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Release channel', 'weidea-studio' ); ?></th>
						<td>
							<label><input type="radio" name="wi_channel" value="stable" <?php checked( 'stable', $channel ); ?>> <?php esc_html_e( 'Stable — promoted releases only', 'weidea-studio' ); ?></label><br>
							<label><input type="radio" name="wi_channel" value="beta" <?php checked( 'beta', $channel ); ?>> <?php esc_html_e( 'Beta — receives everything hot', 'weidea-studio' ); ?></label>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Deploy key', 'weidea-studio' ); ?></th>
						<td>
							<input name="wi_deploy_key" type="password" class="regular-text" autocomplete="new-password"
								placeholder="<?php echo esc_attr( $has_key ? __( 'Set — enter a new key to replace it', 'weidea-studio' ) : __( 'Choose a deploy key', 'weidea-studio' ) ); ?>">
							<p class="description"><?php esc_html_e( 'Typed at deploy time as the fallback ceremony (Touch ID rides on top). Stored only as a hash; failures are rate-limited.', 'weidea-studio' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Safe mode', 'weidea-studio' ); ?></th>
						<td>
							<label><input type="checkbox" name="wi_safe_mode" value="1" <?php checked( $safe_mode ); ?>>
								<?php esc_html_e( 'Kill switch: disable all WeIdea frontend JavaScript site-wide. Static content is unaffected.', 'weidea-studio' ); ?></label>
						</td>
					</tr>
				</table>
				<?php submit_button( __( 'Save settings', 'weidea-studio' ) ); ?>
			</form>

			<h2><?php esc_html_e( 'Deploy with Touch ID', 'weidea-studio' ); ?></h2>
			<p class="description">
				<?php esc_html_e( 'Registered devices confirm deploys with a fingerprint (or the device passkey) instead of the typed key. Needs HTTPS — on local development the typed key does the job.', 'weidea-studio' ); ?>
			</p>
			<?php $credentials = WI_WebAuthn::credentials( get_current_user_id() ); ?>
			<?php if ( $credentials ) : ?>
				<table class="widefat striped" style="max-width: 640px" id="wi-webauthn-list">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Device', 'weidea-studio' ); ?></th>
							<th><?php esc_html_e( 'Added', 'weidea-studio' ); ?></th>
							<th></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $credentials as $credential ) : ?>
							<tr>
								<td><?php echo esc_html( '' !== $credential['label'] ? $credential['label'] : __( 'Passkey', 'weidea-studio' ) ); ?></td>
								<td><?php echo esc_html( date_i18n( get_option( 'date_format' ), $credential['added'] ) ); ?></td>
								<td>
									<button type="button" class="button-link-delete wi-webauthn-remove" data-id="<?php echo esc_attr( $credential['id'] ); ?>">
										<?php esc_html_e( 'Remove', 'weidea-studio' ); ?>
									</button>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
			<p>
				<button type="button" class="button" id="wi-webauthn-register">
					<?php esc_html_e( 'Register this device for Touch ID deploys', 'weidea-studio' ); ?>
				</button>
			</p>
		</div>
		<?php
	}

	/**
	 * A loud badge whenever the kill switch is on.
	 *
	 * @param WP_Admin_Bar $bar Admin bar.
	 */
	public static function safe_mode_badge( $bar ) {
		if ( ! self::safe_mode() || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$bar->add_node(
			array(
				'id'    => 'wi-safe-mode',
				'title' => '<span style="color:#f86368">' . esc_html__( 'WeIdea safe mode ON', 'weidea-studio' ) . '</span>',
				'href'  => admin_url( 'options-general.php?page=weidea-studio' ),
			)
		);
	}

	/**
	 * Instant toggle from any URL: ?wi-safe-mode=on|off (+ nonce), for
	 * the moment something misbehaves on live and seconds matter.
	 */
	public static function safe_mode_query_toggle() {
		if ( ! isset( $_GET['wi-safe-mode'] ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		check_admin_referer( 'wi_safe_mode' );
		update_option( self::SAFE_MODE_OPTION, 'on' === $_GET['wi-safe-mode'] );
	}
}
