<?php
/**
 * WebAuthn for the deploy ceremony — Touch ID on the Mac, any platform
 * authenticator elsewhere. Registration and assertion verified entirely
 * server-side (ES256 via OpenSSL, attestation "none"), no third-party
 * services. The typed deploy key remains the documented fallback; both
 * confirm the same wi/v1/deploy endpoint.
 *
 * Requires a secure context in the browser (HTTPS, or localhost in
 * development) — themall.life qualifies.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Credential registration, assertion verification, credential storage.
 */
final class WI_WebAuthn {

	const META          = 'wi_webauthn_credentials';
	const REG_CHALLENGE = 'wi_wa_register_';
	const GET_CHALLENGE = 'wi_wa_assert_';

	/**
	 * Hook registration.
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * REST routes. All behind the deploy capability: registering a
	 * deploy credential is itself a deploy-privileged act.
	 */
	public static function register_routes() {
		$perm = function () {
			return current_user_can( 'wi_deploy' );
		};

		register_rest_route(
			'wi/v1',
			'/webauthn/register-options',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_register_options' ),
				'permission_callback' => $perm,
			)
		);
		register_rest_route(
			'wi/v1',
			'/webauthn/register',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_register' ),
				'permission_callback' => $perm,
			)
		);
		register_rest_route(
			'wi/v1',
			'/webauthn/assert-options',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_assert_options' ),
				'permission_callback' => $perm,
			)
		);
		register_rest_route(
			'wi/v1',
			'/webauthn/remove',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_remove' ),
				'permission_callback' => $perm,
				'args'                => array(
					'id' => array(
						'type'     => 'string',
						'required' => true,
					),
				),
			)
		);
	}

	/**
	 * Base64url without padding.
	 *
	 * @param string $bytes Raw bytes.
	 * @return string
	 */
	public static function b64url_encode( $bytes ) {
		return rtrim( strtr( base64_encode( $bytes ), '+/', '-_' ), '=' );
	}

	/**
	 * Decode base64url.
	 *
	 * @param string $data Encoded string.
	 * @return string Raw bytes ('' on garbage).
	 */
	public static function b64url_decode( $data ) {
		$decoded = base64_decode( strtr( (string) $data, '-_', '+/' ), true );
		return false === $decoded ? '' : $decoded;
	}

	/**
	 * The relying-party ID: the site's host.
	 *
	 * @return string
	 */
	private static function rp_id() {
		return (string) wp_parse_url( home_url(), PHP_URL_HOST );
	}

	/**
	 * The origin the browser must report in clientDataJSON.
	 *
	 * @return string
	 */
	private static function expected_origin() {
		$parts  = wp_parse_url( home_url() );
		$origin = $parts['scheme'] . '://' . $parts['host'];
		if ( ! empty( $parts['port'] ) ) {
			$origin .= ':' . $parts['port'];
		}
		return $origin;
	}

	/**
	 * This user's registered credentials.
	 *
	 * @param int $user_id User ID.
	 * @return array[]
	 */
	public static function credentials( $user_id ) {
		$stored = get_user_meta( $user_id, self::META, true );
		return is_array( $stored ) ? $stored : array();
	}

	/**
	 * Registration options for navigator.credentials.create().
	 *
	 * @return WP_REST_Response
	 */
	public static function rest_register_options() {
		$user      = wp_get_current_user();
		$challenge = self::b64url_encode( random_bytes( 32 ) );
		set_transient( self::REG_CHALLENGE . $user->ID, $challenge, 5 * MINUTE_IN_SECONDS );

		return rest_ensure_response(
			array(
				'rp'                     => array(
					'id'   => self::rp_id(),
					'name' => get_bloginfo( 'name' ),
				),
				'user'                   => array(
					'id'          => self::b64url_encode( 'wi-user-' . $user->ID ),
					'name'        => $user->user_login,
					'displayName' => $user->display_name,
				),
				'challenge'              => $challenge,
				'pubKeyCredParams'       => array(
					array(
						'type' => 'public-key',
						'alg'  => -7, // ES256 — what platform authenticators (Touch ID) use.
					),
				),
				'timeout'                => 60000,
				'attestation'            => 'none',
				'authenticatorSelection' => array(
					'userVerification' => 'required',
				),
				'excludeCredentials'     => array_map(
					function ( $cred ) {
						return array(
							'type' => 'public-key',
							'id'   => $cred['id'],
						);
					},
					self::credentials( $user->ID )
				),
			)
		);
	}

	/**
	 * Verify and store a new credential.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function rest_register( $request ) {
		$user_id  = get_current_user_id();
		$response = $request['response'];
		if ( ! is_array( $response ) || empty( $response['clientDataJSON'] ) || empty( $response['attestationObject'] ) ) {
			return new WP_Error( 'wi_wa_bad_request', __( 'Malformed registration payload.', 'weidea-studio' ), array( 'status' => 400 ) );
		}

		$client_check = self::verify_client_data(
			(string) $response['clientDataJSON'],
			'webauthn.create',
			get_transient( self::REG_CHALLENGE . $user_id )
		);
		delete_transient( self::REG_CHALLENGE . $user_id );
		if ( is_wp_error( $client_check ) ) {
			return $client_check;
		}

		try {
			$attestation = WI_CBOR::decode( self::b64url_decode( (string) $response['attestationObject'] ) );
			if ( ! is_array( $attestation ) || empty( $attestation['authData'] ) ) {
				throw new InvalidArgumentException( 'Missing authData.' );
			}
			$parsed = self::parse_auth_data( $attestation['authData'], true );
		} catch ( InvalidArgumentException $e ) {
			return new WP_Error( 'wi_wa_bad_attestation', __( 'The authenticator response could not be parsed.', 'weidea-studio' ), array( 'status' => 400 ) );
		}

		$credentials   = self::credentials( $user_id );
		$credentials[] = array(
			'id'    => self::b64url_encode( $parsed['credential_id'] ),
			'key'   => $parsed['public_key_pem'],
			'count' => $parsed['sign_count'],
			'label' => sanitize_text_field( (string) $request['label'] ),
			'added' => time(),
		);
		update_user_meta( $user_id, self::META, $credentials );

		return rest_ensure_response( array( 'registered' => true ) );
	}

	/**
	 * Assertion options for navigator.credentials.get().
	 *
	 * @return WP_REST_Response
	 */
	public static function rest_assert_options() {
		$user_id   = get_current_user_id();
		$challenge = self::b64url_encode( random_bytes( 32 ) );
		set_transient( self::GET_CHALLENGE . $user_id, $challenge, 5 * MINUTE_IN_SECONDS );

		return rest_ensure_response(
			array(
				'challenge'        => $challenge,
				'rpId'             => self::rp_id(),
				'timeout'          => 60000,
				'userVerification' => 'required',
				'allowCredentials' => array_map(
					function ( $cred ) {
						return array(
							'type' => 'public-key',
							'id'   => $cred['id'],
						);
					},
					self::credentials( $user_id )
				),
			)
		);
	}

	/**
	 * Verify a deploy assertion (called by WI_Deploy).
	 *
	 * @param int   $user_id User ID.
	 * @param array $payload { id, response: { clientDataJSON, authenticatorData, signature } }.
	 * @return true|WP_Error
	 */
	public static function verify_assertion( $user_id, $payload ) {
		if ( ! is_array( $payload ) || empty( $payload['id'] ) || empty( $payload['response'] ) || ! is_array( $payload['response'] ) ) {
			return self::denied( 'malformed payload' );
		}
		$response = $payload['response'];
		if ( empty( $response['clientDataJSON'] ) || empty( $response['authenticatorData'] ) || empty( $response['signature'] ) ) {
			return self::denied( 'missing response fields' );
		}

		$credential = null;
		$index      = null;
		$stored     = self::credentials( $user_id );
		foreach ( $stored as $i => $candidate ) {
			if ( hash_equals( $candidate['id'], (string) $payload['id'] ) ) {
				$credential = $candidate;
				$index      = $i;
				break;
			}
		}
		if ( ! $credential ) {
			return self::denied( 'unknown credential' );
		}

		$challenge    = get_transient( self::GET_CHALLENGE . $user_id );
		$client_check = self::verify_client_data( (string) $response['clientDataJSON'], 'webauthn.get', $challenge );
		delete_transient( self::GET_CHALLENGE . $user_id );
		if ( is_wp_error( $client_check ) ) {
			return self::denied( 'client data rejected' );
		}

		$auth_data = self::b64url_decode( (string) $response['authenticatorData'] );
		try {
			$parsed = self::parse_auth_data( $auth_data, false );
		} catch ( InvalidArgumentException $e ) {
			return self::denied( 'authenticator data: ' . $e->getMessage() );
		}

		// Signature covers authenticatorData || SHA-256(clientDataJSON).
		$signed = $auth_data . hash( 'sha256', self::b64url_decode( (string) $response['clientDataJSON'] ), true );
		$result = openssl_verify(
			$signed,
			self::b64url_decode( (string) $response['signature'] ),
			$credential['key'],
			OPENSSL_ALGO_SHA256
		);
		if ( 1 !== $result ) {
			return self::denied( 'signature invalid' );
		}

		// Best-effort clone detection: sign counts must not go backwards.
		// (Apple platform authenticators always report 0 — skip then.)
		if ( $parsed['sign_count'] > 0 || $credential['count'] > 0 ) {
			if ( $parsed['sign_count'] <= $credential['count'] && 0 !== $parsed['sign_count'] ) {
				return self::denied( 'sign count regressed' );
			}
			$stored[ $index ]['count'] = $parsed['sign_count'];
			update_user_meta( $user_id, self::META, $stored );
		}

		return true;
	}

	/**
	 * The uniform denial. The specific reason is appended only under
	 * WP_DEBUG (dev/tests) — production callers get one opaque message,
	 * an attacker learns nothing from which check tripped.
	 *
	 * @param string $reason Which check failed.
	 * @return WP_Error
	 */
	private static function denied( $reason ) {
		$message = __( 'Touch ID confirmation failed.', 'weidea-studio' );
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			$message .= ' [' . $reason . ']';
		}
		return new WP_Error( 'wi_wa_denied', $message, array( 'status' => 403 ) );
	}

	/**
	 * Remove a registered credential.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function rest_remove( $request ) {
		$user_id = get_current_user_id();
		$kept    = array_values(
			array_filter(
				self::credentials( $user_id ),
				function ( $cred ) use ( $request ) {
					return ! hash_equals( $cred['id'], (string) $request['id'] );
				}
			)
		);
		update_user_meta( $user_id, self::META, $kept );
		return rest_ensure_response( array( 'removed' => true ) );
	}

	/**
	 * Shared clientDataJSON checks: type, challenge, origin.
	 *
	 * @param string       $client_data_b64 Base64url clientDataJSON.
	 * @param string       $expected_type   webauthn.create or webauthn.get.
	 * @param string|false $challenge       The stored challenge.
	 * @return true|WP_Error
	 */
	private static function verify_client_data( $client_data_b64, $expected_type, $challenge ) {
		$fail   = new WP_Error( 'wi_wa_client_data', __( 'The browser response did not match this request.', 'weidea-studio' ), array( 'status' => 403 ) );
		$client = json_decode( self::b64url_decode( $client_data_b64 ), true );

		if ( ! is_array( $client ) || empty( $client['type'] ) || empty( $client['challenge'] ) || empty( $client['origin'] ) ) {
			return $fail;
		}
		if ( $expected_type !== $client['type'] ) {
			return $fail;
		}
		if ( ! is_string( $challenge ) || '' === $challenge || ! hash_equals( $challenge, (string) $client['challenge'] ) ) {
			return $fail;
		}
		if ( self::expected_origin() !== $client['origin'] ) {
			return $fail;
		}
		return true;
	}

	/**
	 * Parse WebAuthn authenticator data.
	 *
	 * @param string $auth_data       Raw authData bytes.
	 * @param bool   $with_credential Whether attested credential data is required (registration).
	 * @return array { sign_count, credential_id?, public_key_pem? }
	 * @throws InvalidArgumentException On malformed data or failed checks.
	 */
	private static function parse_auth_data( $auth_data, $with_credential ) {
		if ( strlen( $auth_data ) < 37 ) {
			throw new InvalidArgumentException( 'authData too short.' );
		}

		$rp_hash = substr( $auth_data, 0, 32 );
		if ( ! hash_equals( hash( 'sha256', self::rp_id(), true ), $rp_hash ) ) {
			throw new InvalidArgumentException( 'rpIdHash mismatch.' );
		}

		$flags = ord( $auth_data[32] );
		if ( ! ( $flags & 0x01 ) ) { // User present.
			throw new InvalidArgumentException( 'User presence not asserted.' );
		}
		if ( ! ( $flags & 0x04 ) ) { // User verified — the Touch ID part.
			throw new InvalidArgumentException( 'User verification not asserted.' );
		}

		$sign_count = unpack( 'N', substr( $auth_data, 33, 4 ) )[1];
		$out        = array( 'sign_count' => $sign_count );

		if ( ! $with_credential ) {
			return $out;
		}

		if ( ! ( $flags & 0x40 ) || strlen( $auth_data ) < 55 ) { // Attested credential data.
			throw new InvalidArgumentException( 'No attested credential data.' );
		}
		$cred_length = unpack( 'n', substr( $auth_data, 53, 2 ) )[1];
		if ( strlen( $auth_data ) < 55 + $cred_length ) {
			throw new InvalidArgumentException( 'Credential ID overruns authData.' );
		}
		$out['credential_id'] = substr( $auth_data, 55, $cred_length );

		$offset   = 55 + $cred_length;
		$cose_key = WI_CBOR::decode( $auth_data, $offset );

		// ES256 on P-256 only — what Touch ID emits.
		if ( ! is_array( $cose_key )
			|| 2 !== ( $cose_key[1] ?? 0 )    // kty: EC2.
			|| -7 !== ( $cose_key[3] ?? 0 )   // alg: ES256.
			|| 1 !== ( $cose_key[-1] ?? 0 )   // crv: P-256.
			|| 32 !== strlen( $cose_key[-2] ?? '' )
			|| 32 !== strlen( $cose_key[-3] ?? '' ) ) {
			throw new InvalidArgumentException( 'Unsupported credential key (ES256/P-256 only).' );
		}

		$out['public_key_pem'] = self::p256_to_pem( $cose_key[-2], $cose_key[-3] );
		return $out;
	}

	/**
	 * Wrap a P-256 point as a PEM SubjectPublicKeyInfo for OpenSSL.
	 *
	 * @param string $x X coordinate (32 bytes).
	 * @param string $y Y coordinate (32 bytes).
	 * @return string PEM.
	 */
	private static function p256_to_pem( $x, $y ) {
		// Fixed DER header: SEQUENCE(SEQUENCE(OID ecPublicKey, OID P-256), BIT STRING(00, point)).
		$der = hex2bin( '3059301306072a8648ce3d020106082a8648ce3d030107034200' ) . "\x04" . $x . $y;
		return "-----BEGIN PUBLIC KEY-----\n" . chunk_split( base64_encode( $der ), 64, "\n" ) . '-----END PUBLIC KEY-----';
	}
}
