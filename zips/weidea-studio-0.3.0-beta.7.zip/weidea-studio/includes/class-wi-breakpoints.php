<?php
/**
 * Site-configurable responsive breakpoints.
 *
 * Every responsive control stores independent desktop/tablet/mobile values;
 * the pixel thresholds those compile against are a site-level setting, not
 * hardcoded. Changing a breakpoint later is a recompile, not a rebuild —
 * generated CSS always reads the current values from here.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Breakpoint storage and access.
 */
final class WI_Breakpoints {

	const OPTION = 'wi_breakpoints';

	/**
	 * Default max-width thresholds in px.
	 *
	 * @var int[]
	 */
	const DEFAULTS = array(
		'tablet' => 1024,
		'mobile' => 767,
	);

	/**
	 * Hook registration.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_setting' ) );
	}

	/**
	 * Register the option so it is editable over the REST settings API
	 * (the workbench UI for it arrives in a later phase).
	 */
	public static function register_setting() {
		register_setting(
			'wi_settings',
			self::OPTION,
			array(
				'type'              => 'object',
				'description'       => __( 'WeIdea Studio responsive breakpoints (max-width in px per device).', 'weidea-studio' ),
				'show_in_rest'      => array(
					'schema' => array(
						'type'       => 'object',
						'properties' => array(
							'tablet' => array( 'type' => 'integer' ),
							'mobile' => array( 'type' => 'integer' ),
						),
					),
				),
				'default'           => self::DEFAULTS,
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
			)
		);
	}

	/**
	 * Clamp breakpoints to sane pixel values.
	 *
	 * @param mixed $value Raw option value.
	 * @return int[]
	 */
	public static function sanitize( $value ) {
		$value = is_array( $value ) ? $value : array();
		$out   = array();
		foreach ( self::DEFAULTS as $device => $default ) {
			$px             = isset( $value[ $device ] ) ? (int) $value[ $device ] : $default;
			$out[ $device ] = max( 320, min( 2560, $px ) );
		}
		if ( $out['mobile'] >= $out['tablet'] ) {
			$out['mobile'] = self::DEFAULTS['mobile'];
			$out['tablet'] = self::DEFAULTS['tablet'];
		}
		return $out;
	}

	/**
	 * The ordered device list — THE single source the CSS generator and
	 * the editor both read. First entry is the base (no media query);
	 * the rest carry descending max-widths. Responsive attribute values
	 * are stored keyed by these ids, so adding a fourth breakpoint later
	 * is an option/filter change — content needs NO migration.
	 *
	 * @return array[] Each: [ 'id' => string, 'max_width' => int|null ].
	 */
	public static function devices() {
		$bp = self::get();

		/**
		 * Filter the ordered device list (base first, then descending
		 * max-widths). The editor UI currently surfaces the first three;
		 * generated CSS honors every entry.
		 *
		 * @param array[] $devices Device descriptors.
		 */
		return apply_filters(
			'wi_devices',
			array(
				array(
					'id'        => 'desktop',
					'max_width' => null,
				),
				array(
					'id'        => 'tablet',
					'max_width' => $bp['tablet'],
				),
				array(
					'id'        => 'mobile',
					'max_width' => $bp['mobile'],
				),
			)
		);
	}

	/**
	 * Current breakpoints.
	 *
	 * @return int[] Array with "tablet" and "mobile" max-width px values.
	 */
	public static function get() {
		$saved = get_option( self::OPTION, array() );
		$bp    = wp_parse_args( is_array( $saved ) ? $saved : array(), self::DEFAULTS );

		/**
		 * Filter the breakpoints used when compiling responsive CSS.
		 *
		 * @param int[] $bp Array with "tablet" and "mobile" px values.
		 */
		return apply_filters(
			'wi_breakpoints',
			array(
				'tablet' => (int) $bp['tablet'],
				'mobile' => (int) $bp['mobile'],
			)
		);
	}
}
