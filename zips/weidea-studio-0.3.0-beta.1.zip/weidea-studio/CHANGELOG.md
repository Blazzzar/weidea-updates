# Changelog

## 0.3.0-beta.1 — The Animate tab (July 2026, beta track)

- **Animate tab on every WeIdea block** — Tier 1 of the headline motion
  module. Entrances (fade, rise, slide from left/right, grow, blur into
  focus, wipe across/upward), speed and delay in plain English, "reveal
  children one by one" stagger, and hover lift/grow. Defined once as a
  shared registry panel; present on all 11 blocks.
- **Motion tokens v1** — `--wi-motion-*` (house easing curve, three
  durations, stagger rhythm, travel distance). Every preset rides them;
  brand zones can override them for per-brand motion personalities.
- **No-bloat discipline**: animation never touches saved markup (classes
  stamped at render — zero block deprecations); the whole runtime is a
  ~1.5 KB dependency-free IntersectionObserver helper + ~2 KB CSS loaded
  only on pages that animate; no-JS visitors lose nothing; visitors who
  prefer reduced motion get fade-only; safe mode renders everything
  static instantly.
- Editor: live "Preview entrance" replaying the real engine's classes on
  the canvas.

## 0.2.0-beta.2 — Touch ID deploys + branded inserter (July 2026, beta track)

- **WebAuthn (Touch ID) deploy ceremony** — register a passkey under
  Settings → WeIdea Studio; the workbench Deploy button confirms with
  Touch ID and falls back to the typed key. Verified entirely
  server-side (audited minimal CBOR decoder, COSE ES256/P-256 → PEM,
  OpenSSL signature check, challenge/origin/rpId/UV validation) — zero
  third-party dependencies. e2e drives the full ceremony against a
  virtual platform authenticator on every release.
- **One branded inserter home** — a "WeIdea Studio" category (first in
  the list) plus a block collection on the weidea/ namespace with the
  brand mark; all blocks grouped together, nothing in WP's default
  categories.
- Fix: workbench Deploy/Preview clicks landing before staging resolved
  were silently dropped; they now queue.

## 0.2.0-beta.1 — Phase 1 core (July 2026, beta track)

- **The block library** — the full v1 layout + content set, all
  registry-driven with help text and demo specs on every panel (37
  controls): Section, Row, Column (responsive widths, stack-on-phones
  honoring the site's configurable breakpoints), Advanced Heading, Text,
  Buttons/Button (hover-state color bindings), Image, Icon (curated
  inline-SVG set), Spacer, Divider. Every WeIdea block icon carries the
  dark-orange brand mark.
- **The workbench** — admin-bar button + ⌘E on any editable live page
  opens a full-screen overlay with the real block editor on a STAGED
  copy. Loader ships to logged-in editors only; visitors get zero bytes
  (e2e-verified against a logged-out context).
- **Staged deploys** — edits land on a hidden staged clone; a signed
  preview link renders staged content at the real live URL (and dies on
  deploy). The deploy ceremony: dedicated `wi_deploy` capability, typed
  deploy key (hashed at rest, failures rate-limited), live content
  snapshotted as a tagged rollback point, SiteGround cache purged when
  present, who/when/what audit log, one-click rollback. (The WebAuthn /
  Touch ID ceremony lands on this same endpoint in the next beta.)
- **Safe-mode kill switch** — Settings toggle + admin-bar badge +
  query-param override; disables WeIdea frontend JS site-wide.
- **Settings → WeIdea Studio** — breakpoints, release channel, deploy
  key, safe mode.
- Registry engine: new control types (select, toggle), hover-state CSS
  bindings, value templates, and breakpoint-aware runtime rules.

## 0.1.0 — Phase 0 scaffold (July 2026)

- **Control registry core** — inspector panels render from JSON schemas in
  `registry/blocks/`; the server generates CSS from the same files. Every
  panel and control carries a plain-English label and help text, enforced
  in CI (`npm run registry:check`).
- **Design tokens** — `--wi-*` custom properties with the Kadence palette
  bridge (`--wi-accent` → `--global-palette1`, etc.), so blocks re-skin per
  brand zone through the pilot site's existing body-class remaps.
- **Section proof block** — `weidea/section`, with registry-driven
  Background / Spacing / Content width panels, independent
  desktop/tablet/phone values with inheritance and override dots, and
  site-configurable breakpoints (`wi_breakpoints` option, REST-exposed).
- **No-bloat contract enforcement** — zero assets on pages without WeIdea
  blocks (e2e-verified), per-block conditional loading, CI budget gate with
  numbers written into every release.
- **Self-hosted update channel, two-track** — manifest-based updater
  (12-hour cache, the plugin's only outbound call) serving `stable` and
  `beta` tracks; each site picks its channel on the Plugins screen or via
  REST (`wi_update_channel`). The manifest retains recent releases, and
  the plugin row offers **one-click rollback** to the previous retained
  version through WordPress's native upgrade flow. Detection, channel
  switching, install, and rollback are all covered by the e2e suite
  against a locally served channel.
- **Tooling** — `@wordpress/scripts` build, wp-env disposable WordPress,
  Playwright e2e harness, GitHub Actions CI, versioned release zip.
