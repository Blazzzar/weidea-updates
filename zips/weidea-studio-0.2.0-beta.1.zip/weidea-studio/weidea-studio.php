<?php
/**
 * Plugin Name:       WeIdea Studio
 * Plugin URI:        https://github.com/Blazzzar/weidea-studio
 * Description:       Self-owned block library, live-page workbench, restyler, and motion system for WordPress.
 * Version:           0.2.0-beta.1
 * Requires at least: 6.5
 * Requires PHP:      7.4
 * Author:            Chris — kitemath.com
 * Author URI:        https://kitemath.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       weidea-studio
 * Update URI:        https://blazzzar.github.io/weidea-updates/weidea-studio.json
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WI_VERSION', '0.2.0-beta.1' );
define( 'WI_PLUGIN_FILE', __FILE__ );
define( 'WI_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WI_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'WI_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

require_once WI_PLUGIN_DIR . 'includes/class-wi-registry.php';
require_once WI_PLUGIN_DIR . 'includes/class-wi-breakpoints.php';
require_once WI_PLUGIN_DIR . 'includes/class-wi-tokens.php';
require_once WI_PLUGIN_DIR . 'includes/class-wi-block-css.php';
require_once WI_PLUGIN_DIR . 'includes/class-wi-blocks.php';
require_once WI_PLUGIN_DIR . 'includes/class-wi-assets.php';
require_once WI_PLUGIN_DIR . 'includes/class-wi-updater.php';
require_once WI_PLUGIN_DIR . 'includes/class-wi-updater-admin.php';
require_once WI_PLUGIN_DIR . 'includes/class-wi-staging.php';
require_once WI_PLUGIN_DIR . 'includes/class-wi-deploy.php';
require_once WI_PLUGIN_DIR . 'includes/class-wi-workbench.php';
require_once WI_PLUGIN_DIR . 'includes/class-wi-settings-page.php';
require_once WI_PLUGIN_DIR . 'includes/class-wi-plugin.php';

WI_Plugin::instance();
