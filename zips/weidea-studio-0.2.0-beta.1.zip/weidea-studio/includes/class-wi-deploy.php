<?php
/**
 * The deploy ceremony: publish staging live, keep a way back, purge
 * caches, and write down who did what.
 *
 * A dedicated wi_deploy capability separates "can edit" from "can
 * deploy" (granted to administrators by default, filterable). Phase 1
 * ships the typed deploy key — stored only as a hash, rate-limited on
 * failures. The WebAuthn (Touch ID) ceremony lands on top of this same
 * endpoint; the key remains the documented fallback.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Deploy + rollback endpoints, deploy key, audit log, cache purge.
 */
final class WI_Deploy {

	const KEY_OPTION = 'wi_deploy_key_hash';
	const LOG_OPTION = 'wi_deploy_log';
	const MAX_LOG    = 100;
	const MAX_FAILS  = 5;

	/**
	 * Hook registration.
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		add_filter( 'user_has_cap', array( __CLASS__, 'grant_deploy_cap' ) );
	}

	/**
	 * Administrators can deploy by default; sites can widen or narrow
	 * this (the day Jen edits without deploying, this is the seam).
	 *
	 * @param array $allcaps User capabilities.
	 * @return array
	 */
	public static function grant_deploy_cap( $allcaps ) {
		if ( ! empty( $allcaps['manage_options'] ) && ! isset( $allcaps['wi_deploy'] ) ) {
			/**
			 * Filter whether this user may deploy.
			 *
			 * @param bool $granted Default grant (administrators).
			 */
			$allcaps['wi_deploy'] = apply_filters( 'wi_grant_deploy_cap', true );
		}
		return $allcaps;
	}

	/**
	 * REST routes.
	 */
	public static function register_routes() {
		$post_arg = array(
			'post' => array(
				'type'     => 'integer',
				'required' => true,
			),
		);

		register_rest_route(
			'wi/v1',
			'/deploy',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_deploy' ),
				'permission_callback' => array( __CLASS__, 'can_deploy' ),
				'args'                => $post_arg + array(
					'key' => array( 'type' => 'string' ),
				),
			)
		);

		register_rest_route(
			'wi/v1',
			'/rollback',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_rollback' ),
				'permission_callback' => array( __CLASS__, 'can_deploy' ),
				'args'                => $post_arg,
			)
		);
	}

	/**
	 * Permission: the dedicated deploy capability plus edit rights on
	 * the target post.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool
	 */
	public static function can_deploy( $request ) {
		return current_user_can( 'wi_deploy' )
			&& current_user_can( 'edit_post', (int) $request['post'] );
	}

	/**
	 * Verify the typed deploy key: hashed at rest, rate-limited on
	 * failure (per user, sliding 10-minute window).
	 *
	 * @param string $key Submitted key.
	 * @return true|WP_Error
	 */
	private static function verify_key( $key ) {
		$hash = get_option( self::KEY_OPTION, '' );
		if ( '' === $hash ) {
			return new WP_Error(
				'wi_no_deploy_key',
				__( 'No deploy key is set. Add one under Settings → WeIdea Studio first.', 'weidea-studio' ),
				array( 'status' => 409 )
			);
		}

		$fails_key = 'wi_deploy_fails_' . get_current_user_id();
		$fails     = (int) get_transient( $fails_key );
		if ( $fails >= self::MAX_FAILS ) {
			return new WP_Error(
				'wi_deploy_locked',
				__( 'Too many failed attempts — deploys locked for 10 minutes.', 'weidea-studio' ),
				array( 'status' => 429 )
			);
		}

		if ( ! is_string( $key ) || '' === $key || ! wp_check_password( $key, $hash ) ) {
			set_transient( $fails_key, $fails + 1, 10 * MINUTE_IN_SECONDS );
			return new WP_Error(
				'wi_bad_deploy_key',
				__( 'That deploy key is not right.', 'weidea-studio' ),
				array( 'status' => 403 )
			);
		}

		delete_transient( $fails_key );
		return true;
	}

	/**
	 * Deploy: snapshot live as a tagged revision, copy staged over live,
	 * retire the staged copy, purge caches, log.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function rest_deploy( $request ) {
		$verified = self::verify_key( (string) $request['key'] );
		if ( is_wp_error( $verified ) ) {
			return $verified;
		}

		$post = get_post( (int) $request['post'] );
		if ( ! $post ) {
			return new WP_Error( 'wi_no_post', __( 'Post not found.', 'weidea-studio' ), array( 'status' => 404 ) );
		}
		$staged_id = WI_Staging::staged_id( $post->ID );
		if ( ! $staged_id ) {
			return new WP_Error( 'wi_no_staged', __( 'Nothing is staged for this page.', 'weidea-studio' ), array( 'status' => 409 ) );
		}
		$staged = get_post( $staged_id );

		// The way back: snapshot the CURRENT live content as a revision
		// before overwriting, and remember which one it was.
		$revision_id = (int) wp_save_post_revision( $post->ID );

		$updated = wp_update_post(
			array(
				'ID'           => $post->ID,
				'post_title'   => $staged->post_title,
				'post_content' => $staged->post_content,
			),
			true
		);
		if ( is_wp_error( $updated ) ) {
			return $updated;
		}

		wp_delete_post( $staged_id, true );
		self::purge_cache();
		self::log(
			array(
				'action'      => 'deploy',
				'post'        => $post->ID,
				'revision_id' => $revision_id,
			)
		);

		return rest_ensure_response(
			array(
				'deployed'    => true,
				'post'        => $post->ID,
				'revision_id' => $revision_id,
			)
		);
	}

	/**
	 * Rollback: restore the revision tagged by the last deploy of this
	 * post. Same ceremony philosophy — one click back.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function rest_rollback( $request ) {
		$post_id = (int) $request['post'];
		$entry   = null;
		foreach ( (array) get_option( self::LOG_OPTION, array() ) as $candidate ) {
			if ( 'deploy' === $candidate['action'] && (int) $candidate['post'] === $post_id ) {
				$entry = $candidate;
				break;
			}
		}
		if ( ! $entry || empty( $entry['revision_id'] ) ) {
			return new WP_Error( 'wi_no_rollback', __( 'No deploy to roll back for this page.', 'weidea-studio' ), array( 'status' => 409 ) );
		}

		$restored = wp_restore_post_revision( (int) $entry['revision_id'] );
		if ( ! $restored ) {
			return new WP_Error( 'wi_rollback_failed', __( 'The rollback point could not be restored.', 'weidea-studio' ), array( 'status' => 500 ) );
		}

		self::purge_cache();
		self::log(
			array(
				'action'      => 'rollback',
				'post'        => $post_id,
				'revision_id' => (int) $entry['revision_id'],
			)
		);

		return rest_ensure_response(
			array(
				'rolled_back' => true,
				'post'        => $post_id,
			)
		);
	}

	/**
	 * Purge SiteGround's cache when its plugin is present — the #1
	 * gotcha from the pilot's build guide, closed at the source.
	 */
	private static function purge_cache() {
		if ( function_exists( 'sg_cachepress_purge_cache' ) ) {
			sg_cachepress_purge_cache();
		}

		/**
		 * Fires after a deploy or rollback so other cache layers can purge.
		 */
		do_action( 'wi_after_deploy_purge' );
	}

	/**
	 * Append a who/when/what entry to the audit log (newest first).
	 *
	 * @param array $entry Entry fields.
	 */
	private static function log( $entry ) {
		$log = (array) get_option( self::LOG_OPTION, array() );
		array_unshift(
			$log,
			$entry + array(
				'user' => get_current_user_id(),
				'time' => time(),
			)
		);
		update_option( self::LOG_OPTION, array_slice( $log, 0, self::MAX_LOG ), false );
	}
}
