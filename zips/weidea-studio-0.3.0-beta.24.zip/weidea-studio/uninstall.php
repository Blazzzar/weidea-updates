<?php
/**
 * Uninstall cleanup.
 *
 * POLICY: removing the plugin removes the plugin's OWN data — options,
 * transients, credentials, and everything under uploads/weidea/ — and
 * NEVER touches content. Posts keep rendering (standard block markup),
 * staged drafts stay where they are, revisions and deploy history in
 * post meta remain. That is the single-maintainer safety net from the
 * plan: content survives the tool.
 *
 * Form entries are the plugin's record of what visitors sent, not the
 * site's pages, so they go with it (ruled Q1b, Chris, October 19 2026):
 * once the plugin is gone no screen can list them, and WordPress's export
 * and erase tools no longer reach them.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Plugin options and transients.
delete_option( 'wi_breakpoints' );
delete_option( 'wi_update_channel' );
delete_option( 'wi_deploy_key_hash' );
delete_option( 'wi_deploy_log' );
delete_option( 'wi_safe_mode' );
delete_site_transient( 'wi_update_manifest' );
delete_site_transient( 'wi_rollback_target' );

// Per-user WebAuthn deploy credentials (plugin data, not content).
delete_metadata( 'user', 0, 'wi_webauthn_credentials', '', true );

// Form entries (ruled Q1b): every wi_form_entry post and its meta, deleted
// outright. The post type is not registered while this file runs — WordPress
// loads uninstall.php alone — so the statuses are listed rather than 'any'
// (which skips statuses it cannot see), and the type is a string literal.
// The daily retention event goes with them. The ten-minute rate-limit and
// duplicate-guard transients are left to expire, as the deploy lockout's are.
do {
	$wi_entries = get_posts(
		array(
			'post_type'        => 'wi_form_entry',
			'post_status'      => array( 'private', 'publish', 'draft', 'pending', 'future', 'trash' ),
			'fields'           => 'ids',
			'numberposts'      => 200,
			'suppress_filters' => true,
		)
	);
	foreach ( $wi_entries as $wi_entry ) {
		wp_delete_post( $wi_entry, true );
	}
} while ( count( $wi_entries ) === 200 );
wp_clear_scheduled_hook( 'wi_form_entries_sweep' );

// Generated assets: the namespaced uploads/weidea/ tree, and nothing
// else — the path is re-derived and checked so this can never walk
// outside the plugin's own directory.
$wi_uploads = wp_upload_dir();
$wi_dir     = trailingslashit( $wi_uploads['basedir'] ) . 'weidea';
if ( is_dir( $wi_dir ) && false === strpos( $wi_dir, '..' ) ) {
	$wi_iterator = new RecursiveIteratorIterator(
		new RecursiveDirectoryIterator( $wi_dir, FilesystemIterator::SKIP_DOTS ),
		RecursiveIteratorIterator::CHILD_FIRST
	);
	foreach ( $wi_iterator as $wi_item ) {
		if ( $wi_item->isDir() ) {
			rmdir( $wi_item->getPathname() ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		} else {
			unlink( $wi_item->getPathname() ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
	}
	rmdir( $wi_dir ); // phpcs:ignore WordPress.WP.AlternativeFunctions
}
