<?php
/**
 * The Form block — the server half (design docs/weidea-studio-form-block-design.md,
 * ruled by Chris on October 19 2026: all twelve questions as recommended).
 *
 * The library's first block drawn by the server, first public endpoint, first
 * thing that sends email, first thing that stores what a visitor typed. One
 * class, because those are one pipeline:
 *
 *   draw()    — every state a visitor can see: fresh, with mistakes, the
 *               rate-limit and refreshed lines, sent, gone, preview. There is
 *               ONE renderer; the REST road and the plain-POST road both call
 *               it, so the two can never disagree about a word (ruled Q3).
 *   handle()  — the one pipeline both doors call (§4.1): rate limit, form
 *               lookup in STORED content, signed token, publish/copy check,
 *               spam set, validation, duplicate guard, entry, email, webhook,
 *               count. Nothing about the form's shape is trusted from the
 *               request.
 *   entries   — the wi_form_entry post type under Settings → Form entries,
 *               its retention event, and WordPress's own export and erase
 *               tools (ruled Q1, Q1b).
 *
 * Hard lines from the rulings, said once:
 *  · a preview token (the signed link, a copy's draft preview, any page that
 *    is not published) sends, stores and calls NOTHING;
 *  · no From header is ever set — the visitor's address goes in Reply-To,
 *    alone, and only after is_email() passed;
 *  · the webhook uses wp_safe_remote_post(), follows no redirects, and its
 *    failure is never shown to the visitor;
 *  · entries are deleted when the plugin is deleted (uninstall.php).
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Form rendering, submission handling, entries.
 */
final class WI_Form {

	/** The entries post type. */
	const POST_TYPE = 'wi_form_entry';

	/** The daily retention event. */
	const SWEEP_HOOK = 'wi_form_entries_sweep';

	/** REST namespace and route for the script's door. */
	const REST_NS    = 'wi/v1';
	const REST_ROUTE = '/form/submit';

	/**
	 * Minimum seconds between the form being drawn and being sent (§6.2).
	 * There is deliberately no maximum: a page can sit in SiteGround's cache
	 * for twelve hours, and a token that expired would refuse honest visitors.
	 */
	const MIN_AGE = 2;

	/** Five accepted messages per ten minutes per form and address (§6.3). */
	const RATE_MAX    = 5;
	const RATE_WINDOW = 600;

	/** The duplicate guard's memory (§4.1 step 6). */
	const DUP_TTL = 600;

	/** Retention, in days, when a form says nothing (ruled Q1: 90 to start). */
	const KEEP_DAYS_DEFAULT = 90;

	/** Server-side length limits (§3). */
	const MAX_TEXT     = 200;
	const MAX_EMAIL    = 254;
	const MAX_TEXTAREA = 5000;
	const PHONE_MIN    = 6;
	const PHONE_MAX    = 30;

	/**
	 * The six kinds (ruled Q9), and the name each one stands under when its
	 * label is empty — the JS mirror is src/blocks/form-field/kinds.js. A
	 * field with no label is still drawn, checked, emailed, stored and posted
	 * under this name, everywhere, through label_of() (design §3).
	 *
	 * @return array<string,string> kind → name.
	 */
	public static function kinds() {
		return array(
			'text'     => __( 'Single-line text', 'weidea-studio' ),
			'email'    => __( 'Email', 'weidea-studio' ),
			'phone'    => __( 'Phone', 'weidea-studio' ),
			'textarea' => __( 'Multi-line text', 'weidea-studio' ),
			'select'   => __( 'Choice list', 'weidea-studio' ),
			'checkbox' => __( 'Checkbox', 'weidea-studio' ),
		);
	}

	/**
	 * States handed from the plain-POST door (template_redirect) to the
	 * render callback in the same request, keyed "<post>|<uid>".
	 *
	 * @var array
	 */
	private static $posted = array();

	/**
	 * How many times each form uid has been drawn this request — a synced
	 * pattern can put one form on a page twice, and the second copy's ids
	 * must not repeat the first's (audit, Oct 19).
	 *
	 * @var array<string,int>
	 */
	private static $drawn = array();

	/**
	 * find_form() answers already given this request, keyed "<post>|<uid>".
	 *
	 * @var array
	 */
	private static $found = array();

	/**
	 * Hook registration.
	 */
	public static function init() {
		add_filter( 'block_type_metadata_settings', array( __CLASS__, 'attach_render' ), 10, 2 );
		add_filter( 'allowed_block_types_all', array( __CLASS__, 'only_in_content' ), 10, 2 );
		add_filter( 'pre_render_block', array( __CLASS__, 'only_where_found' ), 10, 2 );
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		// Before core's redirects (priority 10) and after maybe_preview()
		// (the `wp` action), so a plain POST to a signed preview link already
		// knows which copy is on screen.
		add_action( 'template_redirect', array( __CLASS__, 'maybe_handle_post' ), 5 );

		add_action( 'init', array( __CLASS__, 'register_entries' ) );
		add_action( 'init', array( __CLASS__, 'schedule_sweep' ), 20 );
		add_action( self::SWEEP_HOOK, array( __CLASS__, 'sweep' ) );
		add_filter( 'wp_privacy_personal_data_exporters', array( __CLASS__, 'register_exporter' ) );
		add_filter( 'wp_privacy_personal_data_erasers', array( __CLASS__, 'register_eraser' ) );

		if ( is_admin() ) {
			add_filter( 'manage_' . self::POST_TYPE . '_posts_columns', array( __CLASS__, 'list_columns' ) );
			add_action( 'manage_' . self::POST_TYPE . '_posts_custom_column', array( __CLASS__, 'list_cell' ), 10, 2 );
			add_filter( 'list_table_primary_column', array( __CLASS__, 'list_primary_column' ), 10, 2 );
			add_filter( 'post_row_actions', array( __CLASS__, 'row_actions' ), 10, 2 );
			add_filter( 'bulk_actions-edit-' . self::POST_TYPE, array( __CLASS__, 'bulk_actions' ) );
			add_action( 'restrict_manage_posts', array( __CLASS__, 'list_filters' ) );
			add_action( 'pre_get_posts', array( __CLASS__, 'apply_list_filters' ) );
			add_action( 'add_meta_boxes_' . self::POST_TYPE, array( __CLASS__, 'entry_meta_boxes' ) );
			add_filter( 'views_edit-' . self::POST_TYPE, array( __CLASS__, 'list_retention_note' ) );
		}
	}

	/**
	 * Give weidea/form its render callback at registration. Kept here rather
	 * than in WI_Blocks so everything the Form does on the server lives in
	 * one file.
	 *
	 * @param array $settings Block type settings.
	 * @param array $metadata block.json metadata.
	 * @return array
	 */
	public static function attach_render( $settings, $metadata ) {
		if ( isset( $metadata['name'] ) && 'weidea/form' === $metadata['name'] ) {
			$settings['render_callback'] = array( __CLASS__, 'render' );
		}
		return $settings;
	}

	/**
	 * Offer the Form only where its form can be found.
	 *
	 * handle() reads a form from the STORED content of the post it was drawn
	 * on (§4.1 step 1; ruled Q10, the form lives inside the page). A Form in a
	 * block theme's template part or in a widget area is drawn on every page
	 * and stored in none of them, so every Send would come back "This form is
	 * no longer available". The Site Editor and both widget screens therefore
	 * do not offer it; the page and post editor do.
	 *
	 * @param bool|string[]           $allowed Allowed block types, or true.
	 * @param WP_Block_Editor_Context $context The editor screen.
	 * @return bool|string[]
	 */
	public static function only_in_content( $allowed, $context ) {
		$name = is_object( $context ) && isset( $context->name ) ? $context->name : '';
		if ( ! in_array( $name, array( 'core/edit-site', 'core/edit-widgets', 'core/customize-widgets' ), true ) || false === $allowed ) {
			return $allowed;
		}
		if ( true === $allowed ) {
			$allowed = array_keys( WP_Block_Type_Registry::get_instance()->get_all_registered() );
		}
		return array_values( array_diff( (array) $allowed, array( 'weidea/form', 'weidea/form-field' ) ) );
	}

	/**
	 * Draw a Form only where Send can find it (audit, Oct 19).
	 *
	 * handle() looks a form up in the stored content of the post it was drawn
	 * on. A Form inside a synced pattern placed in a block theme's footer, a
	 * widget area or after the loop is drawn on pages that do not hold it, so
	 * every Send from it would answer "This form is no longer available" and
	 * the visitor's message would be lost. Such a Form is not drawn at all —
	 * the same answer a Form with no fields gets (§2.3) — and because this
	 * runs before the block renders, its stylesheet and script are not loaded
	 * for nothing either. A form in a footer is a later addition (#94 notes).
	 *
	 * @param string|null $pre    Short-circuit value.
	 * @param array       $parsed Parsed block.
	 * @return string|null
	 */
	public static function only_where_found( $pre, $parsed ) {
		if ( null !== $pre || ! isset( $parsed['blockName'] ) || 'weidea/form' !== $parsed['blockName'] ) {
			return $pre;
		}
		$form = self::normalize_form( $parsed );
		if ( ! $form['fields'] ) {
			return ''; // A Form with every field deleted is not drawn at all (§2.3).
		}
		list( $post_id ) = self::render_surface();
		return self::find_form( $post_id, $form['uid'] ) ? $pre : '';
	}

	/* ===================================================================
	 * The form's shape — read from STORED content, never from a request.
	 * =================================================================== */

	/**
	 * The uid a block's CSS is scoped to — WI_Assets' derivation, called
	 * rather than copied, so the class this file writes is the class the
	 * instance CSS was collected under.
	 *
	 * @param string $name  Block name.
	 * @param array  $attrs The block's PARSED attributes (not defaults-filled:
	 *                      the derivation hashes exactly what was saved).
	 * @return string
	 */
	private static function uid_of( $name, $attrs ) {
		return WI_Assets::resolve_uid( $name, is_array( $attrs ) ? $attrs : array(), null );
	}

	/**
	 * A parsed weidea/form block, normalised: its uid, its attributes with
	 * defaults filled, and its fields in order.
	 *
	 * @param array $parsed Parsed block (parse_blocks() shape).
	 * @return array
	 */
	public static function normalize_form( $parsed ) {
		$raw   = isset( $parsed['attrs'] ) && is_array( $parsed['attrs'] ) ? $parsed['attrs'] : array();
		// Words come out of stored content as the words a visitor sees.
		// WordPress's tag filter stores an Author's "&" as "&amp;" in block
		// settings (an Administrator's is stored as typed), and the server
		// compares, emails and keeps plain text — so every word is decoded
		// here, once, and escaped again only where it is written into HTML
		// (audit, Oct 19: "Food & Drink" could never be sent). The raw
		// arrays still go to uid_of(): a uid is a hash of what was SAVED.
		$dec   = function ( $value ) {
			return html_entity_decode( (string) $value, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		};
		$attrs = wp_parse_args(
			$raw,
			array(
				'formName'     => '',
				'to'           => '',
				'subject'      => '',
				'keepFor'      => '',
				'successTitle' => '',
				'successBody'  => '',
				'buttonLabel'  => '',
				'webhookUrl'   => '',
				'className'    => '',
				'anchor'       => '',
			)
		);
		foreach ( array( 'formName', 'to', 'subject', 'successTitle', 'successBody', 'webhookUrl' ) as $word ) {
			$attrs[ $word ] = $dec( $attrs[ $word ] );
		}

		$kinds  = self::kinds();
		$fields = array();
		$taken  = array();
		$inner  = isset( $parsed['innerBlocks'] ) && is_array( $parsed['innerBlocks'] ) ? $parsed['innerBlocks'] : array();
		foreach ( $inner as $child ) {
			if ( ! isset( $child['blockName'] ) || 'weidea/form-field' !== $child['blockName'] ) {
				continue;
			}
			$c    = isset( $child['attrs'] ) && is_array( $child['attrs'] ) ? $child['attrs'] : array();
			$kind = isset( $c['fieldType'] ) && isset( $kinds[ $c['fieldType'] ] ) ? $c['fieldType'] : 'text';
			$typed_label = isset( $c['label'] ) ? trim( $dec( $c['label'] ) ) : '';
			$label       = '' !== $typed_label ? $typed_label : $kinds[ $kind ];

			// The name a value travels under: "Name in the webhook" when set,
			// else made from the label (design §3) — "Your email" → your-email.
			$from = isset( $c['key'] ) && '' !== trim( (string) $c['key'] ) ? $dec( $c['key'] ) : $label;
			$key  = sanitize_key( sanitize_title( $from ) );
			if ( '' === $key ) {
				$key = $kind;
			}
			$base = $key;
			for ( $n = 2; isset( $taken[ $key ] ); $n++ ) {
				$key = $base . '-' . $n;
			}
			$taken[ $key ] = true;

			$choices = array();
			if ( 'select' === $kind && isset( $c['options'] ) ) {
				foreach ( preg_split( '/\r\n|\r|\n/', $dec( $c['options'] ) ) as $line ) {
					$line = trim( $line );
					if ( '' !== $line && ! in_array( $line, $choices, true ) ) {
						$choices[] = $line;
					}
				}
			}

			$fields[] = array(
				'uid'         => self::uid_of( 'weidea/form-field', $c ),
				'kind'        => $kind,
				'label'       => $label,
				'key'         => $key,
				'name'        => 'f_' . $key,
				'required'    => ! empty( $c['required'] ),
				'placeholder' => isset( $c['placeholder'] ) ? $dec( $c['placeholder'] ) : '',
				'help'        => isset( $c['helpText'] ) ? $dec( $c['helpText'] ) : '',
				'choices'     => $choices,
				'parsed'      => $child,
			);
		}

		return array(
			'uid'    => self::uid_of( 'weidea/form', $raw ),
			'attrs'  => $attrs,
			'fields' => $fields,
		);
	}

	/**
	 * Find a form by uid in a post's STORED content — following synced
	 * patterns, because reuse across pages is a synced pattern (ruled Q10).
	 *
	 * @param int    $post_id Post whose content was drawn.
	 * @param string $uid     The form's uid.
	 * @return array|null Normalised form, or null when it is not there.
	 */
	public static function find_form( $post_id, $uid ) {
		$key = (int) $post_id . '|' . $uid;
		if ( array_key_exists( $key, self::$found ) ) {
			return self::$found[ $key ];
		}
		$post = get_post( (int) $post_id );
		if ( ! $post || '' === $uid ) {
			return null;
		}
		self::$found[ $key ] = self::search_blocks( parse_blocks( (string) $post->post_content ), $uid, 0, array() );
		return self::$found[ $key ];
	}

	/**
	 * Depth-first search for a weidea/form with this uid.
	 *
	 * @param array  $blocks Parsed blocks.
	 * @param string $uid    Wanted uid.
	 * @param int    $depth  Synced-pattern depth so far.
	 * @param array  $seen   Pattern ids already opened (cycle guard).
	 * @return array|null
	 */
	private static function search_blocks( $blocks, $uid, $depth, $seen ) {
		foreach ( (array) $blocks as $block ) {
			$name = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
			if ( 'weidea/form' === $name ) {
				$form = self::normalize_form( $block );
				if ( $form['uid'] === $uid ) {
					return $form;
				}
				continue;
			}
			if ( 'core/block' === $name && ! empty( $block['attrs']['ref'] ) && $depth < 3 ) {
				$ref = (int) $block['attrs']['ref'];
				if ( ! isset( $seen[ $ref ] ) ) {
					$pattern = get_post( $ref );
					if ( $pattern && 'wp_block' === $pattern->post_type && 'publish' === $pattern->post_status ) {
						$seen[ $ref ] = true;
						$hit          = self::search_blocks( parse_blocks( (string) $pattern->post_content ), $uid, $depth + 1, $seen );
						if ( $hit ) {
							return $hit;
						}
					}
				}
			}
			if ( ! empty( $block['innerBlocks'] ) ) {
				$hit = self::search_blocks( $block['innerBlocks'], $uid, $depth, $seen );
				if ( $hit ) {
					return $hit;
				}
			}
		}
		return null;
	}

	/**
	 * Whether a form has an email field (decides the default second line of
	 * the sent box, design §8.3).
	 *
	 * @param array $form Normalised form.
	 * @return bool
	 */
	private static function has_email_field( $form ) {
		foreach ( $form['fields'] as $field ) {
			if ( 'email' === $field['kind'] ) {
				return true;
			}
		}
		return false;
	}

	/* ===================================================================
	 * Surfaces, tokens, addresses.
	 * =================================================================== */

	/**
	 * The post whose content is being drawn, and whether this render is live
	 * or a preview (design §2.6 rule 2, §12.2).
	 *
	 * @return array{0:int,1:string} [ post id, 'live'|'preview' ].
	 */
	private static function render_surface() {
		$staged = WI_Staging::is_preview_request();
		if ( $staged ) {
			return array( (int) $staged, 'preview' );
		}
		$id   = (int) get_the_ID();
		$post = $id ? get_post( $id ) : null;
		if ( ! $post ) {
			return array( 0, 'live' );
		}
		// WordPress's own Preview, opened by someone who can edit the page:
		// of a draft, or of a PUBLISHED page with unsaved changes. For the
		// second, core draws the newest autosave's content under the published
		// page's id and status (_set_preview(), active only on the
		// preview_id/nonce road), so the form names that autosave — the
		// content that was drawn (§2.6 rule 2) — and is a preview: nothing is
		// sent, stored or called (ruled Q8). Found by the audit (Oct 19): it
		// was drawn as live, and a press mailed the PUBLISHED recipient.
		if ( is_preview() && current_user_can( 'edit_post', $id ) ) {
			if ( has_filter( 'the_preview', '_set_preview' ) ) {
				$autosave = wp_get_post_autosave( $id );
				if ( $autosave ) {
					return array( (int) $autosave->ID, 'preview' );
				}
			}
			return array( $id, 'preview' );
		}
		$live = 'publish' === $post->post_status && ! WI_Staging::is_staged_copy( $id );
		return array( $id, $live ? 'live' : 'preview' );
	}

	/**
	 * The signed token: binds a submission to this post, this form, this
	 * issue time and this surface — the house pattern from
	 * WI_Staging::preview_token(), compared with hash_equals().
	 *
	 * A form redrawn as "refreshed" carries one more signed word, "again":
	 * a press of it inside the two seconds is drawn once more rather than
	 * treated as a program (audit, Oct 19). Every other token signs exactly
	 * what it always did, so pages already in a cache keep working.
	 *
	 * @param int    $post_id Post id.
	 * @param string $uid     Form uid.
	 * @param int    $issued  Unix time the form was drawn.
	 * @param string $surface 'live' or 'preview'.
	 * @param bool   $again   Drawn as the refreshed state.
	 * @return string 32 hex characters.
	 */
	public static function token( $post_id, $uid, $issued, $surface, $again = false ) {
		return substr( hash_hmac( 'sha256', 'wi-form|' . (int) $post_id . '|' . $uid . '|' . (int) $issued . '|' . $surface . ( $again ? '|again' : '' ), wp_salt( 'auth' ) ), 0, 32 );
	}

	/**
	 * The visitor's address, hashed with a salt and never stored raw.
	 * REMOTE_ADDR only: a forwarded header is something a visitor can write
	 * (§6.3; probe P11 decides whether the key ever moves).
	 *
	 * @return string
	 */
	private static function address_hash() {
		$addr = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		return hash( 'sha256', $addr . wp_salt( 'nonce' ) );
	}

	/**
	 * The address a plain POST from this form goes to — the page the form
	 * was drawn on, or the signed link that shows the copy (design §2.6
	 * rule 2: without the `wi-preview` query a POST would be answered by the
	 * live page, which does not have the copy's form).
	 *
	 * On a post split into pages the address is the page that holds the
	 * form, worked out from the STORED content — so the first draw, the REST
	 * redraw and the plain post all agree, and nothing is read from the
	 * request (audit, Oct 19: a form on page 2 posted back to page 1, which
	 * does not draw it, and the visitor saw no answer at all).
	 *
	 * @param int    $post_id Post whose content was drawn.
	 * @param string $surface 'live' or 'preview'.
	 * @param string $uid     Form uid.
	 * @return string
	 */
	private static function action_for( $post_id, $surface, $uid ) {
		$post = get_post( $post_id );
		$link = '';
		if ( 'preview' === $surface && WI_Staging::is_staged_copy( $post_id ) ) {
			$live = (int) get_post_meta( $post_id, WI_Staging::META_KEY, true );
			if ( $live && WI_Staging::staged_id( $live ) === (int) $post_id ) {
				$link = WI_Staging::preview_url( $live, $post_id );
			}
		}
		if ( '' === $link && 'preview' === $surface && $post && 'revision' === $post->post_type ) {
			// WordPress's own Preview of a published page: the autosave's
			// parent, on the same preview road the editor's button uses.
			$parent = (int) $post->post_parent;
			$args   = array();
			if ( current_user_can( 'edit_post', $parent ) ) {
				$args = array(
					'preview_id'    => $parent,
					'preview_nonce' => wp_create_nonce( 'post_preview_' . $parent ),
				);
			}
			$link = (string) get_preview_post_link( $parent, $args );
		}
		if ( '' === $link && 'preview' === $surface ) {
			$link = (string) get_preview_post_link( $post_id );
		}
		if ( '' === $link ) {
			$link = (string) get_permalink( $post_id );
		}
		if ( '' === $link ) {
			return home_url( '/' );
		}
		$page = self::page_of( $post, $uid );
		if ( $page > 1 ) {
			if ( false !== strpos( $link, '?' ) || '' === get_option( 'permalink_structure' ) ) {
				$link = add_query_arg( 'page', $page, $link );
			} else {
				$link = trailingslashit( $link ) . user_trailingslashit( (string) $page, 'single_paged' );
			}
		}
		return $link;
	}

	/**
	 * Which page of a post split with "Page break" holds the form, from the
	 * stored content; 1 when the post is not split.
	 *
	 * @param WP_Post|null $post Post.
	 * @param string       $uid  Form uid.
	 * @return int
	 */
	private static function page_of( $post, $uid ) {
		if ( ! $post || false === strpos( (string) $post->post_content, '<!--nextpage-->' ) ) {
			return 1;
		}
		$data = ( new WP_Query() )->generate_postdata( $post );
		foreach ( (array) ( isset( $data['pages'] ) ? $data['pages'] : array() ) as $i => $part ) {
			if ( self::search_blocks( parse_blocks( $part ), $uid, 0, array() ) ) {
				return $i + 1;
			}
		}
		return 1;
	}

	/* ===================================================================
	 * The doors.
	 * =================================================================== */

	/**
	 * The script's door: POST /wi/v1/form/submit, open to everyone. Every
	 * state comes back as 200 with { html } — so an answer without an html
	 * string is never this handler's (a security plugin, a challenge page),
	 * and the script hands the Send to the browser as a plain page post.
	 * No `args` declared on purpose: core's argument check would answer 400
	 * with no html, and the gone state would never be drawn.
	 */
	public static function register_routes() {
		register_rest_route(
			self::REST_NS,
			self::REST_ROUTE,
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_submit' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	/**
	 * Handle the script's POST and answer with the freshly drawn fragment.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function rest_submit( $request ) {
		$state    = self::handle( (array) $request->get_body_params() );
		$response = rest_ensure_response( array( 'html' => self::draw_state( $state, true ) ) );
		$response->header( 'Cache-Control', 'no-cache, must-revalidate, max-age=0, no-store, private' );
		return $response;
	}

	/**
	 * The plain-POST door: a POST to the page the form was drawn on (no
	 * JavaScript, safe mode, or the script's fallback). Handles the
	 * submission, keeps the state for the render callback, and lets the page
	 * render normally — no redirect, so no `?sent` address exists for a cache
	 * to freeze (§4.1 door 2, §1.5).
	 */
	public static function maybe_handle_post() {
		if ( ! isset( $_SERVER['REQUEST_METHOD'] ) || 'POST' !== $_SERVER['REQUEST_METHOD'] || ! isset( $_POST['wi_form'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- a public form has no nonce by design (§4.1: a nonce baked into a cached page goes stale); the signed token is the check.
			return;
		}
		$state = self::handle( wp_unslash( $_POST ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- every value is cleaned field by field in handle().
		self::$posted[ $state['post_id'] . '|' . $state['uid'] . '|' . $state['n'] ] = $state;
		nocache_headers();
	}

	/**
	 * The render callback: draw this form, in the state the plain-POST door
	 * left for it this request, or fresh.
	 *
	 * @param array    $attributes Attributes (defaults filled).
	 * @param string   $content    Rendered children — ignored: the fields are
	 *                             drawn from their settings, below.
	 * @param WP_Block $block      The block, whose parsed_block carries each
	 *                             field's saved settings.
	 * @return string
	 */
	public static function render( $attributes, $content, $block ) {
		$form = self::normalize_form( $block->parsed_block );
		if ( ! $form['fields'] ) {
			// A Form with every field deleted is not drawn at all (§2.3).
			return '';
		}
		list( $post_id, $surface ) = self::render_surface();
		$uid                 = $form['uid'];
		self::$drawn[ $uid ] = isset( self::$drawn[ $uid ] ) ? self::$drawn[ $uid ] + 1 : 1;
		$n                   = self::$drawn[ $uid ];
		$key                 = $post_id . '|' . $uid . '|' . $n;
		$state               = isset( self::$posted[ $key ] ) ? self::$posted[ $key ] : null;
		if ( ! $state ) {
			$state = array(
				'state'   => 'fresh',
				'form'    => $form,
				'post_id' => $post_id,
				'uid'     => $uid,
				'surface' => $surface,
				'values'  => array(),
				'errors'  => array(),
				'n'       => $n,
			);
		}
		// The page's content filters run AFTER blocks render. Typography
		// (wptexturize) is told to leave the form alone, so what is drawn here
		// is what the REST road swaps in, word for word (audit, Oct 19: a
		// visitor's "--" came back as a dash on the plain road only). The
		// visitor's own words are also made inert to shortcodes and to the
		// brand-name "correction" in draw_field().
		if ( ! has_filter( 'no_texturize_tags', array( __CLASS__, 'no_texturize_form' ) ) ) {
			add_filter( 'no_texturize_tags', array( __CLASS__, 'no_texturize_form' ) );
		}
		return self::draw_state( $state, false );
	}

	/**
	 * Add `form` to the elements WordPress's typography pass leaves alone.
	 *
	 * @param string[] $tags Element names.
	 * @return string[]
	 */
	public static function no_texturize_form( $tags ) {
		$tags[] = 'form';
		return $tags;
	}

	/* ===================================================================
	 * The pipeline (§4.1). Returns a STATE; draw_state() draws it.
	 * =================================================================== */

	/**
	 * Handle one submission. The order is the design's, step by step.
	 *
	 * @param array $input Unslashed request values.
	 * @return array State: state, form, post_id, uid, surface, values, errors.
	 */
	public static function handle( $input ) {
		$input   = is_array( $input ) ? $input : array();
		$post_id = isset( $input['wi_post'] ) ? absint( $input['wi_post'] ) : 0;
		$uid     = isset( $input['wi_form'] ) && is_scalar( $input['wi_form'] ) ? preg_replace( '/[^a-zA-Z0-9_-]/', '', (string) $input['wi_form'] ) : '';
		$issued  = isset( $input['wi_issued'] ) && is_scalar( $input['wi_issued'] ) ? (int) $input['wi_issued'] : 0;
		$surface = isset( $input['wi_surface'] ) && 'preview' === $input['wi_surface'] ? 'preview' : 'live';
		$token   = isset( $input['wi_token'] ) && is_scalar( $input['wi_token'] ) ? (string) $input['wi_token'] : '';
		$again   = ! empty( $input['wi_again'] );
		$addr    = self::address_hash();

		$state = array(
			'state'   => 'gone',
			'form'    => null,
			'post_id' => $post_id,
			'uid'     => $uid,
			'surface' => $surface,
			'values'  => array(),
			'errors'  => array(),
			// Which copy of this form on the page was sent (a synced pattern
			// can place it twice). Cosmetic: it only numbers the ids drawn.
			'n'       => isset( $input['wi_n'] ) && is_scalar( $input['wi_n'] ) ? max( 1, min( 50, (int) $input['wi_n'] ) ) : 1,
		);

		// 0. The rate limit, read first (§4.1 step 0). Its answer is drawn
		// only after the token below has passed: the waiting sentence sits
		// inside the visitor's own form, and only a valid token says the
		// visitor was ever shown that form.
		$over = self::rate_count( $post_id, $uid, $addr ) >= self::RATE_MAX;

		// 1. The form, from the STORED content of the post that was drawn.
		$form = self::find_form( $post_id, $uid );
		if ( ! $form || ! $form['fields'] ) {
			return $state; // gone.
		}

		// 2. The token. A failure is not a refusal but the refreshed state:
		// the form comes back with the typed values and a fresh token, and one
		// more press sends it (R-L — rotated security keys must not leave
		// twelve hours of dead forms in a cache). Only for a page anyone may
		// read: without a valid token nothing says this visitor was shown the
		// form, so a draft's or a private page's form is never drawn for them.
		if ( ! hash_equals( self::token( $post_id, $uid, $issued, $surface, $again ), $token ) ) {
			$post = get_post( $post_id );
			if ( ! $post || ! is_post_publicly_viewable( $post ) || post_password_required( $post ) || WI_Staging::is_staged_copy( $post_id ) ) {
				return $state; // gone.
			}
			$state['form']    = $form;
			$state['values']  = self::clean_values( $form, $input );
			$state['state']   = 'refreshed';
			$state['surface'] = 'live';
			$state['again']   = true;
			return $state;
		}
		$state['form']   = $form;
		$state['values'] = self::clean_values( $form, $input );
		// Every form drawn from here on carries THIS issue time, which the
		// token has just proved the server wrote: a visitor who fixes a mistake
		// and presses Send at once is not a program finishing in under two
		// seconds (audit, Oct 19 — the redraw used to restart the clock, and a
		// quick second press was dropped behind a "sent" box).
		$state['issued'] = $issued;

		if ( $over ) {
			$state['state'] = 'wait';
			return $state;
		}

		// 3. A live token must name a published page that is not a copy.
		if ( 'live' === $surface && 'live' !== self::surface_of_post( $post_id ) ) {
			$state['form']  = null;
			$state['state'] = 'gone';
			return $state;
		}

		// A refreshed form pressed inside its two seconds: the visitor was just
		// told to press Send again, so draw it once more rather than take the
		// press for a program's. Signed, so a program cannot claim it.
		if ( $again && time() - $issued < self::MIN_AGE ) {
			$state['state'] = 'refreshed';
			$state['again'] = true;
			unset( $state['issued'] );
			return $state;
		}

		// 4. Spam: never a message that says so — the sent box, nothing done.
		if ( self::looks_like_spam( $form, $state['values'], $input, $issued, $post_id ) ) {
			$state['state'] = 'preview' === $surface ? 'preview-sent' : 'sent';
			return $state;
		}

		// 5. Validation. Values were cleaned before anything saw them.
		$errors = self::validate( $form, $state['values'] );
		if ( $errors ) {
			$state['state']  = 'errors';
			$state['errors'] = $errors;
			return $state;
		}

		// A preview runs every check above and draws every state, and sends,
		// stores and calls NOTHING (ruled Q8; §12.3).
		if ( 'preview' === $surface ) {
			$state['state'] = 'preview-sent';
			return $state;
		}

		// 6. The duplicate guard — written HERE, before anything is sent,
		// stored or called. A heuristic, not a lock (R-K).
		$dup = self::duplicate_key( $form, $post_id, $state['values'], $addr );
		if ( $dup ) {
			if ( get_transient( $dup ) ) {
				$state['state'] = 'sent';
				return $state;
			}
			set_transient( $dup, 1, self::DUP_TTL );
		}

		// 7. The entry first, so a mail failure cannot lose the message.
		$entry_id = self::store_entry( $form, $post_id, $state['values'] );

		// 8. The email.
		$mail = self::send_email( $form, $post_id, $state['values'] );
		if ( $entry_id ) {
			update_post_meta( $entry_id, '_wi_entry_mail', wp_slash( $mail ) );
		}

		// 9. The webhook — its answer is the owner's, never the visitor's.
		$hook = self::call_webhook( $form, $post_id, $state['values'], $entry_id );
		if ( $entry_id ) {
			update_post_meta( $entry_id, '_wi_entry_webhook', wp_slash( $hook ) );
		}

		// 10. One accepted message against (form, address).
		self::rate_count_up( $post_id, $uid, $addr );
		$state['state'] = 'sent';
		return $state;
	}

	/**
	 * Whether a post is a live, published, non-copy page.
	 *
	 * @param int $post_id Post id.
	 * @return string 'live' or 'preview'.
	 */
	private static function surface_of_post( $post_id ) {
		$post = get_post( $post_id );
		return $post && 'publish' === $post->post_status && ! WI_Staging::is_staged_copy( $post_id ) ? 'live' : 'preview';
	}

	/**
	 * Every field's value, cleaned (§4.1 step 5). Cleaning is not escaping;
	 * draw_field() escapes what it writes back.
	 *
	 * @param array $form  Normalised form.
	 * @param array $input Unslashed request values.
	 * @return array<string,string> key → cleaned value ('1' / '' for a box).
	 */
	private static function clean_values( $form, $input ) {
		$values = array();
		foreach ( $form['fields'] as $field ) {
			$raw = isset( $input[ $field['name'] ] ) && is_scalar( $input[ $field['name'] ] ) ? (string) $input[ $field['name'] ] : '';
			if ( 'checkbox' === $field['kind'] ) {
				$values[ $field['key'] ] = '' !== $raw ? '1' : '';
			} elseif ( 'select' === $field['kind'] ) {
				// A choice is matched as the browser SENT it against the
				// authored choices, and kept as the authored words — cleaning
				// first would turn "< 10 people" into "&lt; 10 people" and a
				// double space into one, and the pick could never match
				// (audit, Oct 19). Anything not on the list is cleaned and
				// then fails validation.
				$sent                    = trim( $raw );
				$values[ $field['key'] ] = in_array( $sent, $field['choices'], true ) ? $sent : self::clean_text( $raw, false );
			} else {
				$values[ $field['key'] ] = self::clean_text( $raw, 'textarea' === $field['kind'] );
			}
		}
		return $values;
	}

	/**
	 * Clean typed text as PLAIN text (§4.1 step 5): invalid UTF-8 gone, tags
	 * stripped, line breaks kept only in a multi-line box. It is core's own
	 * sanitize_text_field() recipe less the two steps that are about HTML
	 * rather than text — so "I <3 the arcade" stays "<3" rather than
	 * "&lt;3" in the email, entry and webhook, and "code %AB12" keeps its
	 * "%AB" (audit, Oct 19). Cleaning is not escaping: every place this text
	 * is written into HTML escapes it there.
	 *
	 * @param string $raw       Typed value, unslashed.
	 * @param bool   $multiline Keep line breaks.
	 * @return string
	 */
	private static function clean_text( $raw, $multiline ) {
		$text = wp_check_invalid_utf8( (string) $raw );
		if ( false !== strpos( $text, '<' ) ) {
			// Core's wp_pre_kses_less_than() step, with a stand-in character
			// where it writes HTML codes: a "<" that does not open a tag is set
			// aside (PHP's strip_tags() would otherwise eat everything after
			// it), the tags are stripped, and the "<" comes back. A stand-in
			// the visitor typed is dropped first, so it cannot become a "<".
			$hold = "\xEE\x80\x80";
			$text = str_replace( $hold, '', $text );
			$text = preg_replace_callback(
				'%<[^>]*?((?=<)|>|$)%',
				function ( $m ) use ( $hold ) {
					return false === strpos( $m[0], '>' ) ? str_replace( '<', $hold, $m[0] ) : $m[0];
				},
				$text
			);
			$text = str_replace( $hold, '<', wp_strip_all_tags( $text, false ) );
		}
		if ( ! $multiline ) {
			$text = preg_replace( '/[\r\n\t ]+/', ' ', $text );
		}
		return trim( $text );
	}

	/**
	 * The spam set (§6): the honeypot, the two-second minimum, WordPress's
	 * own Disallowed Comment Keys, and a filter for a site's own rule.
	 *
	 * @param array $form    Normalised form.
	 * @param array $values  Cleaned values.
	 * @param array $input   Unslashed request.
	 * @param int   $issued  When the form was drawn.
	 * @param int   $post_id Post id.
	 * @return bool
	 */
	private static function looks_like_spam( $form, $values, $input, $issued, $post_id ) {
		if ( isset( $input['wi_hp'] ) && '' !== trim( (string) ( is_scalar( $input['wi_hp'] ) ? $input['wi_hp'] : 'x' ) ) ) {
			return true;
		}
		if ( time() - $issued < self::MIN_AGE ) {
			return true;
		}
		$author = '';
		$email  = '';
		$text   = array();
		foreach ( $form['fields'] as $field ) {
			$value = $values[ $field['key'] ];
			if ( '' === $author && 'text' === $field['kind'] && self::is_name_field( $field ) ) {
				$author = $value;
			}
			if ( '' === $email && 'email' === $field['kind'] ) {
				$email = $value;
			}
			if ( 'checkbox' !== $field['kind'] ) {
				$text[] = $value;
			}
		}
		if ( wp_check_comment_disallowed_list( $author, $email, '', implode( "\n", $text ), '', '' ) ) {
			return true;
		}
		/**
		 * Lets a site add its own spam rule in code. Return true to treat the
		 * submission as spam: the visitor sees the sent box and nothing is
		 * sent, stored or called.
		 *
		 * @param bool  $reject  Default false.
		 * @param array $values  Cleaned values, keyed by field key.
		 * @param array $form    The normalised form.
		 * @param int   $post_id The post the form was drawn on.
		 */
		return (bool) apply_filters( 'wi_form_reject', false, $values, $form, $post_id );
	}

	/**
	 * Whether a field is the form's name field ("Name" / "Your name").
	 *
	 * @param array $field Normalised field.
	 * @return bool
	 */
	private static function is_name_field( $field ) {
		return in_array( strtolower( $field['label'] ), array( 'name', 'your name', 'full name' ), true );
	}

	/**
	 * Check every field against its kind's rules (§3, §8.3).
	 *
	 * @param array $form   Normalised form.
	 * @param array $values Cleaned values.
	 * @return array<int,array{0:string,1:string}> field index → [ summary link words, sentence under the box ].
	 */
	private static function validate( $form, $values ) {
		$errors = array();
		foreach ( $form['fields'] as $i => $field ) {
			$v     = $values[ $field['key'] ];
			$label = $field['label'];
			$len   = function_exists( 'mb_strlen' ) ? mb_strlen( $v ) : strlen( $v );

			if ( 'checkbox' === $field['kind'] ) {
				if ( $field['required'] && '1' !== $v ) {
					/* translators: %s: the checkbox's label. */
					$errors[ $i ] = array( sprintf( __( 'Tick the box “%s”', 'weidea-studio' ), $label ), __( 'Please tick the box to continue.', 'weidea-studio' ) );
				}
				continue;
			}
			if ( '' === $v ) {
				if ( $field['required'] ) {
					$errors[ $i ] = self::required_words( $field );
				}
				continue;
			}
			switch ( $field['kind'] ) {
				case 'email':
					if ( $len > self::MAX_EMAIL ) {
						$errors[ $i ] = self::too_long_words( $label, self::MAX_EMAIL );
					} elseif ( ! is_email( $v ) ) {
						$errors[ $i ] = array(
							/* translators: %s: the field's label. */
							sprintf( __( 'Check %s', 'weidea-studio' ), $label ),
							__( 'That doesn’t look like an email address — check it and try again.', 'weidea-studio' ),
						);
					}
					break;
				case 'phone':
					if ( ! preg_match( '/^[0-9 +()\-]+$/', $v ) ) {
						$errors[ $i ] = array(
							/* translators: %s: the field's label. */
							sprintf( __( 'Check %s', 'weidea-studio' ), $label ),
							/* translators: %s: the field's label. */
							sprintf( __( '%s can only have digits, spaces and + ( ) -.', 'weidea-studio' ), $label ),
						);
					} elseif ( $len > self::PHONE_MAX ) {
						$errors[ $i ] = self::too_long_words( $label, self::PHONE_MAX );
					} elseif ( $len < self::PHONE_MIN ) {
						$errors[ $i ] = array(
							/* translators: %s: the field's label. */
							sprintf( __( 'Check %s', 'weidea-studio' ), $label ),
							__( 'That phone number looks too short — check it and try again.', 'weidea-studio' ),
						);
					}
					break;
				case 'textarea':
					if ( $len > self::MAX_TEXTAREA ) {
						$errors[ $i ] = self::too_long_words( $label, self::MAX_TEXTAREA );
					}
					break;
				case 'select':
					if ( ! in_array( $v, $field['choices'], true ) ) {
						$errors[ $i ] = array(
							/* translators: %s: the field's label. */
							sprintf( __( 'Pick one of the choices for %s', 'weidea-studio' ), $label ),
							/* translators: %s: the field's label. */
							sprintf( __( 'Please pick one of the choices for %s.', 'weidea-studio' ), $label ),
						);
					}
					break;
				default:
					if ( $len > self::MAX_TEXT ) {
						$errors[ $i ] = self::too_long_words( $label, self::MAX_TEXT );
					}
			}
		}
		return $errors;
	}

	/**
	 * The words for an empty required field: two special cases so the
	 * sentence reads naturally, otherwise "Please fill in <label>." (§8.3).
	 *
	 * @param array $field Normalised field.
	 * @return array{0:string,1:string}
	 */
	private static function required_words( $field ) {
		$lower = strtolower( $field['label'] );
		if ( 'email' === $field['kind'] && in_array( $lower, array( 'email', 'email address', 'your email' ), true ) ) {
			return array( __( 'Add your email address', 'weidea-studio' ), __( 'Please add your email address.', 'weidea-studio' ) );
		}
		if ( in_array( $lower, array( 'message', 'your message' ), true ) ) {
			return array( __( 'Add a message', 'weidea-studio' ), __( 'Please add a message.', 'weidea-studio' ) );
		}
		if ( 'select' === $field['kind'] ) {
			return array(
				/* translators: %s: the field's label. */
				sprintf( __( 'Pick one of the choices for %s', 'weidea-studio' ), $field['label'] ),
				/* translators: %s: the field's label. */
				sprintf( __( 'Please pick one of the choices for %s.', 'weidea-studio' ), $field['label'] ),
			);
		}
		return array(
			/* translators: %s: the field's label. */
			sprintf( __( 'Fill in %s', 'weidea-studio' ), $field['label'] ),
			/* translators: %s: the field's label. */
			sprintf( __( 'Please fill in %s.', 'weidea-studio' ), $field['label'] ),
		);
	}

	/**
	 * The words for a value over its limit.
	 *
	 * @param string $label Field label.
	 * @param int    $max   The limit.
	 * @return array{0:string,1:string}
	 */
	private static function too_long_words( $label, $max ) {
		return array(
			/* translators: %s: the field's label. */
			sprintf( __( 'Shorten %s', 'weidea-studio' ), $label ),
			/* translators: 1: the field's label, 2: the most characters allowed. */
			sprintf( __( '%1$s can be at most %2$s characters.', 'weidea-studio' ), $label, number_format_i18n( $max ) ),
		);
	}

	/* ===================================================================
	 * Rate limit and duplicate guard (§6.3, §4.1 step 6).
	 * =================================================================== */

	/**
	 * The transient key for (form, address).
	 *
	 * @param int    $post_id Post id.
	 * @param string $uid     Form uid.
	 * @param string $addr    Address hash.
	 * @return string
	 */
	private static function rate_key( $post_id, $uid, $addr ) {
		return 'wi_form_rl_' . substr( hash( 'sha256', (int) $post_id . '|' . $uid . '|' . $addr ), 0, 40 );
	}

	/**
	 * Accepted messages counted for (form, address) in the current window.
	 *
	 * @param int    $post_id Post id.
	 * @param string $uid     Form uid.
	 * @param string $addr    Address hash.
	 * @return int
	 */
	private static function rate_count( $post_id, $uid, $addr ) {
		$data = get_transient( self::rate_key( $post_id, $uid, $addr ) );
		if ( ! is_array( $data ) || empty( $data['until'] ) || (int) $data['until'] <= time() ) {
			return 0;
		}
		return (int) $data['n'];
	}

	/**
	 * Count one accepted message. A FIXED window: the expiry is set by the
	 * first message counted and never extended — unlike the deploy key's
	 * lockout, which resets its expiry on every wrong key (§6.3).
	 *
	 * @param int    $post_id Post id.
	 * @param string $uid     Form uid.
	 * @param string $addr    Address hash.
	 */
	private static function rate_count_up( $post_id, $uid, $addr ) {
		$key  = self::rate_key( $post_id, $uid, $addr );
		$data = get_transient( $key );
		$now  = time();
		if ( ! is_array( $data ) || empty( $data['until'] ) || (int) $data['until'] <= $now ) {
			$data = array(
				'n'     => 0,
				'until' => $now + self::RATE_WINDOW,
			);
		}
		$data['n'] = (int) $data['n'] + 1;
		set_transient( $key, $data, max( 1, (int) $data['until'] - $now ) );
	}

	/**
	 * The duplicate guard's key, or '' when the submission has no words of
	 * its own (only choices and ticks) and so is not de-duplicated — the rate
	 * limit bounds those instead (R-K).
	 *
	 * @param array  $form    Normalised form.
	 * @param int    $post_id Post id.
	 * @param array  $values  Cleaned values.
	 * @param string $addr    Address hash.
	 * @return string
	 */
	private static function duplicate_key( $form, $post_id, $values, $addr ) {
		$words = false;
		foreach ( $form['fields'] as $field ) {
			if ( in_array( $field['kind'], array( 'text', 'email', 'phone', 'textarea' ), true ) && '' !== $values[ $field['key'] ] ) {
				$words = true;
				break;
			}
		}
		return $words ? 'wi_form_dup_' . substr( hash( 'sha256', (int) $post_id . '|' . $form['uid'] . '|' . wp_json_encode( $values ) . '|' . $addr ), 0, 40 ) : '';
	}

	/* ===================================================================
	 * The three things an accepted message causes: entry, email, webhook.
	 * =================================================================== */

	/**
	 * The words a field's value is written in, for the email and the entry.
	 *
	 * @param array  $field Normalised field.
	 * @param string $value Cleaned value.
	 * @return string
	 */
	private static function value_words( $field, $value ) {
		if ( 'checkbox' === $field['kind'] ) {
			return '1' === $value ? __( 'Yes', 'weidea-studio' ) : __( 'No', 'weidea-studio' );
		}
		return '' === $value ? __( '(not given)', 'weidea-studio' ) : $value;
	}

	/**
	 * The first email field's value, when it passed is_email() — the only
	 * thing that ever goes in Reply-To, and the key for the privacy tools.
	 *
	 * @param array $form   Normalised form.
	 * @param array $values Cleaned values.
	 * @return string
	 */
	private static function visitor_email( $form, $values ) {
		foreach ( $form['fields'] as $field ) {
			if ( 'email' === $field['kind'] && '' !== $values[ $field['key'] ] && is_email( $values[ $field['key'] ] ) ) {
				return $values[ $field['key'] ];
			}
		}
		return '';
	}

	/**
	 * The name field's value, if the form has one.
	 *
	 * @param array $form   Normalised form.
	 * @param array $values Cleaned values.
	 * @return string
	 */
	private static function visitor_name( $form, $values ) {
		foreach ( $form['fields'] as $field ) {
			if ( 'text' === $field['kind'] && self::is_name_field( $field ) && '' !== $values[ $field['key'] ] ) {
				return $values[ $field['key'] ];
			}
		}
		return '';
	}

	/**
	 * The form's name, or "Form" when it has none.
	 *
	 * @param array $form Normalised form.
	 * @return string
	 */
	private static function form_name( $form ) {
		$name = trim( (string) $form['attrs']['formName'] );
		return '' !== $name ? $name : __( 'Form', 'weidea-studio' );
	}

	/**
	 * Write the entry (ruled Q1). Meta is written already cleaned, because
	 * core filters no meta; the values are kept out of post_content, which
	 * core runs through the tag filter on an anonymous request (§4.2).
	 *
	 * @param array $form    Normalised form.
	 * @param int   $post_id The page it came from.
	 * @param array $values  Cleaned values.
	 * @return int Entry id, or 0.
	 */
	private static function store_entry( $form, $post_id, $values ) {
		$rows = array();
		foreach ( $form['fields'] as $field ) {
			$rows[] = array(
				'label' => $field['label'],
				'key'   => $field['key'],
				'type'  => $field['kind'],
				'value' => $values[ $field['key'] ],
			);
		}
		$keep = (string) $form['attrs']['keepFor'];
		$days = 'keep' === $keep ? 0 : ( in_array( $keep, array( '30', '365' ), true ) ? (int) $keep : self::KEEP_DAYS_DEFAULT );

		$entry_id = wp_insert_post(
			wp_slash(
				array(
					'post_type'   => self::POST_TYPE,
					'post_status' => 'private',
					'post_author' => 0,
					/* translators: 1: the form's name, 2: the date and time it arrived. */
					'post_title'  => sprintf( __( '%1$s — %2$s', 'weidea-studio' ), self::form_name( $form ), wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) ) ),
				)
			),
			true
		);
		if ( is_wp_error( $entry_id ) || ! $entry_id ) {
			return 0;
		}
		$email = strtolower( self::visitor_email( $form, $values ) );
		$meta  = array(
			'_wi_entry_fields' => $rows,
			'_wi_entry_page'   => (int) $post_id,
			'_wi_entry_form'   => $form['uid'],
			'_wi_entry_name'   => self::form_name( $form ),
			'_wi_entry_from'   => self::visitor_name( $form, $values ),
			'_wi_entry_email'  => $email,
		);
		if ( $days ) {
			$meta['_wi_entry_expires'] = time() + $days * DAY_IN_SECONDS;
		}
		foreach ( $meta as $key => $value ) {
			add_post_meta( $entry_id, $key, wp_slash( $value ), true );
		}
		// Every valid address in the message is a key WordPress's privacy
		// tools can find it by — a friend named in a second email box can ask
		// for their data too (audit, Oct 19: only the first was findable).
		$addresses = array();
		foreach ( $form['fields'] as $field ) {
			$value = $values[ $field['key'] ];
			if ( 'email' === $field['kind'] && '' !== $value && is_email( $value ) ) {
				$addresses[ strtolower( $value ) ] = true;
			}
		}
		foreach ( array_keys( $addresses ) as $address ) {
			add_post_meta( $entry_id, '_wi_entry_address', wp_slash( $address ) );
		}
		return (int) $entry_id;
	}

	/**
	 * Send the plain-text email (ruled Q6, Q7). No From header, ever: the
	 * site's mail setup supplies it and WP Mail SMTP's "Force From Email"
	 * overrides any From a plugin sets. The visitor's ADDRESS ALONE goes in
	 * Reply-To — never the typed name, which core would split on its commas
	 * (§5.1).
	 *
	 * @param array $form    Normalised form.
	 * @param int   $post_id The page it came from.
	 * @param array $values  Cleaned values.
	 * @return array{ok:bool,reason:string,at:int} What happened, for the entry.
	 */
	private static function send_email( $form, $post_id, $values ) {
		$to = array();
		foreach ( explode( ',', (string) $form['attrs']['to'] ) as $address ) {
			$address = trim( $address );
			if ( '' !== $address && is_email( $address ) ) {
				$to[] = $address;
			}
		}
		if ( ! $to ) {
			$to[] = get_option( 'admin_email' );
		}

		$site    = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$subject = trim( (string) $form['attrs']['subject'] );
		if ( '' === $subject ) {
			/* translators: 1: the site's name, 2: the form's name. */
			$subject = sprintf( __( '[%1$s] New message from the %2$s', 'weidea-studio' ), $site, self::form_name( $form ) );
		}

		$lines = array();
		foreach ( $form['fields'] as $field ) {
			$words = self::value_words( $field, $values[ $field['key'] ] );
			if ( 'textarea' === $field['kind'] && '' !== $values[ $field['key'] ] ) {
				$lines[] = $field['label'] . ':';
				$lines[] = $words;
			} else {
				$lines[] = $field['label'] . ': ' . $words;
			}
		}
		$lines[] = '';
		$lines[] = sprintf(
			/* translators: 1: the page title, 2: its address, 3: the date, 4: the time. */
			__( 'Sent from the page “%1$s” (%2$s) on %3$s at %4$s.', 'weidea-studio' ),
			wp_specialchars_decode( get_the_title( $post_id ), ENT_QUOTES ),
			get_permalink( $post_id ),
			wp_date( get_option( 'date_format' ) ),
			wp_date( get_option( 'time_format' ) )
		);

		$headers = array();
		$reply   = self::visitor_email( $form, $values );
		if ( '' !== $reply ) {
			$headers[] = 'Reply-To: ' . $reply;
			$name      = self::visitor_name( $form, $values );
			$lines[]   = '' !== $name
				/* translators: %s: the visitor's name as they typed it. */
				? sprintf( __( 'Reply to this email to answer %s.', 'weidea-studio' ), $name )
				: __( 'Reply to this email to answer the person who sent it.', 'weidea-studio' );
		}

		// wp_mail()'s answer only means "handed over" (§5.2), and WP Mail
		// SMTP reports its own failures through wp_mail_failed — so both are
		// listened to.
		$failure = null;
		$catch   = function ( $error ) use ( &$failure ) {
			$failure = $error;
		};
		add_action( 'wp_mail_failed', $catch );
		$sent = wp_mail( $to, $subject, implode( "\n", $lines ), $headers );
		remove_action( 'wp_mail_failed', $catch );

		if ( $sent && ! $failure ) {
			return array(
				'ok'     => true,
				'reason' => '',
				'at'     => time(),
			);
		}
		$reason = $failure instanceof WP_Error ? $failure->get_error_message() : __( 'the mail system refused it without saying why', 'weidea-studio' );
		return array(
			'ok'     => false,
			'reason' => sanitize_text_field( $reason ),
			'at'     => time(),
		);
	}

	/**
	 * Why a webhook address is refused before any request is made, or ''.
	 * https only, by our rule; core's own check runs again inside
	 * wp_safe_remote_post(). The private-range check is the form's OWN and
	 * runs first, so the entry records the form's reason (§7.1).
	 *
	 * @param string $url Webhook address.
	 * @return string
	 */
	private static function webhook_refusal( $url ) {
		if ( 0 !== stripos( $url, 'https://' ) ) {
			return __( 'not sent — the address must start with https://', 'weidea-studio' );
		}
		$host = wp_parse_url( $url, PHP_URL_HOST );
		if ( ! is_string( $host ) || '' === $host ) {
			return __( 'not sent — that is not a web address', 'weidea-studio' );
		}
		$host = trim( $host, '[]' );
		if ( filter_var( $host, FILTER_VALIDATE_IP ) ) {
			$ip = $host;
		} else {
			$ip = gethostbyname( $host );
			if ( $ip === $host ) {
				return ''; // Does not resolve: the transport says so, on the entry.
			}
		}
		// Private and reserved ranges — 10/8, 172.16/12, 192.168/16, 127/8,
		// 0/8, 169.254/16 (cloud metadata), 240/4 and their IPv6 kin — plus
		// the shared 100.64/10 range PHP's flags do not cover. Resolved once
		// here and once again by the transport, so a host whose answer
		// changes between the two is not caught (R-F, named not solved).
		if ( ! filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) || preg_match( '/^100\.(6[4-9]|[7-9][0-9]|1[01][0-9]|12[0-7])\./', $ip ) ) {
			return __( 'not sent — the address is inside a private network', 'weidea-studio' );
		}
		return '';
	}

	/**
	 * Call the webhook, if the form has one (§7). Blocking, 5 seconds, no
	 * redirects followed, no retry; the answer is recorded on the entry and
	 * the visitor is never told.
	 *
	 * @param array $form     Normalised form.
	 * @param int   $post_id  The page it came from.
	 * @param array $values   Cleaned values.
	 * @param int   $entry_id The entry, or 0.
	 * @return array{state:string,code:int,reason:string}
	 */
	private static function call_webhook( $form, $post_id, $values, $entry_id ) {
		$url = trim( (string) $form['attrs']['webhookUrl'] );
		if ( '' === $url ) {
			return array(
				'state'  => 'none',
				'code'   => 0,
				'reason' => '',
			);
		}
		$refused = self::webhook_refusal( $url );
		if ( '' !== $refused ) {
			return array(
				'state'  => 'failed',
				'code'   => 0,
				'reason' => $refused,
			);
		}

		$fields = array();
		foreach ( $form['fields'] as $field ) {
			$fields[] = array(
				'key'   => $field['key'],
				'label' => $field['label'],
				'type'  => $field['kind'],
				'value' => 'checkbox' === $field['kind'] ? '1' === $values[ $field['key'] ] : $values[ $field['key'] ],
			);
		}
		$payload = array(
			'form'         => array(
				'name'     => self::form_name( $form ),
				'id'       => $form['uid'],
				'page_id'  => (int) $post_id,
				'page_url' => get_permalink( $post_id ),
			),
			'submitted_at' => gmdate( 'c' ),
			'fields'       => $fields,
			'entry_id'     => $entry_id ? (int) $entry_id : null,
		);

		$response = wp_safe_remote_post(
			$url,
			array(
				'body'        => wp_json_encode( $payload ),
				'headers'     => array( 'Content-Type' => 'application/json' ),
				'timeout'     => 5,
				'redirection' => 0,
			)
		);
		if ( is_wp_error( $response ) ) {
			return array(
				'state'  => 'failed',
				'code'   => 0,
				'reason' => sanitize_text_field( $response->get_error_message() ),
			);
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		return array(
			'state'  => $code >= 200 && $code < 300 ? 'ok' : 'failed',
			'code'   => $code,
			'reason' => '',
		);
	}

	/* ===================================================================
	 * Drawing — the one renderer (ruled Q3).
	 * =================================================================== */

	/**
	 * Draw a state: the sent or gone box in the form's place, or the form.
	 *
	 * @param array $state  State from handle() or render().
	 * @param bool  $redraw True for a REST fragment: drawn without the motion
	 *                      classes, which the page's motion script only ever
	 *                      reveals once, at load — a swapped-in box carrying
	 *                      them would stay invisible.
	 * @return string
	 */
	private static function draw_state( $state, $redraw ) {
		$n = isset( $state['n'] ) ? (int) $state['n'] : 1;
		if ( 'gone' === $state['state'] || ! $state['form'] ) {
			return self::draw_box( $state['uid'], null, 'gone', $n );
		}
		if ( 'sent' === $state['state'] ) {
			return self::draw_box( $state['uid'], $state['form'], 'sent', $n );
		}
		return self::draw_form( $state, $redraw );
	}

	/**
	 * The form root's id: the author's anchor when one is set, else
	 * wi-form-<uid>. The same id is on the sent box, so the plain road's
	 * `#<id>` opens the answer at the form's place.
	 *
	 * The second and later copies of one form on a page (a synced pattern
	 * placed twice) get "-2", "-3"… on every id they write, so labels, the
	 * list's links and the plain road's "#…" each reach their own copy
	 * (audit, Oct 19). The first copy's ids never change.
	 *
	 * @param string     $uid  Form uid.
	 * @param array|null $form Normalised form.
	 * @param int        $n    Which copy on the page.
	 * @return string
	 */
	private static function root_id( $uid, $form, $n = 1 ) {
		$anchor = $form ? trim( (string) $form['attrs']['anchor'] ) : '';
		$anchor = preg_replace( '/[^A-Za-z0-9_:.-]/', '', $anchor );
		return ( '' !== $anchor ? $anchor : 'wi-form-' . $uid ) . self::copy_suffix( $n );
	}

	/**
	 * The id suffix for the n-th copy of a form on a page.
	 *
	 * @param int $n Which copy.
	 * @return string '' for the first, "-n" after.
	 */
	private static function copy_suffix( $n ) {
		return (int) $n > 1 ? '-' . (int) $n : '';
	}

	/**
	 * The root's class list: the class a static save would carry, the
	 * instance pair, and the author's extra classes.
	 *
	 * @param string     $uid   Form uid.
	 * @param array|null $form  Normalised form.
	 * @param string     $extra More classes.
	 * @return string
	 */
	private static function root_class( $uid, $form, $extra = '' ) {
		$classes = array( 'wp-block-weidea-form', 'wi-form', 'wi-form-' . $uid );
		if ( $form ) {
			foreach ( preg_split( '/\s+/', (string) $form['attrs']['className'] ) as $class ) {
				$class = sanitize_html_class( $class );
				if ( '' !== $class ) {
					$classes[] = $class;
				}
			}
		}
		if ( '' !== $extra ) {
			$classes[] = $extra;
		}
		return implode( ' ', array_unique( $classes ) );
	}

	/**
	 * The box that takes the form's place: sent (ruled Q4), or gone.
	 *
	 * @param string     $uid  Form uid.
	 * @param array|null $form Normalised form, or null when it is gone.
	 * @param string     $kind 'sent' or 'gone'.
	 * @param int        $n    Which copy on the page.
	 * @return string
	 */
	private static function draw_box( $uid, $form, $kind, $n = 1 ) {
		$uid = '' !== $uid ? $uid : 'unknown';
		if ( 'gone' === $kind ) {
			$title = __( 'This form is no longer available. Please reload the page.', 'weidea-studio' );
			$body  = '';
			$extra = 'wi-form__success wi-form__success--gone';
		} else {
			$title = trim( (string) $form['attrs']['successTitle'] );
			$title = '' !== $title ? $title : __( 'Thanks — your message has been sent.', 'weidea-studio' );
			$body  = trim( (string) $form['attrs']['successBody'] );
			if ( '' === $body && self::has_email_field( $form ) ) {
				$body = __( 'We’ll reply to the email address you gave us.', 'weidea-studio' );
			}
			$extra = 'wi-form__success';
		}
		return sprintf(
			'<div class="%1$s" id="%2$s" role="status" tabindex="-1"><p class="wi-form__success-title">%3$s</p>%4$s</div>',
			esc_attr( self::root_class( $uid, $form, $extra ) ),
			esc_attr( self::root_id( $uid, $form, $n ) ),
			esc_html( $title ),
			'' !== $body ? '<p>' . esc_html( $body ) . '</p>' : ''
		);
	}

	/**
	 * The form, in any of its on-screen states (§2.6 is the contract).
	 *
	 * @param array $state  State.
	 * @param bool  $redraw REST fragment (no motion classes).
	 * @return string
	 */
	private static function draw_form( $state, $redraw ) {
		$form    = $state['form'];
		$uid     = $form['uid'];
		$post_id = (int) $state['post_id'];
		$surface = 'preview' === $state['surface'] ? 'preview' : 'live';
		$errors  = $state['errors'];
		$values  = $state['values'];
		$n       = isset( $state['n'] ) ? (int) $state['n'] : 1;
		$suffix  = self::copy_suffix( $n );
		$id      = self::root_id( $uid, $form, $n );
		// A form drawn after a verified press keeps that press's issue time
		// (handle() step 2); a fresh draw, and the refreshed state, start now.
		$issued  = isset( $state['issued'] ) ? (int) $state['issued'] : time();
		$again   = ! empty( $state['again'] );
		$focus   = ' data-wi-focus';

		$html  = sprintf(
			'<form class="%1$s" id="%2$s" method="post" action="%3$s" novalidate data-wi-v="1" data-wi-endpoint="%4$s">',
			esc_attr( self::root_class( $uid, $form ) ),
			esc_attr( $id ),
			esc_url( self::action_for( $post_id, $surface, $uid ) . '#' . $id ),
			esc_url( rest_url( self::REST_NS . self::REST_ROUTE ) )
		);

		// One data-wi-focus per drawn form (§2.6 rule 3).
		$notice = '';
		if ( 'wait' === $state['state'] ) {
			$notice = __( 'Please wait a few minutes before sending another message.', 'weidea-studio' );
		} elseif ( 'refreshed' === $state['state'] ) {
			$notice = __( 'This form was out of date and has been refreshed. Try Send again — nothing you typed has been lost.', 'weidea-studio' );
		}
		if ( '' !== $notice ) {
			$html .= '<p class="wi-form__general" tabindex="-1"' . $focus . '>' . esc_html( $notice ) . '</p>';
			$focus = '';
		}
		// The script's line for a dropped connection or a server error. It is
		// in the page, hidden, so its words are the server's too.
		$html .= '<p class="wi-form__general" data-wi-net hidden tabindex="-1">' . esc_html__( 'Your message didn’t go through. Check your connection and try Send again — nothing you typed has been lost.', 'weidea-studio' ) . '</p>';

		if ( $errors ) {
			$count = count( $errors );
			$words = array(
				2 => __( 'two', 'weidea-studio' ),
				3 => __( 'three', 'weidea-studio' ),
				4 => __( 'four', 'weidea-studio' ),
				5 => __( 'five', 'weidea-studio' ),
				6 => __( 'six', 'weidea-studio' ),
				7 => __( 'seven', 'weidea-studio' ),
				8 => __( 'eight', 'weidea-studio' ),
				9 => __( 'nine', 'weidea-studio' ),
			);
			if ( 1 === $count ) {
				$heading = __( 'Please check one thing below.', 'weidea-studio' );
			} else {
				/* translators: %s: how many things, as a word ("two") or a number. */
				$heading = sprintf( __( 'Please check %s things below.', 'weidea-studio' ), isset( $words[ $count ] ) ? $words[ $count ] : number_format_i18n( $count ) );
			}
			$items = '';
			foreach ( $errors as $i => $pair ) {
				$items .= '<li><a href="#wi-f-' . esc_attr( $form['fields'][ $i ]['uid'] . $suffix ) . '">' . esc_html( $pair[0] ) . '</a></li>';
			}
			$html .= '<div class="wi-form__summary" tabindex="-1"' . $focus . '><div role="alert"><p class="wi-form__summary-title">' . esc_html( $heading ) . '</p><ul>' . $items . '</ul></div></div>';
			$focus = '';
		}

		$html .= '<div class="wi-form__fields">';
		foreach ( $form['fields'] as $i => $field ) {
			$one = self::draw_field( $field, isset( $values[ $field['key'] ] ) ? $values[ $field['key'] ] : '', isset( $errors[ $i ] ) ? $errors[ $i ][1] : '', $suffix );
			if ( ! $redraw ) {
				// The field's own Animate settings: a field saves no markup for
				// WI_Motion's pass to reach, so the Form hands it the field.
				$one = WI_Motion::render_block( $one, $field['parsed'] );
			}
			$html .= $one;
		}
		$html .= '</div>';

		// The trap (§6.1): off-screen, out of the tab order, hidden from
		// screen readers, and a name no browser autofills.
		$html .= sprintf(
			'<div class="wi-form__hp" aria-hidden="true"><label for="wi-hp-%1$s">%2$s</label><input id="wi-hp-%1$s" name="wi_hp" type="text" tabindex="-1" autocomplete="off" value=""></div>',
			esc_attr( $uid . $suffix ),
			esc_html__( 'Leave this field empty', 'weidea-studio' )
		);
		$html .= sprintf(
			'<input type="hidden" name="wi_post" value="%1$d"><input type="hidden" name="wi_form" value="%2$s"><input type="hidden" name="wi_issued" value="%3$d"><input type="hidden" name="wi_surface" value="%4$s"><input type="hidden" name="wi_token" value="%5$s">%6$s%7$s',
			$post_id,
			esc_attr( $uid ),
			$issued,
			esc_attr( $surface ),
			esc_attr( self::token( $post_id, $uid, $issued, $surface, $again ) ),
			$again ? '<input type="hidden" name="wi_again" value="1">' : '',
			$n > 1 ? '<input type="hidden" name="wi_n" value="' . (int) $n . '">' : ''
		);

		$label = trim( wp_kses( (string) $form['attrs']['buttonLabel'], array() ) );
		$html .= sprintf(
			'<div class="wi-form__actions"><button class="wi-form__button" type="submit" data-wi-busy="%1$s">%2$s</button></div>',
			esc_attr__( 'Sending…', 'weidea-studio' ),
			'' !== $label ? $label : esc_html__( 'Send', 'weidea-studio' )
		);

		// The amber line on a preview (ruled Q8), and its answer after Send.
		if ( 'preview' === $surface ) {
			if ( 'preview-sent' === $state['state'] ) {
				$html .= '<p class="wi-form__preview" role="status" tabindex="-1"' . $focus . '>' . esc_html__( 'Nothing was sent — this page is a preview. The form will work once the page is deployed.', 'weidea-studio' ) . '</p>';
			} else {
				$html .= '<p class="wi-form__preview">' . esc_html__( 'This is a preview of the page. Nothing you send here is delivered until the page is deployed.', 'weidea-studio' ) . '</p>';
			}
		}

		return $html . '</form>';
	}

	/**
	 * One field (§2.6). Echoed values are ESCAPED, not merely cleaned
	 * (rule 4): esc_attr() inside value="…", esc_textarea() inside a
	 * textarea; a choice or a tick only selects or checks what the author
	 * wrote, and is never written back as text.
	 *
	 * @param array  $field  Normalised field.
	 * @param string $value  Cleaned value to keep.
	 * @param string $error  The sentence under the box, or ''.
	 * @param string $suffix Id suffix for a second copy of the form.
	 * @return string
	 */
	private static function draw_field( $field, $value, $error, $suffix = '' ) {
		$id       = 'wi-f-' . $field['uid'] . $suffix;
		$kind     = $field['kind'];
		$describe = ( '' !== $field['help'] ? $id . '-hint ' : '' ) . $id . '-err';
		$aria     = ' aria-describedby="' . esc_attr( $describe ) . '"'
			. ( $field['required'] ? ' aria-required="true"' : '' )
			. ( '' !== $error ? ' aria-invalid="true"' : '' );
		$words    = esc_html( $field['label'] )
			. ( $field['required'] ? ' <span class="wi-form__req">' . esc_html__( '(required)', 'weidea-studio' ) . '</span>' : '' );
		$label    = '<label class="wi-form__label" for="' . esc_attr( $id ) . '">' . $words . '</label>';
		$hold     = '' !== $field['placeholder'] ? ' placeholder="' . esc_attr( $field['placeholder'] ) . '"' : '';
		$name     = ' id="' . esc_attr( $id ) . '" name="' . esc_attr( $field['name'] ) . '"';

		if ( 'textarea' === $kind ) {
			$box = $label . '<textarea class="wi-form__input" rows="5"' . $name . $hold . $aria . '>' . self::inert( esc_textarea( $value ) ) . '</textarea>';
		} elseif ( 'select' === $kind ) {
			$first   = '' !== $field['placeholder'] ? $field['placeholder'] : __( 'Choose one', 'weidea-studio' );
			$options = '<option value="">' . esc_html( $first ) . '</option>';
			foreach ( $field['choices'] as $choice ) {
				$options .= '<option value="' . esc_attr( $choice ) . '"' . selected( $choice, $value, false ) . '>' . esc_html( $choice ) . '</option>';
			}
			$box = $label . '<select class="wi-form__input"' . $name . $aria . '>' . $options . '</select>';
		} elseif ( 'checkbox' === $kind ) {
			$box = '<div class="wi-form__check-row"><input class="wi-form__check" type="checkbox" value="1"' . $name . ( '1' === $value ? ' checked' : '' ) . $aria . '>' . $label . '</div>';
		} else {
			$type = array(
				'email' => 'email',
				'phone' => 'tel',
			);
			$auto = 'email' === $kind ? ' autocomplete="email" inputmode="email"' : ( 'phone' === $kind ? ' autocomplete="tel" inputmode="tel"' : ( self::is_name_field( $field ) ? ' autocomplete="name"' : '' ) );
			$box  = $label . '<input class="wi-form__input"' . $name . ' type="' . ( isset( $type[ $kind ] ) ? $type[ $kind ] : 'text' ) . '" value="' . self::inert( esc_attr( $value ) ) . '"' . $auto . $hold . $aria . '>';
		}

		return '<div class="wi-form__field wi-form__field--' . esc_attr( $kind ) . ' wi-form-field-' . esc_attr( $field['uid'] ) . '">'
			. $box
			. ( '' !== $field['help'] ? '<p class="wi-form__hint" id="' . esc_attr( $id ) . '-hint">' . esc_html( $field['help'] ) . '</p>' : '' )
			. '<p class="wi-form__error" id="' . esc_attr( $id ) . '-err">' . esc_html( $error ) . '</p>'
			. '</div>';
	}

	/**
	 * Make an already-escaped value inert to the page's content filters,
	 * which run AFTER blocks render on the plain-POST road: brackets become
	 * the codes core itself uses, so a typed "[gallery]" is never run as a
	 * shortcode, and the brand-name "correction" (capital_P_dangit) cannot
	 * find its spelling. The browser shows exactly what was typed; the REST
	 * road writes the same bytes (audit, Oct 19).
	 *
	 * @param string $escaped Escaped value.
	 * @return string
	 */
	private static function inert( $escaped ) {
		return str_replace( array( '[', ']', 'Wordpress' ), array( '&#91;', '&#93;', 'W&#111;rdpress' ), $escaped );
	}

	/* ===================================================================
	 * Entries: the post type, the list, retention, privacy (ruled Q1).
	 * =================================================================== */

	/**
	 * Register the entries post type: no public face, a list under
	 * Settings beside Settings → WeIdea Studio, readable and deletable by
	 * anyone who can edit pages — the same bar as building a form.
	 */
	public static function register_entries() {
		register_post_type(
			self::POST_TYPE,
			array(
				'labels'              => array(
					'name'               => __( 'Form entries', 'weidea-studio' ),
					'singular_name'      => __( 'Form entry', 'weidea-studio' ),
					'menu_name'          => __( 'Form entries', 'weidea-studio' ),
					'all_items'          => __( 'Form entries', 'weidea-studio' ),
					'edit_item'          => __( 'Form entry', 'weidea-studio' ),
					'view_item'          => __( 'View entry', 'weidea-studio' ),
					'search_items'       => __( 'Search entries', 'weidea-studio' ),
					'not_found'          => __( 'No form entries yet.', 'weidea-studio' ),
					'not_found_in_trash' => __( 'No form entries in the bin.', 'weidea-studio' ),
				),
				'public'              => false,
				'publicly_queryable'  => false,
				'exclude_from_search' => true,
				'show_ui'             => true,
				'show_in_menu'        => 'options-general.php',
				'show_in_rest'        => false,
				'show_in_nav_menus'   => false,
				'show_in_admin_bar'   => false,
				// The list is under Settings (ruled Q1), and WordPress shows
				// Settings to administrators only — an Editor sent to it is
				// told they may not open it. So the Settings bar holds on every
				// road to an entry, not only the list: one entry's screen,
				// reading it, deleting it (audit, Oct 19). Whether Editors
				// should read entries — the design's first intent — is #94.
				'capabilities'        => array(
					'edit_post'          => 'manage_options',
					'read_post'          => 'manage_options',
					'delete_post'        => 'manage_options',
					'edit_posts'         => 'manage_options',
					'edit_others_posts'  => 'manage_options',
					'delete_posts'       => 'manage_options',
					'publish_posts'      => 'manage_options',
					'read_private_posts' => 'manage_options',
					'create_posts'       => 'do_not_allow',
				),
				'map_meta_cap'        => false,
				'supports'            => array( 'title' ),
				'rewrite'             => false,
				'query_var'           => false,
				'can_export'          => false,
			)
		);
	}

	/**
	 * Keep the daily retention event scheduled.
	 */
	public static function schedule_sweep() {
		if ( ! wp_next_scheduled( self::SWEEP_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::SWEEP_HOOK );
		}
	}

	/**
	 * Delete every entry past its keep-until time — outright, not binned:
	 * the bin would merely move the personal data (§4.2). Runs on
	 * WordPress's own scheduler, so on a quiet site it is late by however
	 * long the quiet lasts, and never early.
	 */
	public static function sweep() {
		do {
			$ids = get_posts(
				array(
					'post_type'        => self::POST_TYPE,
					'post_status'      => array( 'private', 'publish', 'draft', 'pending', 'trash' ),
					'fields'           => 'ids',
					'numberposts'      => 100,
					'suppress_filters' => true,
					'meta_query'       => array( // phpcs:ignore WordPress.DB.SlowDBQuery
						array(
							'key'     => '_wi_entry_expires',
							'value'   => time(),
							'compare' => '<=',
							'type'    => 'NUMERIC',
						),
					),
				)
			);
			foreach ( $ids as $id ) {
				wp_delete_post( $id, true );
			}
		} while ( count( $ids ) === 100 );
	}

	/**
	 * Unschedule the retention event (plugin deactivation).
	 */
	public static function deactivate() {
		wp_clear_scheduled_hook( self::SWEEP_HOOK );
	}

	/**
	 * The list's columns: Received · Form · Page · From · Email · Webhook.
	 *
	 * @param array $columns Core's columns.
	 * @return array
	 */
	public static function list_columns( $columns ) {
		return array(
			'cb'          => isset( $columns['cb'] ) ? $columns['cb'] : '<input type="checkbox" />',
			'wi_received' => __( 'Received', 'weidea-studio' ),
			'wi_form'     => __( 'Form', 'weidea-studio' ),
			'wi_page'     => __( 'Page', 'weidea-studio' ),
			'wi_from'     => __( 'From', 'weidea-studio' ),
			'wi_email'    => __( 'Email sent', 'weidea-studio' ),
			'wi_webhook'  => __( 'Webhook', 'weidea-studio' ),
		);
	}

	/**
	 * Received carries the row actions.
	 *
	 * @param string $default Default column.
	 * @param string $screen  Screen id.
	 * @return string
	 */
	public static function list_primary_column( $default, $screen ) {
		return 'edit-' . self::POST_TYPE === $screen ? 'wi_received' : $default;
	}

	/**
	 * One cell.
	 *
	 * @param string $column  Column key.
	 * @param int    $post_id Entry id.
	 */
	public static function list_cell( $column, $post_id ) {
		switch ( $column ) {
			case 'wi_received':
				printf(
					'<strong><a class="row-title" href="%1$s">%2$s</a></strong>',
					esc_url( get_edit_post_link( $post_id ) ),
					esc_html( get_the_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $post_id ) )
				);
				break;
			case 'wi_form':
				echo esc_html( (string) get_post_meta( $post_id, '_wi_entry_name', true ) );
				break;
			case 'wi_page':
				$page = (int) get_post_meta( $post_id, '_wi_entry_page', true );
				$link = $page ? get_permalink( $page ) : '';
				if ( $link ) {
					printf( '<a href="%1$s">%2$s</a>', esc_url( $link ), esc_html( get_the_title( $page ) ) );
				} else {
					esc_html_e( '(page no longer exists)', 'weidea-studio' );
				}
				break;
			case 'wi_from':
				$name  = (string) get_post_meta( $post_id, '_wi_entry_from', true );
				$email = (string) get_post_meta( $post_id, '_wi_entry_email', true );
				echo esc_html( trim( $name . ( '' !== $name && '' !== $email ? ' · ' : '' ) . $email ) );
				break;
			case 'wi_email':
				$mail = get_post_meta( $post_id, '_wi_entry_mail', true );
				echo esc_html( is_array( $mail ) && ! empty( $mail['ok'] ) ? __( 'Sent', 'weidea-studio' ) : __( 'Not sent', 'weidea-studio' ) );
				break;
			case 'wi_webhook':
				$hook = get_post_meta( $post_id, '_wi_entry_webhook', true );
				$st   = is_array( $hook ) && isset( $hook['state'] ) ? $hook['state'] : 'none';
				echo esc_html( 'ok' === $st ? __( 'Delivered', 'weidea-studio' ) : ( 'failed' === $st ? __( 'Failed', 'weidea-studio' ) : '—' ) );
				break;
		}
	}

	/**
	 * Row actions: View and Delete permanently — nothing to edit, and no
	 * bin, which would merely move the personal data.
	 *
	 * @param array   $actions Core's actions.
	 * @param WP_Post $post    Entry.
	 * @return array
	 */
	public static function row_actions( $actions, $post ) {
		if ( self::POST_TYPE !== $post->post_type ) {
			return $actions;
		}
		$out = array(
			'view' => sprintf( '<a href="%1$s">%2$s</a>', esc_url( get_edit_post_link( $post->ID ) ), esc_html__( 'View', 'weidea-studio' ) ),
		);
		if ( current_user_can( 'delete_post', $post->ID ) ) {
			$out['delete'] = sprintf( '<a class="submitdelete" href="%1$s">%2$s</a>', esc_url( get_delete_post_link( $post->ID, '', true ) ), esc_html__( 'Delete permanently', 'weidea-studio' ) );
		}
		return $out;
	}

	/**
	 * Bulk actions: delete permanently only.
	 *
	 * @param array $actions Core's actions.
	 * @return array
	 */
	public static function bulk_actions( $actions ) {
		return array( 'delete' => __( 'Delete permanently', 'weidea-studio' ) );
	}

	/**
	 * Filters above the list: by form, by page.
	 *
	 * @param string $post_type Screen post type.
	 */
	public static function list_filters( $post_type ) {
		if ( self::POST_TYPE !== $post_type ) {
			return;
		}
		global $wpdb;
		$forms = $wpdb->get_results( $wpdb->prepare( "SELECT DISTINCT m.meta_value AS uid, n.meta_value AS name FROM {$wpdb->postmeta} m JOIN {$wpdb->postmeta} n ON n.post_id = m.post_id AND n.meta_key = '_wi_entry_name' JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE m.meta_key = '_wi_entry_form' AND p.post_type = %s", self::POST_TYPE ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$pages = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT m.meta_value FROM {$wpdb->postmeta} m JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE m.meta_key = '_wi_entry_page' AND p.post_type = %s", self::POST_TYPE ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$form  = isset( $_GET['wi_entry_form'] ) ? sanitize_key( wp_unslash( $_GET['wi_entry_form'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page  = isset( $_GET['wi_entry_page'] ) ? absint( $_GET['wi_entry_page'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		echo '<label class="screen-reader-text" for="wi-entry-form">' . esc_html__( 'Filter by form', 'weidea-studio' ) . '</label><select name="wi_entry_form" id="wi-entry-form"><option value="">' . esc_html__( 'All forms', 'weidea-studio' ) . '</option>';
		foreach ( (array) $forms as $row ) {
			echo '<option value="' . esc_attr( $row->uid ) . '"' . selected( $form, $row->uid, false ) . '>' . esc_html( $row->name ) . '</option>';
		}
		echo '</select><label class="screen-reader-text" for="wi-entry-page">' . esc_html__( 'Filter by page', 'weidea-studio' ) . '</label><select name="wi_entry_page" id="wi-entry-page"><option value="">' . esc_html__( 'All pages', 'weidea-studio' ) . '</option>';
		foreach ( (array) $pages as $id ) {
			echo '<option value="' . esc_attr( $id ) . '"' . selected( $page, (int) $id, false ) . '>' . esc_html( get_the_title( (int) $id ) ) . '</option>';
		}
		echo '</select>';
	}

	/**
	 * Apply the two filters to the list's query.
	 *
	 * @param WP_Query $query The query.
	 */
	public static function apply_list_filters( $query ) {
		if ( ! $query->is_main_query() || self::POST_TYPE !== $query->get( 'post_type' ) ) {
			return;
		}
		$meta = array();
		if ( ! empty( $_GET['wi_entry_form'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$meta[] = array(
				'key'   => '_wi_entry_form',
				'value' => sanitize_key( wp_unslash( $_GET['wi_entry_form'] ) ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			);
		}
		if ( ! empty( $_GET['wi_entry_page'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$meta[] = array(
				'key'   => '_wi_entry_page',
				'value' => absint( $_GET['wi_entry_page'] ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			);
		}
		if ( $meta ) {
			$existing = (array) $query->get( 'meta_query' );
			$query->set( 'meta_query', array_merge( $existing, $meta ) );
		}
	}

	/**
	 * The plain sentence under the list's views.
	 *
	 * @param array $views Core's views.
	 * @return array
	 */
	public static function list_retention_note( $views ) {
		echo '<p class="description">' . esc_html__( 'Each entry is deleted automatically when its form’s “Keep entries for” time runs out — 90 days unless the form says otherwise. Deleting here is permanent.', 'weidea-studio' ) . '</p>';
		// No "All (5) | Private (5)" links: entries are stored as private
		// posts so nothing can show them in public, and "Private" is a
		// WordPress word that means nothing about a message (built
		// photograph, Oct 19). Every entry is the same kind of thing.
		return array();
	}

	/**
	 * The entry screen: every field, the page, and what happened to the
	 * email and the webhook, in words.
	 */
	public static function entry_meta_boxes() {
		remove_meta_box( 'slugdiv', self::POST_TYPE, 'normal' );
		add_meta_box( 'wi-entry', __( 'Message', 'weidea-studio' ), array( __CLASS__, 'entry_box' ), self::POST_TYPE, 'normal', 'high' );
	}

	/**
	 * Draw the entry box.
	 *
	 * @param WP_Post $post Entry.
	 */
	public static function entry_box( $post ) {
		$rows = get_post_meta( $post->ID, '_wi_entry_fields', true );
		$page = (int) get_post_meta( $post->ID, '_wi_entry_page', true );
		$mail = get_post_meta( $post->ID, '_wi_entry_mail', true );
		$hook = get_post_meta( $post->ID, '_wi_entry_webhook', true );

		echo '<table class="widefat striped"><tbody>';
		$link = $page ? get_permalink( $page ) : '';
		echo '<tr><th scope="row">' . esc_html__( 'Page', 'weidea-studio' ) . '</th><td>' . ( $link ? '<a href="' . esc_url( $link ) . '">' . esc_html( get_the_title( $page ) ) . '</a>' : esc_html__( '(page no longer exists)', 'weidea-studio' ) ) . '</td></tr>';
		foreach ( (array) $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$value = 'checkbox' === $row['type'] ? ( '1' === $row['value'] ? __( 'Yes', 'weidea-studio' ) : __( 'No', 'weidea-studio' ) ) : ( '' === $row['value'] ? __( '(not given)', 'weidea-studio' ) : $row['value'] );
			echo '<tr><th scope="row">' . esc_html( $row['label'] ) . '</th><td>' . nl2br( esc_html( $value ) ) . '</td></tr>';
		}
		if ( is_array( $mail ) && ! empty( $mail['ok'] ) ) {
			/* translators: %s: date and time. */
			$said = sprintf( __( 'Handed to the site’s mail system on %s — delivery itself is not confirmed.', 'weidea-studio' ), wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $mail['at'] ) );
		} elseif ( is_array( $mail ) ) {
			/* translators: %s: the reason the mail system gave. */
			$said = sprintf( __( 'Not handed over: %s', 'weidea-studio' ), $mail['reason'] );
		} else {
			$said = __( 'Not handed over: the email was never attempted.', 'weidea-studio' );
		}
		echo '<tr><th scope="row">' . esc_html__( 'Email sent', 'weidea-studio' ) . '</th><td>' . esc_html( $said ) . '</td></tr>';
		$st = is_array( $hook ) && isset( $hook['state'] ) ? $hook['state'] : 'none';
		if ( 'ok' === $st ) {
			/* translators: %d: HTTP status code. */
			$said = sprintf( __( 'Webhook: delivered (HTTP %d)', 'weidea-studio' ), (int) $hook['code'] );
		} elseif ( 'failed' === $st ) {
			/* translators: %s: the reason. */
			$said = sprintf( __( 'Webhook: failed (%s)', 'weidea-studio' ), $hook['code'] ? 'HTTP ' . (int) $hook['code'] : $hook['reason'] );
		} else {
			$said = __( 'Not set on this form', 'weidea-studio' );
		}
		echo '<tr><th scope="row">' . esc_html__( 'Webhook', 'weidea-studio' ) . '</th><td>' . esc_html( $said ) . '</td></tr>';
		echo '</tbody></table>';
		if ( ! get_post_meta( $post->ID, '_wi_entry_address' ) ) {
			echo '<p class="description">' . esc_html__( 'This entry has no email address, so WordPress’s Export and Erase Personal Data tools cannot find it. It is reachable only from this list, and it is deleted when its form’s “Keep entries for” time runs out.', 'weidea-studio' ) . '</p>';
		}
	}

	/**
	 * Register the exporter (Tools → Export Personal Data).
	 *
	 * @param array $exporters Exporters.
	 * @return array
	 */
	public static function register_exporter( $exporters ) {
		$exporters['weidea-studio-form-entries'] = array(
			'exporter_friendly_name' => __( 'WeIdea Studio form entries', 'weidea-studio' ),
			'callback'               => array( __CLASS__, 'export_personal_data' ),
		);
		return $exporters;
	}

	/**
	 * Register the eraser (Tools → Erase Personal Data).
	 *
	 * @param array $erasers Erasers.
	 * @return array
	 */
	public static function register_eraser( $erasers ) {
		$erasers['weidea-studio-form-entries'] = array(
			'eraser_friendly_name' => __( 'WeIdea Studio form entries', 'weidea-studio' ),
			'callback'             => array( __CLASS__, 'erase_personal_data' ),
		);
		return $erasers;
	}

	/**
	 * Entries for an email address, a page at a time.
	 *
	 * @param string $email Address.
	 * @param int    $page  1-based page.
	 * @return int[]
	 */
	private static function entries_for( $email, $page ) {
		return get_posts(
			array(
				'post_type'        => self::POST_TYPE,
				'post_status'      => array( 'private', 'publish', 'draft', 'pending', 'trash' ),
				'fields'           => 'ids',
				'numberposts'      => 50,
				'paged'            => max( 1, (int) $page ),
				'suppress_filters' => true,
				'meta_key'         => '_wi_entry_address', // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'       => strtolower( (string) $email ), // phpcs:ignore WordPress.DB.SlowDBQuery
			)
		);
	}

	/**
	 * The exporter.
	 *
	 * @param string $email Address.
	 * @param int    $page  Page.
	 * @return array
	 */
	public static function export_personal_data( $email, $page = 1 ) {
		$items = array();
		$ids   = self::entries_for( $email, $page );
		foreach ( $ids as $id ) {
			$data = array(
				array(
					'name'  => __( 'Received', 'weidea-studio' ),
					'value' => get_the_date( 'c', $id ),
				),
				array(
					'name'  => __( 'Form', 'weidea-studio' ),
					'value' => (string) get_post_meta( $id, '_wi_entry_name', true ),
				),
			);
			foreach ( (array) get_post_meta( $id, '_wi_entry_fields', true ) as $row ) {
				if ( is_array( $row ) ) {
					$data[] = array(
						'name'  => $row['label'],
						'value' => (string) $row['value'],
					);
				}
			}
			$items[] = array(
				'group_id'    => 'weidea-studio-form-entries',
				'group_label' => __( 'Form entries', 'weidea-studio' ),
				'item_id'     => 'wi-form-entry-' . $id,
				'data'        => $data,
			);
		}
		return array(
			'data' => $items,
			'done' => count( $ids ) < 50,
		);
	}

	/**
	 * The eraser: an entry IS the visitor's message, so erasing deletes it.
	 *
	 * @param string $email Address.
	 * @param int    $page  Page (always the first: deleted rows shift).
	 * @return array
	 */
	public static function erase_personal_data( $email, $page = 1 ) {
		$ids     = self::entries_for( $email, 1 );
		$removed = false;
		foreach ( $ids as $id ) {
			$removed = (bool) wp_delete_post( $id, true ) || $removed;
		}
		return array(
			'items_removed'  => $removed,
			'items_retained' => false,
			'messages'       => array(),
			'done'           => count( $ids ) < 50,
		);
	}
}
