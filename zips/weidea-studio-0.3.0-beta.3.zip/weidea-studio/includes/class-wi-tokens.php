<?php
/**
 * Design tokens, including the Kadence palette bridge.
 *
 * Coexistence contract (current direction): WeIdea tokens ALIAS TO the
 * site's existing Kadence global palette slots, so every WeIdea block
 * automatically re-skins per brand zone through the body-class palette
 * remaps already built on the pilot site. Sites without Kadence simply
 * get the fallback values. Later the bridge flips — brands become native
 * WeIdea token scopes and the Kadence slots alias FROM them.
 *
 * Kadence slot conventions this maps: 1–2 accents, 3–6 text (strongest to
 * faintest), 7–9 backgrounds (softest to base).
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Token definitions and CSS output.
 */
final class WI_Tokens {

	/**
	 * The token map: name (without the --wi- prefix) => CSS value.
	 *
	 * @return string[]
	 */
	public static function tokens() {
		/**
		 * Filter the design tokens. Values are raw CSS; the Kadence bridge
		 * lives in the defaults and can be replaced wholesale on sites
		 * that never ran Kadence.
		 *
		 * @param string[] $tokens Token name => CSS value.
		 */
		return apply_filters(
			'wi_design_tokens',
			array(
				'accent'        => 'var(--global-palette1, #2b6aa3)',
				'accent-alt'    => 'var(--global-palette2, #215181)',
				'text-strong'   => 'var(--global-palette3, #1f2933)',
				'text'          => 'var(--global-palette4, #3e4c59)',
				'text-soft'     => 'var(--global-palette5, #52606d)',
				'text-faint'    => 'var(--global-palette6, #7b8794)',
				'bg-soft'       => 'var(--global-palette7, #f5f7fa)',
				'bg-alt'        => 'var(--global-palette8, #f9fafb)',
				'bg'            => 'var(--global-palette9, #ffffff)',
				'content-width' => '1160px',

				// Motion tokens v1 — the house personality. Every preset
				// and (later) every timeline references these; brand
				// zones can override them (Retrobotics snappy, Knocking
				// Ghost slow and eerie) via body-class scoping.
				'motion-duration'      => '0.6s',
				'motion-duration-fast' => '0.35s',
				'motion-duration-slow' => '1s',
				'motion-ease'          => 'cubic-bezier(0.22, 1, 0.36, 1)',
				'motion-stagger'       => '90ms',
				'motion-distance'      => '28px',
			)
		);
	}

	/**
	 * Breakpoint-aware base rules shared by all block instances — rules
	 * that need the site's configured breakpoints (which static block
	 * stylesheets can't know), generated once per page, not per instance.
	 *
	 * @return string
	 */
	public static function runtime_css() {
		$bp  = WI_Breakpoints::get();
		$css = '@media (max-width:' . $bp['mobile'] . 'px){'
			. '.wi-row--stack{flex-direction:column;}'
			. '.wi-row--stack > .wi-column{flex:1 1 auto;}'
			. '}';

		/**
		 * Filter the breakpoint-aware shared rules.
		 *
		 * @param string $css   Compiled CSS.
		 * @param int[]  $bp    Current breakpoints.
		 */
		return apply_filters( 'wi_runtime_css', $css, $bp );
	}

	/**
	 * The compiled :root ruleset.
	 *
	 * @return string
	 */
	public static function css() {
		$out = ':root{';
		foreach ( self::tokens() as $name => $value ) {
			$name = preg_replace( '/[^a-z0-9-]/', '', strtolower( (string) $name ) );
			if ( '' === $name || ! is_string( $value ) || preg_match( '/[{};<>]/', $value ) ) {
				continue;
			}
			$out .= '--wi-' . $name . ':' . $value . ';';
		}
		return $out . '}';
	}
}
