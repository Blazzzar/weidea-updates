<?php
/**
 * Per-instance responsive CSS, generated from the control registry.
 *
 * The registry schema declares which attribute each control edits and which
 * CSS property/selector it emits; this class walks that schema against a
 * block's saved attributes and compiles the instance stylesheet using the
 * site's configured breakpoints. Devices without their own value simply
 * emit nothing — the cascade handles inheritance (desktop is the base rule,
 * tablet/mobile are max-width overrides).
 *
 * Phase 0 note: instance CSS is emitted inline at render. Compiling merged
 * static per-page stylesheets moves into the staged-deploy pipeline in
 * Phase 1, per the no-bloat contract.
 *
 * @package WeIdeaStudio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registry-driven CSS generation.
 */
final class WI_Block_CSS {

	/**
	 * Generate the instance CSS for one rendered block.
	 *
	 * @param string $block_name Block name, e.g. "weidea/section".
	 * @param array  $attrs      Saved block attributes.
	 * @return string Compiled CSS, or empty string.
	 */
	public static function generate( $block_name, $attrs ) {
		$schema = WI_Registry::schema_for( $block_name );
		if ( ! $schema || empty( $attrs['uniqueId'] ) ) {
			return '';
		}

		$uid = preg_replace( '/[^a-zA-Z0-9_-]/', '', (string) $attrs['uniqueId'] );
		if ( '' === $uid ) {
			return '';
		}

		$selectors = isset( $schema['selectors'] ) ? $schema['selectors'] : array();
		// Buckets follow the ordered device list — never a hard-coded
		// three — so a site (or a later phase) can add breakpoints and
		// existing content compiles against them unchanged.
		$devices    = WI_Breakpoints::devices();
		$device_ids = array_column( $devices, 'id' );
		$base_id    = $device_ids[0];
		$buckets    = array_fill_keys( $device_ids, array() );

		foreach ( (array) $schema['panels'] as $panel ) {
			foreach ( (array) $panel['controls'] as $control ) {
				if ( empty( $control['css']['property'] ) || empty( $control['bind']['attribute'] ) ) {
					continue;
				}

				$css       = $control['css'];
				$attr_name = $control['bind']['attribute'];
				$value     = isset( $attrs[ $attr_name ] ) ? $attrs[ $attr_name ] : null;
				$sel_key   = isset( $css['selector'] ) ? $css['selector'] : 'self';
				$sel_tpl   = isset( $selectors[ $sel_key ] ) ? $selectors[ $sel_key ] : '.wi-{uid}';
				$selector  = str_replace( '{uid}', $uid, $sel_tpl );
				$property  = $css['property'];

				// Hover-state bindings style the same selector's :hover.
				if ( isset( $css['state'] ) && 'hover' === $css['state'] ) {
					$selector .= ':hover';
				}

				if ( isset( $css['value'] ) ) {
					// Preset binding: a fixed declaration emitted while the
					// attribute is truthy (e.g. stack-on-mobile), confined
					// to css.device's bucket when given.
					if ( $value ) {
						$device = isset( $css['device'] ) && isset( $buckets[ $css['device'] ] )
							? $css['device']
							: $base_id;
						$v      = self::sanitize_value( $css['value'] );
						if ( '' !== $v ) {
							$buckets[ $device ][ $selector ][ $property ] = $v;
						}
					}
				} elseif ( ! empty( $control['responsive'] ) && is_array( $value ) ) {
					foreach ( $device_ids as $device ) {
						$v = isset( $value[ $device ] ) ? self::sanitize_value( $value[ $device ] ) : '';
						if ( '' !== $v ) {
							$buckets[ $device ][ $selector ][ $property ] = self::apply_template( $css, $v );
						}
					}
				} elseif ( empty( $control['responsive'] ) ) {
					$v = self::sanitize_value( is_scalar( $value ) ? $value : '' );
					if ( '' !== $v ) {
						$buckets[ $base_id ][ $selector ][ $property ] = self::apply_template( $css, $v );
					}
				}
			}
		}

		$css = '';
		foreach ( $devices as $device ) {
			$bucket = $buckets[ $device['id'] ];
			if ( ! $bucket ) {
				continue;
			}
			if ( null === $device['max_width'] ) {
				$css .= self::rules( $bucket );
			} else {
				$css .= '@media (max-width:' . (int) $device['max_width'] . 'px){' . self::rules( $bucket ) . '}';
			}
		}
		return $css;
	}

	/**
	 * Wrap a value in the binding's template, e.g. "0 0 {value}" turns a
	 * width into a flex shorthand. The value is already sanitized.
	 *
	 * @param array  $css   The control's css binding.
	 * @param string $value Sanitized value.
	 * @return string
	 */
	private static function apply_template( $css, $value ) {
		if ( empty( $css['template'] ) || false === strpos( $css['template'], '{value}' ) ) {
			return $value;
		}
		// The template itself ships in the registry schema (trusted);
		// only {value} carries user input, sanitized above.
		return str_replace( '{value}', $value, $css['template'] );
	}

	/**
	 * Serialize a selector => declarations map.
	 *
	 * @param array $map Selector => [ property => value ].
	 * @return string
	 */
	private static function rules( $map ) {
		$out = '';
		foreach ( $map as $selector => $props ) {
			$out .= $selector . '{';
			foreach ( $props as $property => $value ) {
				$out .= $property . ':' . $value . ';';
			}
			$out .= '}';
		}
		return $out;
	}

	/**
	 * Reject values that could escape a declaration or smuggle behavior.
	 *
	 * @param mixed $value Raw attribute value.
	 * @return string Safe value or empty string.
	 */
	private static function sanitize_value( $value ) {
		if ( ! is_string( $value ) && ! is_numeric( $value ) ) {
			return '';
		}
		$value = trim( (string) $value );
		if ( '' === $value ) {
			return '';
		}
		if ( preg_match( '/[{};<>\\\\]|expression|javascript|url\s*\(/i', $value ) ) {
			return '';
		}
		return $value;
	}
}
